import { Student, AttendanceRecord, Invoice, PushReminder, PeakHourData, RetentionCohort, LibrarySettings, ShiftType, PlanType, PaymentStatus, StudentApplication, calculateShiftFee } from '../types';
import { defaultStudentAvatar } from '../utils/assets';

export const DEFAULT_SETTINGS: LibrarySettings = {
  name: 'Bharti Digital Library',
  tagline: '24/7 Silent Study Sanctuary & Digital Hub',
  ownerName: 'Raj',
  phone: '9973299354',
  email: 'contact@bhartidigitallibrary.com',
  address: 'Sekhwara More, Bodhgaya 824234',
  totalDesks: 120,
  monthlyFees: {
    AFTERNOON: 300,
    MORNING: 400,
    EVENING: 400,
    DAY_9TO5: 500,
    NIGHT_OWL: 350,
    TWELVE_HOURS: 700,
    FULL_DAY: 750,
    TWENTY_FOUR_HOURS: 800,
    RESERVED_CUBICLE: 700,
  },
  currency: '₹',
  upiNumber: '9973299354',
  upiId: '9973299354@ybl',
  upiPayeeName: 'Bharti Digital Library',
  whatsappConnected: true,
  whatsappNumber: '9973299354',
  whatsappBusinessName: 'Bharti Digital Library',
  whatsappIncludeUpi: true,
  whatsappIncludePortalLink: true,
  whatsappCustomNote: 'Kindly clear your dues by the due date to keep your reserved desk active.',
  notificationsEnabled: true,
  autoRemindDaysBefore: 3,
};

export const UPLOADED_SHEET_STUDENTS: string[] = [
  'Sunaina Kumari',
  'Soni Kumari',
  'Aasha Kumari',
  'Anjani Kumari',
  'Kavita Kumari',
  'Rajni Kumari',
  'Annu Kumari',
  'Priyanka Kri',
  'Sanam Kumari',
  'Raina Kumari',
  'Seema Kri',
  'Arti Kumari',
  'Sapna Kumari',
  'Priya Kumari',
  'Aarti Kumari',
  'Shusma Kumari',
  'Simmi Kumari',
  'Gudiya Kumari',
  'Simran Kumari',
  'Sonam Kumari',
  'Saniya Kumari',
  'Khusi Kumari',
  'Shiva Kumar',
  'Vikash Kumar',
  'Arvind Kumar',
  'Ankit Kumar',
  'Vikash Raftar',
  'Dhanjay Kumar',
  'Ajay Kumar',
  'Munna Kumar',
  'Sachin Kumar',
  'Rahul Kumar Sir',
  'Bholu Kumar',
  'Ritik Kumar',
  'Nitish Kumar',
  'Vikash Kumar',
  'Rajeev Kumar',
  'Nitish Kumar Bhola',
  'Raushan Kumar',
  'Raushan Kumar',
  'Pradeep Kumar',
  'Rishu Kumar',
  'Upnesh Kumar',
  'Dablu Kumar',
  'Bipin Kumar',
  'Sarwajeet Kumar',
  'Shasikant Kumar',
  'Amit Raj',
  'Nitish Kumar',
  'Rahish Kumar',
  'Manish Kumar',
  'Mantu Kumar',
  'Saurav Kumar',
  'Kartik Kumar',
  'Akshay Kumar',
  'Himanshu Kumar',
  'Raju Kumar',
  'Banti Kumar',
  'Dharmendra Kumar',
  'Rohit Kumar',
  'Omprakash Kumar',
  'Pramanand Kumar',
  'Deepak Kumar',
  'Shivam Kumar',
  'Nitish Kumar',
  'Shivam Kumar',
  'Mohit Kumar',
  'Dhanjay Kumar',
  'Nitish Kumar',
  'Sujit Kumar',
  'Shyam Sunder',
  'Shristi Kumari',
];

const EXAMS = [
  'Civil Services / UPSC',
  'BPSC / State PSC',
  'SSC CGL / CHSL',
  'Medical / NEET',
  'Railways / RRB NTPC',
  'Banking / IBPS PO',
  'Bihar Police / SI',
  'GATE / Engineering',
];

export function generateInitialStudents(): Student[] {
  const students: Student[] = [];
  const shiftsPool: ShiftType[] = ['DAY_9TO5', 'TWELVE_HOURS', 'MORNING', 'EVENING', 'AFTERNOON', 'NIGHT_OWL', 'TWENTY_FOUR_HOURS', 'FULL_DAY'];
  const plans: PlanType[] = ['MONTHLY_FULL_DAY', 'MONTHLY_HALF_DAY', 'RESERVED_CUBICLE', 'QUARTERLY_PASS'];

  UPLOADED_SHEET_STUDENTS.forEach((fullName, idx) => {
    const i = idx + 1;
    const idNum = 1000 + i;
    const id = `LIB-${idNum}`;
    const pin = String(1000 + ((i * 73 + 19) % 8999));
    const primaryShift = shiftsPool[idx % shiftsPool.length];
    const plan = plans[idx % plans.length];

    let studentShifts: ShiftType[] = [primaryShift];
    if (i % 6 === 0) {
      studentShifts = ['MORNING', 'EVENING']; // 6h + 6h = 12h -> ₹700
    } else if (i % 7 === 0) {
      studentShifts = ['DAY_9TO5']; // 8h -> ₹500
    } else if (i % 9 === 0) {
      studentShifts = ['TWELVE_HOURS']; // 12h -> ₹700
    } else if (i % 11 === 0) {
      studentShifts = ['TWENTY_FOUR_HOURS']; // 24h -> ₹800
    }

    const zone = i <= 40 ? 'A' : 'B';
    const deskNum = ((i - 1) % 40) + 1;
    const desk = `${zone}-${String(deskNum).padStart(2, '0')}`;
    const hasLocker = i % 4 === 0;
    const lockerNum = hasLocker ? `L-${String(i).padStart(3, '0')}` : undefined;

    const monthlyFee = calculateShiftFee(studentShifts, DEFAULT_SETTINGS.monthlyFees);

    let paymentStatus: PaymentStatus = 'PAID';
    let renewalDueDate = '2026-11-28';

    if (i <= 9) {
      paymentStatus = 'OVERDUE';
      renewalDueDate = `2026-11-${String((i % 9) + 1).padStart(2, '0')}`;
    } else if (i <= 21) {
      paymentStatus = 'DUE_SOON';
      renewalDueDate = `2026-11-${String(14 + (i % 3)).padStart(2, '0')}`;
    } else {
      paymentStatus = 'PAID';
      renewalDueDate = `2026-12-${String((i % 25) + 1).padStart(2, '0')}`;
    }

    const isCheckedIn = i % 2 === 0 && i <= 64;
    const checkInHour = 7 + (i % 6);
    const checkInMin = (i * 13) % 60;
    const checkInTime = isCheckedIn
      ? `2026-11-13T${String(checkInHour).padStart(2, '0')}:${String(checkInMin).padStart(2, '0')}:00`
      : undefined;

    const currentDurationMinutes = isCheckedIn ? (13 - checkInHour) * 60 + (30 - checkInMin) : undefined;
    const cleanSlug = fullName.toLowerCase().replace(/[^a-z0-9]+/g, '.');

    students.push({
      id,
      pin,
      name: fullName,
      phone: `+91 98${String(100 + ((i * 17) % 899)).padStart(3, '0')} ${String(10000 + ((i * 437) % 89999)).padStart(5, '0')}`,
      email: `${cleanSlug}@bhartilibrary.in`,
      avatarUrl: i === 1 ? defaultStudentAvatar : `https://images.unsplash.com/broken-fallback-safe-${i}`,
      assignedDesk: desk,
      hasLocker,
      lockerNumber: lockerNum,
      shift: studentShifts[0],
      shifts: studentShifts,
      plan,
      monthlyFee,
      paymentStatus,
      joinedDate: `2026-${String(Math.max(1, 11 - (i % 6))).padStart(2, '0')}-05`,
      cardValidFrom: paymentStatus === 'OVERDUE' ? '2026-10-08' : '2026-11-02',
      renewalDueDate,
      lastPaymentDate: paymentStatus === 'OVERDUE' ? '2026-10-08' : '2026-11-02',
      attendanceStatus: isCheckedIn ? 'CHECKED_IN' : 'CHECKED_OUT',
      currentCheckInTime: checkInTime,
      currentCheckInDurationMinutes: currentDurationMinutes && currentDurationMinutes > 0 ? currentDurationMinutes : 120,
      totalVisitsThisMonth: 12 + (i % 16),
      avgHoursPerVisit: 5.5 + ((i % 10) * 0.3),
      courseOrExam: EXAMS[idx % EXAMS.length],
      notes: i % 8 === 0 ? 'Prefers corner cubicle away from entrance' : undefined,
    });
  });

  return students;
}

export function generateInitialAttendanceHistory(students: Student[]): AttendanceRecord[] {
  const records: AttendanceRecord[] = [];
  const methods: ('QR_SCAN' | 'PIN_KIOSK' | 'STAFF_MANUAL')[] = ['QR_SCAN', 'PIN_KIOSK', 'STAFF_MANUAL'];

  // Today's active records (November 13, 2026)
  students.filter(s => s.attendanceStatus === 'CHECKED_IN').forEach((s, idx) => {
    records.push({
      id: `ATT-TODAY-${idx + 1}`,
      studentId: s.id,
      studentName: s.name,
      assignedDesk: s.assignedDesk,
      shift: s.shift,
      checkInTime: s.currentCheckInTime || '2026-11-13T08:30:00',
      durationMinutes: s.currentCheckInDurationMinutes || 180,
      method: methods[idx % 3],
      overtimeAlert: s.shift === 'MORNING' && idx % 4 === 0,
    });
  });

  // Earlier November 2026 completed checkouts (Current Month multi-day log)
  students.forEach((s, idx) => {
    if (idx % 12 !== 0) {
      const visitDays = (idx % 3) + 1;
      for (let v = 0; v < visitDays; v++) {
        const day = String(2 + ((idx + v * 3) % 10)).padStart(2, '0');
        records.push({
          id: `ATT-2026-11-${idx}-${v}`,
          studentId: s.id,
          studentName: s.name,
          assignedDesk: s.assignedDesk,
          shift: s.shift,
          checkInTime: `2026-11-${day}T07:15:00`,
          checkOutTime: `2026-11-${day}T13:30:00`,
          durationMinutes: 375,
          method: methods[(idx + v) % 3],
          overtimeAlert: false,
        });
      }
    }
  });

  // Monthly historical attendance across January (01) through October (10) 2026
  // Simulates growing attendance from ~42 students in Jan up to ~67 students in Oct
  const targetCountByMonth: Record<number, number> = {
    1: 42, // January
    2: 47, // February
    3: 51, // March
    4: 54, // April
    5: 57, // May
    6: 59, // June
    7: 62, // July
    8: 64, // August
    9: 65, // September
    10: 67, // October (Last Month)
  };

  for (let month = 1; month <= 10; month++) {
    const mm = String(month).padStart(2, '0');
    const targetPresent = Math.min(students.length, targetCountByMonth[month] || 50);

    for (let idx = 0; idx < students.length; idx++) {
      // Deterministic rotating selection so each month has realistic present/absent variation
      const rank = (idx * 7 + month * 5) % students.length;
      if (rank >= targetPresent) continue;

      const s = students[idx];
      const visitsInMonth = 1 + ((idx + month) % 3); // 1-3 representative logs per student in month
      for (let v = 0; v < visitsInMonth; v++) {
        const day = String(3 + ((idx + v * 7 + month) % 24)).padStart(2, '0');
        records.push({
          id: `ATT-2026-${mm}-${idx}-${v}`,
          studentId: s.id,
          studentName: s.name,
          assignedDesk: s.assignedDesk,
          shift: s.shift,
          checkInTime: `2026-${mm}-${day}T08:00:00`,
          checkOutTime: `2026-${mm}-${day}T14:00:00`,
          durationMinutes: 360,
          method: methods[(idx + v + month) % 3],
          overtimeAlert: false,
        });
      }
    }
  }

  return records;
}

export function generateInitialInvoices(students: Student[]): Invoice[] {
  const invoices: Invoice[] = [];
  const methods: ('UPI' | 'CASH' | 'CARD' | 'BANK_TRANSFER')[] = ['UPI', 'CASH', 'CARD', 'BANK_TRANSFER'];

  // Current Month (November 2026) paid invoices matching PAID students
  students.forEach((s, i) => {
    if (s.paymentStatus === 'PAID') {
      invoices.push({
        id: `INV-11${String(i + 1).padStart(3, '0')}`,
        studentId: s.id,
        studentName: s.name,
        phone: s.phone,
        planName: s.plan.replace('_', ' '),
        amount: s.monthlyFee,
        paidDate: `2026-11-${String(1 + (i % 12)).padStart(2, '0')}`,
        periodStart: '2026-11-01',
        periodEnd: s.renewalDueDate,
        paymentMethod: methods[i % methods.length],
        transactionRef: `TXN2611${String(1000 + i)}`,
        status: 'PAID',
      });
    }
  });

  // Historical Monthly Fee Invoices for January (01) through October (10) 2026
  const paidTargetByMonth: Record<number, number> = {
    1: 38, // January
    2: 43, // February
    3: 47, // March
    4: 50, // April
    5: 53, // May
    6: 55, // June
    7: 58, // July
    8: 60, // August
    9: 61, // September
    10: 63, // October (Last Month)
  };

  for (let month = 1; month <= 10; month++) {
    const mm = String(month).padStart(2, '0');
    const targetPaid = Math.min(students.length, paidTargetByMonth[month] || 45);

    for (let idx = 0; idx < students.length; idx++) {
      const rank = (idx * 5 + month * 3) % students.length;
      if (rank >= targetPaid) continue;

      const s = students[idx];
      const payDay = String(1 + ((idx + month) % 10)).padStart(2, '0');
      invoices.push({
        id: `INV-${mm}${String(idx + 1).padStart(3, '0')}`,
        studentId: s.id,
        studentName: s.name,
        phone: s.phone,
        planName: s.plan.replace('_', ' '),
        amount: s.monthlyFee,
        paidDate: `2026-${mm}-${payDay}`,
        periodStart: `2026-${mm}-01`,
        periodEnd: `2026-${mm}-28`,
        paymentMethod: methods[(idx + month) % methods.length],
        transactionRef: `TXN26${mm}${String(1000 + idx)}`,
        status: 'PAID',
      });
    }
  }

  return invoices;
}

export function generateInitialReminders(students: Student[]): PushReminder[] {
  const reminders: PushReminder[] = [];
  const dueStudents = students.filter(s => s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'DUE_SOON').slice(0, 8);

  dueStudents.forEach((s, idx) => {
    const isOverdue = s.paymentStatus === 'OVERDUE';
    reminders.push({
      id: `REM-${idx + 1}`,
      studentId: s.id,
      studentName: s.name,
      phone: s.phone,
      type: isOverdue ? 'OVERDUE_ALERT' : 'DUE_IN_3_DAYS',
      title: isOverdue ? '⚠️ Payment Overdue Notice' : '📅 Monthly Fee Reminder',
      message: isOverdue
        ? `Dear ${s.name}, your membership fee of ₹${s.monthlyFee} was due on ${s.renewalDueDate}. Please clear immediately to retain desk ${s.assignedDesk}.`
        : `Hi ${s.name}, your library renewal is coming up on ${s.renewalDueDate}. Total: ₹${s.monthlyFee}.`,
      sentAt: `2026-11-12T07:${String(10 + idx * 5).padStart(2, '0')}:00`,
      channel: idx % 2 === 0 ? 'PUSH' : 'WHATSAPP',
      status: 'DELIVERED',
    });
  });

  return reminders;
}

export const HOURLY_PEAK_DATA: PeakHourData[] = [
  { hour: 6, label: '6 AM', occupancyCount: 14, capacityPercentage: 12, isPeak: false },
  { hour: 7, label: '7 AM', occupancyCount: 32, capacityPercentage: 27, isPeak: false },
  { hour: 8, label: '8 AM', occupancyCount: 58, capacityPercentage: 48, isPeak: false },
  { hour: 9, label: '9 AM', occupancyCount: 88, capacityPercentage: 73, isPeak: true },
  { hour: 10, label: '10 AM', occupancyCount: 112, capacityPercentage: 93, isPeak: true }, // Peak Morning
  { hour: 11, label: '11 AM', occupancyCount: 116, capacityPercentage: 97, isPeak: true }, // Peak Morning
  { hour: 12, label: '12 PM', occupancyCount: 98, capacityPercentage: 82, isPeak: true },
  { hour: 13, label: '1 PM', occupancyCount: 74, capacityPercentage: 62, isPeak: false }, // Lunch lull
  { hour: 14, label: '2 PM', occupancyCount: 82, capacityPercentage: 68, isPeak: false },
  { hour: 15, label: '3 PM', occupancyCount: 94, capacityPercentage: 78, isPeak: true },
  { hour: 16, label: '4 PM', occupancyCount: 105, capacityPercentage: 88, isPeak: true },
  { hour: 17, label: '5 PM', occupancyCount: 115, capacityPercentage: 96, isPeak: true }, // Peak Evening
  { hour: 18, label: '6 PM', occupancyCount: 118, capacityPercentage: 98, isPeak: true }, // Peak Evening
  { hour: 19, label: '7 PM', occupancyCount: 114, capacityPercentage: 95, isPeak: true },
  { hour: 20, label: '8 PM', occupancyCount: 92, capacityPercentage: 77, isPeak: false },
  { hour: 21, label: '9 PM', occupancyCount: 65, capacityPercentage: 54, isPeak: false },
  { hour: 22, label: '10 PM', occupancyCount: 42, capacityPercentage: 35, isPeak: false },
  { hour: 23, label: '11 PM', occupancyCount: 22, capacityPercentage: 18, isPeak: false },
];

export const RETENTION_COHORTS: RetentionCohort[] = [
  { cohortMonth: 'May 2026', totalRegistered: 124, retainedMonth1: 91, retainedMonth2: 83, retainedMonth3: 76, retainedMonth6: 68, dropReasonTop: 'Completed Civil Services Prelims' },
  { cohortMonth: 'June 2026', totalRegistered: 142, retainedMonth1: 93, retainedMonth2: 86, retainedMonth3: 79, retainedMonth6: 72, dropReasonTop: 'College Semester Reopened' },
  { cohortMonth: 'July 2026', totalRegistered: 138, retainedMonth1: 89, retainedMonth2: 81, retainedMonth3: 74, retainedMonth6: 66, dropReasonTop: 'Shift Time Clashing' },
  { cohortMonth: 'August 2026', totalRegistered: 156, retainedMonth1: 94, retainedMonth2: 88, retainedMonth3: 82, retainedMonth6: 75, dropReasonTop: 'Relocated to Coaching Center' },
  { cohortMonth: 'September 2026', totalRegistered: 148, retainedMonth1: 92, retainedMonth2: 84, retainedMonth3: 78, retainedMonth6: 71, dropReasonTop: 'Switched to Home Study' },
  { cohortMonth: 'October 2026', totalRegistered: 165, retainedMonth1: 95, retainedMonth2: 89, retainedMonth3: 84, retainedMonth6: 77, dropReasonTop: 'Exam Cycle Finished' },
];

export const CHURN_REASONS = [
  { reason: 'Exam / Course Finished', percentage: 42, count: 52 },
  { reason: 'Relocated to University / Center', percentage: 24, count: 30 },
  { reason: 'Shift Timings Clashed with Work', percentage: 16, count: 20 },
  { reason: 'Pricing / Financial Constraints', percentage: 11, count: 14 },
  { reason: 'Switched to Home Study', percentage: 7, count: 9 },
];

export function generateInitialApplications(): StudentApplication[] {
  return [
    {
      id: 'APP-2026-1049',
      fullName: 'Rajesh Kumar',
      phone: '+91 98112 34567',
      email: 'rajesh.k@gmail.com',
      courseOrExam: 'Civil Services / UPSC Prelims 2027',
      desiredShift: 'DAY_9TO5',
      desiredShifts: ['DAY_9TO5'],
      desiredPlan: 'RESERVED_CUBICLE',
      deskPreference: 'Zone A (Quiet AC)',
      hasLocker: true,
      govtIdType: 'Aadhaar / National ID',
      govtIdNumber: 'XXXX-XXXX-4819',
      submittedAt: '2026-11-12T07:45:00',
      status: 'PENDING',
    },
    {
      id: 'APP-2026-1050',
      fullName: 'Pooja Verma',
      phone: '+91 97234 56789',
      email: 'pooja.verma@outlook.com',
      courseOrExam: 'NEET PG Medical Residency',
      desiredShift: 'MORNING',
      desiredShifts: ['MORNING', 'EVENING'],
      desiredPlan: 'MONTHLY_HALF_DAY',
      deskPreference: 'Window Seat / Natural Light',
      hasLocker: false,
      govtIdType: 'College ID Card',
      govtIdNumber: 'MMC-2023-891',
      submittedAt: '2026-11-12T08:15:00',
      status: 'PENDING',
    },
    {
      id: 'APP-2026-1051',
      fullName: 'Amit Yadav',
      phone: '+91 98456 12345',
      email: 'amit.yadav@gmail.com',
      courseOrExam: 'SSC CGL & State PSC',
      desiredShift: 'TWENTY_FOUR_HOURS',
      desiredShifts: ['TWENTY_FOUR_HOURS'],
      desiredPlan: 'MONTHLY_FULL_DAY',
      deskPreference: 'Near Power Socket',
      hasLocker: true,
      govtIdType: 'Driving License',
      govtIdNumber: 'DL-04202200918',
      submittedAt: '2026-11-12T08:20:00',
      status: 'PENDING',
    },
    {
      id: 'APP-2026-1052',
      fullName: 'Sneha Gupta',
      phone: '+91 99123 98765',
      email: 'sneha.gupta@company.com',
      courseOrExam: 'Remote Data Analyst & CFA Prep',
      desiredShift: 'FULL_DAY',
      desiredShifts: ['FULL_DAY'],
      desiredPlan: 'RESERVED_CUBICLE',
      deskPreference: 'Corner Desk / Ergonomic Chair',
      hasLocker: true,
      govtIdType: 'Passport',
      govtIdNumber: 'Z8921045',
      submittedAt: '2026-11-12T08:32:00',
      status: 'PENDING',
    },
  ];
}
