import React, { useState, useEffect } from 'react';
import { X, Printer, Share2, QrCode, Shield, Check, Pencil, Camera, CalendarRange, IndianRupee, Award, Palette } from 'lucide-react';
import { Student, LibrarySettings, formatStudentShifts } from '../types';
import { generateQrDataUrl } from '../utils/qr';
import { CameraCaptureModal } from './CameraCaptureModal';
import { resolveStudentAvatar } from '../utils/assets';

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const CARD_THEME_STORAGE_KEY = 'bharti_id_card_theme_v2';

type CardThemeId = 'monochrome' | 'emerald' | 'navy' | 'ivory' | 'maroon' | 'teal';

interface CardThemeConfig {
  id: CardThemeId;
  label: string;
  swatchClass: string;
  outerFrame: string;
  cardBg: string;
  topStrip: string;
  divider: string;
  brandIcon: string;
  brandTitle: string;
  subtitle: string;
  shiftBadge: string;
  photoFrame: string;
  studentName: string;
  studentId: string;
  studentCourse: string;
  statBoxDesk: string;
  statLabelDesk: string;
  statValDesk: string;
  statBoxPin: string;
  statLabelPin: string;
  statValPin: string;
  statBoxLocker: string;
  statLabelLocker: string;
  statValLocker: string;
  qrFrame: string;
  qrLabel: string;
  infoPanel: string;
  infoDivider: string;
  infoIcon: string;
  infoLabel: string;
  infoVal: string;
  fromDateVal: string;
  arrowColor: string;
  toDateOk: string;
  toDateAlert: string;
  statusPaid: string;
  statusDue: string;
  statusOverdue: string;
}

const CARD_THEMES: Record<CardThemeId, CardThemeConfig> = {
  monochrome: {
    id: 'monochrome',
    label: 'White & Black',
    swatchClass: 'bg-gradient-to-br from-white via-neutral-300 to-black ring-slate-900 dark:ring-white',
    outerFrame: 'bg-gradient-to-br from-white via-neutral-400 to-black',
    cardBg: 'bg-gradient-to-br from-black via-neutral-950 to-neutral-900 text-white',
    topStrip: 'bg-white',
    divider: 'border-white/25',
    brandIcon: 'text-white',
    brandTitle: 'text-white',
    subtitle: 'text-neutral-300',
    shiftBadge: 'bg-white text-black border-white',
    photoFrame: 'bg-white',
    studentName: 'text-white',
    studentId: 'text-neutral-200',
    studentCourse: 'text-neutral-300',
    statBoxDesk: 'bg-white border-white',
    statLabelDesk: 'text-neutral-600',
    statValDesk: 'text-black',
    statBoxPin: 'bg-neutral-900 border-white/40',
    statLabelPin: 'text-neutral-300',
    statValPin: 'text-white',
    statBoxLocker: 'bg-white border-white',
    statLabelLocker: 'text-neutral-600',
    statValLocker: 'text-black',
    qrFrame: 'bg-white',
    qrLabel: 'text-black',
    infoPanel: 'bg-neutral-900/90 border-white/25',
    infoDivider: 'border-white/15',
    infoIcon: 'text-white',
    infoLabel: 'text-neutral-300',
    infoVal: 'text-white',
    fromDateVal: 'text-white',
    arrowColor: 'text-neutral-400',
    toDateOk: 'text-white',
    toDateAlert: 'text-neutral-300 underline decoration-white/60',
    statusPaid: 'bg-white text-black border border-white',
    statusDue: 'bg-neutral-800 text-white border border-white/50',
    statusOverdue: 'bg-black text-white border border-white',
  },
  emerald: {
    id: 'emerald',
    label: 'Emerald',
    swatchClass: 'bg-gradient-to-br from-emerald-800 to-emerald-950 ring-amber-400',
    outerFrame: 'bg-gradient-to-br from-amber-400 via-emerald-500 to-amber-500',
    cardBg: 'bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-950 text-white',
    topStrip: 'bg-gradient-to-r from-amber-300 via-yellow-400 to-emerald-400',
    divider: 'border-emerald-400/20',
    brandIcon: 'text-amber-300',
    brandTitle: 'text-amber-200',
    subtitle: 'text-emerald-200/85',
    shiftBadge: 'bg-emerald-800/70 text-amber-200 border-amber-300/35',
    photoFrame: 'bg-gradient-to-br from-amber-300 via-yellow-400 to-emerald-400',
    studentName: 'text-white',
    studentId: 'text-amber-300',
    studentCourse: 'text-emerald-200',
    statBoxDesk: 'bg-emerald-800/45 border-emerald-400/30',
    statLabelDesk: 'text-emerald-200',
    statValDesk: 'text-white',
    statBoxPin: 'bg-amber-500/15 border-amber-300/35',
    statLabelPin: 'text-amber-200',
    statValPin: 'text-amber-300',
    statBoxLocker: 'bg-slate-900/50 border-emerald-300/25',
    statLabelLocker: 'text-emerald-200/90',
    statValLocker: 'text-emerald-100',
    qrFrame: 'bg-gradient-to-r from-amber-300 via-emerald-400 to-amber-400',
    qrLabel: 'text-emerald-900',
    infoPanel: 'bg-emerald-950/60 border-emerald-400/25',
    infoDivider: 'border-emerald-400/15',
    infoIcon: 'text-emerald-400',
    infoLabel: 'text-emerald-200',
    infoVal: 'text-white',
    fromDateVal: 'text-amber-200',
    arrowColor: 'text-amber-300',
    toDateOk: 'text-emerald-300',
    toDateAlert: 'text-rose-300',
    statusPaid: 'bg-emerald-400/25 text-emerald-100 border border-emerald-300/45',
    statusDue: 'bg-amber-400/25 text-amber-100 border border-amber-300/45',
    statusOverdue: 'bg-rose-500/30 text-rose-100 border border-rose-300/45',
  },
  navy: {
    id: 'navy',
    label: 'Royal Navy',
    swatchClass: 'bg-gradient-to-br from-blue-900 to-slate-950 ring-sky-400',
    outerFrame: 'bg-gradient-to-br from-sky-400 via-blue-500 to-amber-400',
    cardBg: 'bg-gradient-to-br from-blue-950 via-slate-900 to-slate-950 text-white',
    topStrip: 'bg-gradient-to-r from-sky-400 via-blue-400 to-amber-400',
    divider: 'border-sky-300/20',
    brandIcon: 'text-amber-300',
    brandTitle: 'text-sky-100',
    subtitle: 'text-sky-200/80',
    shiftBadge: 'bg-blue-900/70 text-sky-100 border-sky-300/35',
    photoFrame: 'bg-gradient-to-br from-sky-300 via-blue-400 to-amber-300',
    studentName: 'text-white',
    studentId: 'text-sky-300',
    studentCourse: 'text-slate-300',
    statBoxDesk: 'bg-blue-900/45 border-sky-400/30',
    statLabelDesk: 'text-sky-200',
    statValDesk: 'text-white',
    statBoxPin: 'bg-amber-500/15 border-amber-300/35',
    statLabelPin: 'text-amber-200',
    statValPin: 'text-amber-300',
    statBoxLocker: 'bg-slate-800/60 border-sky-300/25',
    statLabelLocker: 'text-slate-300',
    statValLocker: 'text-sky-100',
    qrFrame: 'bg-gradient-to-r from-sky-400 via-blue-500 to-amber-300',
    qrLabel: 'text-blue-950',
    infoPanel: 'bg-slate-900/75 border-sky-300/20',
    infoDivider: 'border-sky-300/15',
    infoIcon: 'text-sky-300',
    infoLabel: 'text-sky-200',
    infoVal: 'text-white',
    fromDateVal: 'text-sky-200',
    arrowColor: 'text-amber-300',
    toDateOk: 'text-emerald-300',
    toDateAlert: 'text-rose-300',
    statusPaid: 'bg-emerald-500/25 text-emerald-200 border border-emerald-400/40',
    statusDue: 'bg-amber-500/25 text-amber-200 border border-amber-400/40',
    statusOverdue: 'bg-rose-500/30 text-rose-200 border border-rose-400/40',
  },
  maroon: {
    id: 'maroon',
    label: 'Crimson',
    swatchClass: 'bg-gradient-to-br from-rose-900 to-red-950 ring-amber-400',
    outerFrame: 'bg-gradient-to-br from-amber-400 via-rose-500 to-amber-300',
    cardBg: 'bg-gradient-to-br from-red-950 via-rose-950 to-stone-950 text-white',
    topStrip: 'bg-gradient-to-r from-amber-300 via-orange-400 to-rose-400',
    divider: 'border-amber-200/20',
    brandIcon: 'text-amber-300',
    brandTitle: 'text-amber-100',
    subtitle: 'text-rose-200/85',
    shiftBadge: 'bg-rose-900/70 text-amber-100 border-amber-300/35',
    photoFrame: 'bg-gradient-to-br from-amber-300 via-rose-400 to-amber-400',
    studentName: 'text-white',
    studentId: 'text-amber-300',
    studentCourse: 'text-rose-200',
    statBoxDesk: 'bg-rose-900/40 border-rose-300/30',
    statLabelDesk: 'text-rose-200',
    statValDesk: 'text-white',
    statBoxPin: 'bg-amber-500/15 border-amber-300/35',
    statLabelPin: 'text-amber-200',
    statValPin: 'text-amber-300',
    statBoxLocker: 'bg-stone-900/60 border-amber-300/25',
    statLabelLocker: 'text-rose-200/90',
    statValLocker: 'text-amber-100',
    qrFrame: 'bg-gradient-to-r from-amber-300 via-rose-400 to-amber-400',
    qrLabel: 'text-rose-950',
    infoPanel: 'bg-black/25 border-amber-200/20',
    infoDivider: 'border-amber-200/15',
    infoIcon: 'text-amber-300',
    infoLabel: 'text-rose-200',
    infoVal: 'text-white',
    fromDateVal: 'text-amber-200',
    arrowColor: 'text-amber-300',
    toDateOk: 'text-emerald-300',
    toDateAlert: 'text-rose-300',
    statusPaid: 'bg-emerald-500/25 text-emerald-200 border border-emerald-300/45',
    statusDue: 'bg-amber-400/25 text-amber-100 border border-amber-300/45',
    statusOverdue: 'bg-rose-500/35 text-rose-100 border border-rose-300/45',
  },
  teal: {
    id: 'teal',
    label: 'Ocean Teal',
    swatchClass: 'bg-gradient-to-br from-teal-800 to-slate-950 ring-teal-400',
    outerFrame: 'bg-gradient-to-br from-teal-400 via-cyan-500 to-emerald-400',
    cardBg: 'bg-gradient-to-br from-teal-950 via-slate-900 to-slate-950 text-white',
    topStrip: 'bg-gradient-to-r from-teal-300 via-cyan-400 to-emerald-400',
    divider: 'border-teal-300/20',
    brandIcon: 'text-teal-300',
    brandTitle: 'text-teal-100',
    subtitle: 'text-cyan-200/80',
    shiftBadge: 'bg-teal-900/70 text-teal-100 border-teal-300/35',
    photoFrame: 'bg-gradient-to-br from-teal-300 via-cyan-400 to-emerald-300',
    studentName: 'text-white',
    studentId: 'text-teal-300',
    studentCourse: 'text-slate-300',
    statBoxDesk: 'bg-teal-900/45 border-teal-400/30',
    statLabelDesk: 'text-teal-200',
    statValDesk: 'text-white',
    statBoxPin: 'bg-cyan-500/15 border-cyan-300/35',
    statLabelPin: 'text-cyan-200',
    statValPin: 'text-cyan-300',
    statBoxLocker: 'bg-slate-800/60 border-teal-300/25',
    statLabelLocker: 'text-slate-300',
    statValLocker: 'text-teal-100',
    qrFrame: 'bg-gradient-to-r from-teal-300 via-cyan-400 to-emerald-400',
    qrLabel: 'text-teal-950',
    infoPanel: 'bg-slate-900/75 border-teal-300/20',
    infoDivider: 'border-teal-300/15',
    infoIcon: 'text-teal-300',
    infoLabel: 'text-teal-200',
    infoVal: 'text-white',
    fromDateVal: 'text-cyan-200',
    arrowColor: 'text-teal-300',
    toDateOk: 'text-emerald-300',
    toDateAlert: 'text-rose-300',
    statusPaid: 'bg-emerald-500/25 text-emerald-200 border border-emerald-400/40',
    statusDue: 'bg-amber-500/25 text-amber-200 border border-amber-400/40',
    statusOverdue: 'bg-rose-500/30 text-rose-200 border border-rose-400/40',
  },
  ivory: {
    id: 'ivory',
    label: 'Classic Ivory',
    swatchClass: 'bg-gradient-to-br from-stone-100 to-amber-100 ring-slate-400',
    outerFrame: 'bg-gradient-to-br from-slate-800 via-emerald-800 to-amber-600',
    cardBg: 'bg-gradient-to-br from-stone-50 via-white to-amber-50/70 text-slate-900',
    topStrip: 'bg-gradient-to-r from-emerald-700 via-teal-700 to-amber-500',
    divider: 'border-slate-200',
    brandIcon: 'text-emerald-700',
    brandTitle: 'text-slate-900',
    subtitle: 'text-slate-500',
    shiftBadge: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    photoFrame: 'bg-gradient-to-br from-emerald-600 via-teal-600 to-amber-500',
    studentName: 'text-slate-900',
    studentId: 'text-emerald-700',
    studentCourse: 'text-slate-600',
    statBoxDesk: 'bg-emerald-50 border-emerald-200',
    statLabelDesk: 'text-emerald-700',
    statValDesk: 'text-emerald-950',
    statBoxPin: 'bg-amber-50 border-amber-200',
    statLabelPin: 'text-amber-700',
    statValPin: 'text-amber-950',
    statBoxLocker: 'bg-slate-100 border-slate-200',
    statLabelLocker: 'text-slate-600',
    statValLocker: 'text-slate-900',
    qrFrame: 'bg-gradient-to-r from-emerald-600 via-teal-600 to-amber-500',
    qrLabel: 'text-emerald-800',
    infoPanel: 'bg-slate-50 border-slate-200',
    infoDivider: 'border-slate-200',
    infoIcon: 'text-emerald-600',
    infoLabel: 'text-slate-600',
    infoVal: 'text-slate-900',
    fromDateVal: 'text-slate-900',
    arrowColor: 'text-emerald-600',
    toDateOk: 'text-emerald-700',
    toDateAlert: 'text-rose-600',
    statusPaid: 'bg-emerald-100 text-emerald-800 border border-emerald-300',
    statusDue: 'bg-amber-100 text-amber-800 border border-amber-300',
    statusOverdue: 'bg-rose-100 text-rose-800 border border-rose-300',
  },
};

function formatIdDate(iso?: string): string {
  if (!iso) return 'Pending';
  const clean = iso.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return iso;
  const [year, monthStr, day] = parts;
  const monthIdx = parseInt(monthStr, 10) - 1;
  return `${day} ${MONTHS_SHORT[monthIdx] || monthStr} ${year}`;
}

interface StudentCardModalProps {
  student: Student | null;
  settings: LibrarySettings;
  isAdmin?: boolean;
  onRequireAdmin?: () => void;
  onClose: () => void;
  onEdit?: (student: Student) => void;
  onUpdatePhoto?: (studentId: string, photoDataUrl: string) => void;
}

export const StudentCardModal: React.FC<StudentCardModalProps> = ({
  student,
  settings,
  isAdmin = true,
  onRequireAdmin,
  onClose,
  onEdit,
  onUpdatePhoto,
}) => {
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [themeId, setThemeId] = useState<CardThemeId>(() => {
    try {
      const saved = localStorage.getItem(CARD_THEME_STORAGE_KEY) as CardThemeId | null;
      if (saved && saved in CARD_THEMES) return saved;
    } catch {
      // ignore storage errors
    }
    return 'monochrome';
  });

  useEffect(() => {
    if (student) {
      const scanPayload =
        typeof window !== 'undefined'
          ? `${window.location.origin}/?student_id=${encodeURIComponent(student.id)}`
          : student.id;
      generateQrDataUrl(scanPayload, 280).then(url => setQrUrl(url));
    }
  }, [student]);

  const handleSelectTheme = (id: CardThemeId) => {
    setThemeId(id);
    try {
      localStorage.setItem(CARD_THEME_STORAGE_KEY, id);
    } catch {
      // ignore storage errors
    }
  };

  if (!student) return null;

  const theme = CARD_THEMES[themeId] || CARD_THEMES.monochrome;
  const displayAvatarSrc = resolveStudentAvatar(student.avatarUrl);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}/?student_id=${encodeURIComponent(student.id)}`
    );
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenCamera = () => {
    if (!isAdmin) {
      onRequireAdmin?.();
      return;
    }
    setIsCameraOpen(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl my-auto max-h-[94vh] flex flex-col">
        {/* Top Modal Header */}
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between no-print bg-slate-50 dark:bg-slate-900 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <Shield className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Digital Library Pass</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full hover:bg-slate-200/70 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 transition-colors"
            aria-label="Close Digital Library Pass"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Card Colour Theme Switcher (no-print) */}
        <div className="px-4 sm:px-5 pt-3 pb-1 flex items-center justify-between gap-2 no-print shrink-0">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Card Colour</span>
          </span>
          <div className="flex items-center gap-2">
            {(Object.keys(CARD_THEMES) as CardThemeId[]).map((id) => {
              const option = CARD_THEMES[id];
              const isActive = themeId === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => handleSelectTheme(id)}
                  title={option.label}
                  aria-label={`Select ${option.label} ID card colour`}
                  className={`w-5 h-5 rounded-full border border-slate-300 dark:border-slate-600 transition-transform ${option.swatchClass} ${
                    isActive ? 'ring-2 ring-offset-2 dark:ring-offset-slate-900 scale-110' : 'opacity-75 hover:opacity-100 hover:scale-105'
                  }`}
                />
              );
            })}
          </div>
        </div>

        {/* Printable Pass Card */}
        <div className="p-4 sm:p-5 overflow-y-auto">
          <div className={`rounded-2xl p-[2px] shadow-xl ${theme.outerFrame}`}>
            <div className={`rounded-[14px] p-4 sm:p-5 relative overflow-hidden ${theme.cardBg}`}>
              {/* Top Accent Strip */}
              <div className={`absolute top-0 inset-x-0 h-1.5 ${theme.topStrip}`}></div>

              {/* Library Branding Bar */}
              <div className={`relative flex items-center justify-between border-b pb-3 mb-3.5 gap-2 pt-0.5 ${theme.divider}`}>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <Award className={`w-3.5 h-3.5 shrink-0 ${theme.brandIcon}`} />
                    <span className={`text-[11px] font-extrabold uppercase tracking-wider block truncate ${theme.brandTitle}`}>
                      {settings.name || 'Bharti Digital Library'}
                    </span>
                  </div>
                  <span className={`text-[10px] block mt-0.5 ${theme.subtitle}`}>
                    Honoured Scholar · Privilege ID Pass
                  </span>
                </div>
                <div
                  className={`px-2 py-0.5 rounded-md font-mono text-[9px] font-semibold border shrink-0 max-w-[145px] truncate ${theme.shiftBadge}`}
                  title={formatStudentShifts(student.shifts, student.shift)}
                >
                  {formatStudentShifts(student.shifts, student.shift)}
                </div>
              </div>

              {/* Student Photo & Identity */}
              <div className="relative flex items-center gap-3.5 mb-3.5">
                <div className={`p-[2px] rounded-xl shrink-0 shadow-md ${theme.photoFrame}`}>
                  <div className="w-16 h-16 rounded-[10px] overflow-hidden bg-slate-900 relative group">
                    <img
                      src={displayAvatarSrc}
                      alt={student.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    {onUpdatePhoto && (
                      <button
                        type="button"
                        onClick={handleOpenCamera}
                        className="no-print absolute bottom-1 right-1 w-6 h-6 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-md border border-white/40 transition-transform hover:scale-105"
                        title={isAdmin ? 'Capture Student Photo with Camera' : 'Admin PIN required to update photo'}
                      >
                        <Camera className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
                <div className="overflow-hidden">
                  <h4 className={`text-base font-extrabold truncate leading-tight tracking-tight ${theme.studentName}`}>
                    {student.name}
                  </h4>
                  <p className={`text-[11px] font-mono font-semibold mt-0.5 tabular-nums ${theme.studentId}`}>
                    ID: {student.id}
                  </p>
                  <p className={`text-[10px] truncate mt-0.5 ${theme.studentCourse}`}>
                    {student.courseOrExam || 'Dedicated Study Scholar'}
                  </p>
                </div>
              </div>

              {/* Desk, PIN & Locker Highlights */}
              <div className="relative grid grid-cols-3 gap-2 mb-3.5">
                <div className={`p-2 rounded-xl border text-center ${theme.statBoxDesk}`}>
                  <span className={`text-[9px] uppercase tracking-wider block ${theme.statLabelDesk}`}>Desk Slot</span>
                  <span className={`text-sm font-extrabold font-mono tabular-nums ${theme.statValDesk}`}>{student.assignedDesk}</span>
                </div>
                <div className={`p-2 rounded-xl border text-center ${theme.statBoxPin}`}>
                  <span className={`text-[9px] uppercase tracking-wider block ${theme.statLabelPin}`}>Kiosk PIN</span>
                  <span className={`text-sm font-extrabold font-mono tabular-nums ${theme.statValPin}`}>{student.pin}</span>
                </div>
                <div className={`p-2 rounded-xl border text-center ${theme.statBoxLocker}`}>
                  <span className={`text-[9px] uppercase tracking-wider block ${theme.statLabelLocker}`}>Locker</span>
                  <span className={`text-sm font-extrabold font-mono tabular-nums ${theme.statValLocker}`}>{student.lockerNumber || 'None'}</span>
                </div>
              </div>

              {/* Framed QR Code for Kiosk Entry */}
              <div className={`relative rounded-xl p-[2px] shadow-lg ${theme.qrFrame}`}>
                <div className="bg-white rounded-[10px] p-2.5 flex flex-col items-center justify-center text-slate-900">
                  {qrUrl ? (
                    <img src={qrUrl} alt={`QR for ${student.id}`} className="w-24 h-24 sm:w-28 sm:h-28" />
                  ) : (
                    <div className="w-24 h-24 sm:w-28 sm:h-28 bg-slate-100 flex items-center justify-center">
                      <QrCode className="w-10 h-10 text-slate-400" />
                    </div>
                  )}
                  <span className={`text-[9px] font-mono tracking-widest mt-1 uppercase font-bold ${theme.qrLabel}`}>
                    SCAN FOR FULL DETAILS & ENTRY
                  </span>
                </div>
              </div>

              {/* Admission, Payment Date & Card Validity From/To Section */}
              <div className={`relative mt-3 rounded-xl border p-2.5 space-y-2 ${theme.infoPanel}`}>
                <div className={`flex items-center justify-between text-[11px] border-b pb-1.5 gap-1 ${theme.infoDivider}`}>
                  <span className={`flex items-center gap-1 font-medium shrink-0 ${theme.infoLabel}`}>
                    <span>Admission Date</span>
                  </span>
                  <strong className={`font-mono tabular-nums ${theme.infoVal}`}>
                    {formatIdDate(student.joinedDate)}
                  </strong>
                </div>

                <div className={`flex items-center justify-between text-[11px] border-b pb-1.5 gap-1 ${theme.infoDivider}`}>
                  <span className={`flex items-center gap-1 font-medium shrink-0 ${theme.infoLabel}`}>
                    <IndianRupee className={`w-3 h-3 ${theme.infoIcon}`} />
                    <span>Payment Date</span>
                  </span>
                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    <strong className={`font-mono tabular-nums ${theme.infoVal}`}>
                      {student.lastPaymentDate ? formatIdDate(student.lastPaymentDate) : 'Not Paid'}
                    </strong>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide tabular-nums ${
                        student.paymentStatus === 'PAID'
                          ? theme.statusPaid
                          : student.paymentStatus === 'DUE_SOON'
                          ? theme.statusDue
                          : theme.statusOverdue
                      }`}
                    >
                      ₹{student.monthlyFee} · {student.paymentStatus.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] gap-1">
                  <span className={`flex items-center gap-1 font-medium shrink-0 ${theme.infoLabel}`}>
                    <CalendarRange className="w-3 h-3" />
                    <span>Card Validity</span>
                  </span>
                  <div className="text-right font-mono tabular-nums">
                    <span>
                      From <strong className={theme.fromDateVal}>{formatIdDate(student.cardValidFrom || student.lastPaymentDate || student.joinedDate)}</strong>
                    </span>
                    <span className={`mx-1 ${theme.arrowColor}`}>→</span>
                    <span>
                      To{' '}
                      <strong
                        className={
                          student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED'
                            ? theme.toDateAlert
                            : theme.toDateOk
                        }
                      >
                        {formatIdDate(student.renewalDueDate)}
                      </strong>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 no-print shrink-0">
          <button
            onClick={handlePrint}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
          {onUpdatePhoto && (
            <button
              type="button"
              onClick={handleOpenCamera}
              className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors"
              title="Capture Student Photo"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Photo</span>
            </button>
          )}
          {onEdit && (
            <button
              onClick={() => {
                onClose();
                onEdit(student);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Edit</span>
            </button>
          )}
          <button
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-1.5 py-2 px-2.5 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Copy Student Pass Link"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Share2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        studentName={student.name}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => {
          onUpdatePhoto?.(student.id, dataUrl);
        }}
      />
    </div>
  );
};
