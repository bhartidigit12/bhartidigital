import React from 'react';
import { Bell, QrCode, UserPlus, ShieldCheck, Lock, User } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadNotificationsCount: number;
  pendingApprovalsCount: number;
  onOpenNotifications: () => void;
  onOpenKiosk: () => void;
  onOpenRegister: () => void;
  onOpenSelfRegister: () => void;
  onOpenApprovals: () => void;
  isAdmin: boolean;
  onOpenAdminAuth: () => void;
  totalActiveCount: number;
  totalCapacity: number;
  libraryName?: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  unreadNotificationsCount,
  pendingApprovalsCount,
  onOpenNotifications,
  onOpenKiosk,
  onOpenRegister,
  onOpenSelfRegister,
  onOpenApprovals,
  isAdmin,
  onOpenAdminAuth,
  totalActiveCount,
  totalCapacity,
  libraryName = 'Bharti Digital Library',
}) => {
  const occupancyPercent = Math.round((totalActiveCount / totalCapacity) * 100);

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-2 md:gap-6">
        {/* Zone 1: Single text wordmark */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1 md:flex-initial">
          <button 
            onClick={() => setActiveTab('dashboard')} 
            className="flex items-center gap-2 sm:gap-2.5 text-left focus:outline-none group min-w-0"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base sm:text-lg shadow-sm group-hover:scale-105 transition-transform shrink-0">
              B
            </div>
            <div className="min-w-0">
              <span className="text-sm sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white truncate block leading-tight">
                {libraryName}
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 hidden sm:block">
                Study Sanctuary & Hub
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: 4-5 Clean single-line text links (Desktop/Tablet) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'dashboard'
                ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Live Hub
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'attendance'
                ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Attendance
          </button>
          {isAdmin && (
            <button
              onClick={() => setActiveTab('members')}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === 'members'
                  ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Members
            </button>
          )}
          <button
            onClick={() => setActiveTab('billing')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'billing'
                ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Billing
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'analytics'
                ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('student-portal')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'student-portal'
                ? 'text-slate-900 dark:text-white font-semibold border-b-2 border-indigo-600'
                : 'hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Student Portal
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + Quick Utilities */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          {/* Live Occupancy Status Badge */}
          <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>
              <strong className="font-mono tabular-nums text-slate-900 dark:text-white">{totalActiveCount}</strong>/{totalCapacity} Seated ({occupancyPercent}%)
            </span>
          </div>

          {/* Mobile Student Portal quick access */}
          <button
            onClick={() => setActiveTab('student-portal')}
            className={`md:hidden flex items-center gap-1 p-2 sm:px-2.5 sm:py-2 text-xs font-semibold rounded-lg transition-colors min-h-[36px] sm:min-h-[40px] ${
              activeTab === 'student-portal'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200'
            }`}
            title="Student Login & Online Fee Payment"
            aria-label="Student Login & Online Fee Payment"
          >
            <User className="w-4 h-4" />
            <span className="hidden sm:inline">Student</span>
          </button>

          {/* Student Self-Registration Portal button */}
          <button
            onClick={onOpenSelfRegister}
            className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 text-xs font-semibold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 rounded-lg transition-colors min-h-[36px] sm:min-h-[40px]"
            title="Open Student Self-Registration Form"
            aria-label="Student Self-Registration"
          >
            <UserPlus className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span className="hidden sm:inline">Self Register</span>
          </button>

          {/* Admin Approval Queue Button with Pending Badge */}
          <button
            onClick={onOpenApprovals}
            className="relative flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 rounded-lg transition-colors min-h-[36px] sm:min-h-[40px]"
            title="Review & Approve Student Applications"
            aria-label="Review & Approve Student Applications"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span className="hidden sm:inline">Approvals</span>
            {pendingApprovalsCount > 0 && (
              <span className="w-4 h-4 sm:w-5 sm:h-5 bg-amber-500 text-white rounded-full font-mono text-[10px] font-bold flex items-center justify-center shadow-xs">
                {pendingApprovalsCount}
              </span>
            )}
          </button>

          {/* Admin Lock / Active Mode Button */}
          <button
            onClick={onOpenAdminAuth}
            className={`flex items-center gap-1.5 p-2 sm:px-3 sm:py-2 text-xs font-semibold rounded-lg transition-colors min-h-[36px] sm:min-h-[40px] ${
              isAdmin
                ? 'bg-slate-900 dark:bg-emerald-600 text-white shadow-xs'
                : 'bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100'
            }`}
            title={isAdmin ? 'Admin Mode Active (Click to Lock or Change PIN)' : 'Unlock Admin Mode to Edit Student Details'}
            aria-label={isAdmin ? 'Admin Mode Active' : 'Unlock Admin Mode'}
          >
            {isAdmin ? <ShieldCheck className="w-4 h-4 text-emerald-400 dark:text-white" /> : <Lock className="w-4 h-4" />}
            <span className="hidden sm:inline">{isAdmin ? 'Admin Active' : 'Admin Lock'}</span>
          </button>

          {/* Kiosk Mode Button (Desktop/Tablet; mobile uses bottom nav center Kiosk button) */}
          <button
            onClick={onOpenKiosk}
            className="hidden md:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors min-h-[40px]"
            title="Launch Student Self-Check-in Kiosk"
          >
            <QrCode className="w-4 h-4 text-slate-600 dark:text-slate-400" />
            <span>Kiosk</span>
          </button>

          {/* Notifications Trigger */}
          <button
            onClick={onOpenNotifications}
            className="relative p-1.5 sm:p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors min-w-[36px] min-h-[36px] sm:min-w-[40px] sm:min-h-[40px] flex items-center justify-center"
            aria-label="View Push Reminders"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1 right-1 sm:top-1.5 sm:right-1.5 w-4 h-4 bg-rose-600 text-[10px] font-bold text-white rounded-full flex items-center justify-center">
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
