import React, { useState, useMemo, useEffect } from 'react';
import {
  User,
  KeyRound,
  LogOut,
  CreditCard,
  IndianRupee,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  QrCode,
  ShieldCheck,
  Printer,
  FileText,
  Smartphone,
  Building2,
  Eye,
  EyeOff,
  ArrowRight,
  Lock,
  Sparkles,
  UserPlus,
  Upload,
  Trash2,
  XCircle,
  LogIn,
} from 'lucide-react';
import {
  Student,
  AttendanceRecord,
  Invoice,
  LibrarySettings,
  formatStudentShifts,
} from '../types';
import { resolveStudentAvatar } from '../utils/assets';
import { PhonePeScannerCard } from './PhonePeScannerCard';
import { sounds } from '../utils/notifications';

interface StudentPortalViewProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  invoices: Invoice[];
  settings: LibrarySettings;
  isAdmin?: boolean;
  loggedInStudentId: string | null;
  onLoginStudent: (studentId: string) => void;
  onLogoutStudent: () => void;
  onSubmitPaymentRequest: (
    studentId: string,
    amount: number,
    method: 'UPI' | 'CARD',
    transactionRef: string,
    targetYearMonth?: string,
    proofImageUrl?: string
  ) => Invoice;
  onCheckInToggle?: (
    studentId: string,
    method: 'QR_SCAN' | 'PIN_KIOSK' | 'STAFF_MANUAL' | 'BIOMETRIC_SIM',
    customTimeHHMM?: string
  ) => {
    success: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
    message?: string;
  };
  onViewStudentCard: (student: Student) => void;
  onOpenSelfRegister: () => void;
  onOpenKiosk: () => void;
  onOpenKioskQr?: () => void;
}

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatDateReadable(iso?: string): string {
  if (!iso) return '—';
  const clean = iso.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return iso;
  const [y, m, d] = parts;
  return `${d} ${MONTHS_SHORT[parseInt(m, 10) - 1] || m} ${y}`;
}

function getLocalTodayStr(): string {
  const dt = new Date();
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

function getCurrentHHMM(): string {
  const dt = new Date();
  return `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
}

function extractLocalHHMM(isoStr?: string): string {
  if (!isoStr) return '';
  if (isoStr.endsWith('Z')) {
    const dt = new Date(isoStr);
    if (!Number.isNaN(dt.getTime())) {
      return `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
    }
  }
  if (isoStr.includes('T')) {
    return isoStr.split('T')[1].substring(0, 5);
  }
  return isoStr.slice(0, 5);
}

function formatTime12h(isoOrHHMM?: string): string {
  const hhmm = extractLocalHHMM(isoOrHHMM);
  if (!hhmm || !hhmm.includes(':')) return '--:--';
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  const m = Number(mStr);
  if (Number.isNaN(h) || Number.isNaN(m)) return hhmm;
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${String(hour12).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
}

function normalizePhone(raw: string): string {
  return raw.replace(/\D/g, '').slice(-10);
}

export const StudentPortalView: React.FC<StudentPortalViewProps> = ({
  students,
  attendanceRecords,
  invoices,
  settings,
  isAdmin = false,
  loggedInStudentId,
  onLoginStudent,
  onLogoutStudent,
  onSubmitPaymentRequest,
  onCheckInToggle,
  onViewStudentCard,
  onOpenSelfRegister,
  onOpenKiosk,
  onOpenKioskQr,
}) => {
  // Login form states
  const [identifier, setIdentifier] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [markInOnLogin, setMarkInOnLogin] = useState(false);

  // Login-page direct attendance system states
  const [attIdentifier, setAttIdentifier] = useState('');
  const [attPin, setAttPin] = useState('');
  const [attTimeInput, setAttTimeInput] = useState<string>(() => getCurrentHHMM());
  const [attError, setAttError] = useState('');
  const [attConfirmation, setAttConfirmation] = useState<{
    student: Student;
    action: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
  } | null>(null);

  // Logged-in dashboard states
  const [portalTab, setPortalTab] = useState<'OVERVIEW' | 'PAY_FEE' | 'ATTENDANCE' | 'RECEIPTS'>('OVERVIEW');
  const [showPin, setShowPin] = useState(false);
  const [attendanceTimeInput, setAttendanceTimeInput] = useState<string>(() => getCurrentHHMM());
  const [attendanceActionNote, setAttendanceActionNote] = useState<string>('');

  // Online fee payment states
  const now = new Date();
  const currentYM = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const [selectedPayMonth, setSelectedPayMonth] = useState<string>(currentYM);
  const [payMethod, setPayMethod] = useState<'UPI' | 'CARD' | 'NETBANKING'>('UPI');
  const [utrNumber, setUtrNumber] = useState('');
  const [proofImageUrl, setProofImageUrl] = useState<string | undefined>(undefined);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [selectedBank, setSelectedBank] = useState('State Bank of India (SBI)');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState('');
  const [latestReceipt, setLatestReceipt] = useState<Invoice | null>(null);
  const [receiptModalInvoice, setReceiptModalInvoice] = useState<Invoice | null>(null);

  const activeStudent = useMemo(
    () => (loggedInStudentId ? students.find(s => s.id === loggedInStudentId) || null : null),
    [students, loggedInStudentId]
  );

  // Demo quick-login samples (one overdue, one paid) for frictionless exploration
  const demoOverdueStudent = useMemo(
    () => students.find(s => s.paymentStatus === 'OVERDUE') || students[0],
    [students]
  );
  const demoPaidStudent = useMemo(
    () => students.find(s => s.paymentStatus === 'PAID') || students[1] || students[0],
    [students]
  );

  // Student-specific attendance and invoices
  const studentAttendance = useMemo(() => {
    if (!activeStudent) return [];
    return attendanceRecords
      .filter(r => r.studentId === activeStudent.id)
      .sort((a, b) => b.checkInTime.localeCompare(a.checkInTime));
  }, [attendanceRecords, activeStudent]);

  const studentInvoices = useMemo(() => {
    if (!activeStudent) return [];
    return invoices
      .filter(inv => inv.studentId === activeStudent.id)
      .sort((a, b) => b.paidDate.localeCompare(a.paidDate));
  }, [invoices, activeStudent]);

  // Month options (current year Jan–Dec) with paid/unpaid flag
  const monthOptions = useMemo(() => {
    const yr = now.getFullYear();
    return MONTHS_SHORT.map((shortLabel, idx) => {
      const ym = `${yr}-${String(idx + 1).padStart(2, '0')}`;
      const isPaid = studentInvoices.some(
        inv => inv.status === 'PAID' && (inv.periodStart ? inv.periodStart.startsWith(ym) : inv.paidDate.startsWith(ym))
      );
      return {
        ym,
        label: `${shortLabel} ${yr}`,
        isPaid,
      };
    });
  }, [studentInvoices]);

  const liveMatchedAttStudent = useMemo(() => {
    const rawId = attIdentifier.trim().toLowerCase();
    const cleanPhone = normalizePhone(attIdentifier);
    const cleanPin = attPin.trim();
    if (!rawId || cleanPin.length !== 4) return null;
    return (
      students.find(s => {
        const idMatch = s.id.toLowerCase() === rawId;
        const phoneMatch = cleanPhone.length === 10 && normalizePhone(s.phone) === cleanPhone;
        return (idMatch || phoneMatch) && s.pin === cleanPin;
      }) || null
    );
  }, [students, attIdentifier, attPin]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const rawId = identifier.trim().toLowerCase();
    const cleanPhone = normalizePhone(identifier);
    const cleanPin = pinInput.trim();

    if (!rawId || !cleanPin) {
      setLoginError('Please enter your Student ID (or Mobile No.) and 4-digit PIN.');
      return;
    }

    const matched = students.find(s => {
      const idMatch = s.id.toLowerCase() === rawId;
      const phoneMatch = cleanPhone.length === 10 && normalizePhone(s.phone) === cleanPhone;
      return (idMatch || phoneMatch) && s.pin === cleanPin;
    });

    if (!matched) {
      sounds.playAlert();
      setLoginError('Invalid Student ID / Mobile or PIN. Check your Library ID Pass and try again.');
      return;
    }

    if (markInOnLogin && matched.attendanceStatus === 'CHECKED_OUT' && onCheckInToggle) {
      const res = onCheckInToggle(matched.id, 'PIN_KIOSK', getCurrentHHMM());
      if (res.success) {
        setAttendanceActionNote(`Checked In automatically on sign-in at ${formatTime12h(res.inTime)}.`);
      }
    }

    sounds.playSuccess();
    setIdentifier('');
    setPinInput('');
    setLatestReceipt(null);
    setPortalTab(matched.paymentStatus === 'OVERDUE' || matched.paymentStatus === 'DUE_SOON' ? 'PAY_FEE' : 'OVERVIEW');
    onLoginStudent(matched.id);
  };

  const handleLoginPageAttendanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAttError('');
    const rawId = attIdentifier.trim().toLowerCase();
    const cleanPhone = normalizePhone(attIdentifier);
    const cleanPin = attPin.trim();

    if (!rawId || cleanPin.length !== 4) {
      sounds.playAlert();
      setAttError('Enter your Student ID (or 10-digit Mobile) and 4-digit PIN.');
      return;
    }

    const matched = students.find(s => {
      const idMatch = s.id.toLowerCase() === rawId;
      const phoneMatch = cleanPhone.length === 10 && normalizePhone(s.phone) === cleanPhone;
      return (idMatch || phoneMatch) && s.pin === cleanPin;
    });

    if (!matched) {
      sounds.playAlert();
      setAttError('No matching student found. Verify your Student ID / Mobile and 4-digit PIN.');
      return;
    }

    if (!onCheckInToggle) {
      onOpenKiosk();
      return;
    }

    const chosenTime = attTimeInput || getCurrentHHMM();
    const res = onCheckInToggle(matched.id, 'PIN_KIOSK', chosenTime);
    if (res.success && res.action) {
      if (res.action === 'IN') {
        sounds.playSuccess();
      } else {
        sounds.playCheckOut();
      }
      setAttConfirmation({
        student: res.student || matched,
        action: res.action,
        inTime: res.inTime,
        outTime: res.outTime,
        durationMinutes: res.durationMinutes,
      });
      setAttTimeInput(getCurrentHHMM());
    }
  };

  const handleQuickDemoLogin = (student: Student, targetTab: 'OVERVIEW' | 'PAY_FEE' = 'OVERVIEW') => {
    sounds.playSuccess();
    setLoginError('');
    setLatestReceipt(null);
    setPortalTab(targetTab);
    onLoginStudent(student.id);
  };

  const handlePayOnline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) return;
    setPaymentError('');

    let finalRef = '';

    if (payMethod === 'UPI') {
      const cleanUtr = utrNumber.replace(/\D/g, '');
      if (cleanUtr.length !== 12) {
        sounds.playAlert();
        setPaymentError('Please enter a valid 12-digit UTR / Reference Number from your PhonePe, GPay, or Paytm payment receipt.');
        return;
      }
      if (
        /^(\d)\1{11}$/.test(cleanUtr) ||
        cleanUtr === '123456789012' ||
        cleanUtr === '987654321012' ||
        cleanUtr === '012345678901'
      ) {
        sounds.playAlert();
        setPaymentError('Test or repeated digits (e.g. 123456789012) cannot be accepted. Enter your real 12-digit UPI UTR number.');
        return;
      }
      const duplicate = invoices.find(
        inv =>
          inv.transactionRef.replace(/\D/g, '') === cleanUtr &&
          (inv.status === 'PAID' || inv.status === 'PENDING')
      );
      if (duplicate) {
        sounds.playAlert();
        setPaymentError(`UTR ${cleanUtr} has already been submitted (${duplicate.id}). Please enter your new payment UTR.`);
        return;
      }
      finalRef = cleanUtr;
    } else if (payMethod === 'CARD') {
      const digits = cardNumber.replace(/\D/g, '');
      if (digits.length < 12) {
        setPaymentError('Please enter a valid card number.');
        return;
      }
      if (!cardExpiry.trim() || cardCvv.trim().length < 3) {
        setPaymentError('Please enter card expiry (MM/YY) and 3-digit CVV.');
        return;
      }
      finalRef = `CARD${digits.slice(-4)}${Math.floor(100000 + Math.random() * 900000)}`;
    } else {
      finalRef = `NB${Date.now().toString().slice(-8)}`;
    }

    setIsProcessingPayment(true);
    setTimeout(() => {
      const mappedMethod: 'UPI' | 'CARD' = payMethod === 'CARD' ? 'CARD' : 'UPI';
      const submittedInvoice = onSubmitPaymentRequest(
        activeStudent.id,
        activeStudent.monthlyFee,
        mappedMethod,
        finalRef,
        selectedPayMonth,
        proofImageUrl
      );
      setIsProcessingPayment(false);
      setLatestReceipt(submittedInvoice);
      setUtrNumber('');
      setProofImageUrl(undefined);
      setCardNumber('');
      setCardExpiry('');
      setCardCvv('');
      sounds.playSuccess();
    }, 450);
  };

  // ============================================================================
  // UNAUTHENTICATED VIEW: STUDENT LOGIN + QUICK ATTENDANCE SYSTEM
  // ============================================================================
  if (!activeStudent) {
    const loginTodayStr = getLocalTodayStr();
    return (
      <div className="py-4 sm:py-8 pb-24 md:pb-12">
        <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
          {/* Card 1: Student Dashboard Login */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
                    Student Dashboard Login
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {settings.name} · Profile, attendance &amp; online fee payment
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Student ID or Registered Mobile No.
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={identifier}
                    onChange={e => {
                      setIdentifier(e.target.value);
                      setLoginError('');
                    }}
                    placeholder="e.g. LIB-1001 or 9876500000"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  4-Digit Entry PIN
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={4}
                    required
                    value={pinInput}
                    onChange={e => {
                      setPinInput(e.target.value);
                      setLoginError('');
                    }}
                    placeholder="••••"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tracking-widest text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                  />
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
                  Your Student ID and 4-digit PIN are printed on your Digital Library Pass.
                </p>
              </div>

              <label className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/70 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={markInOnLogin}
                  onChange={e => setMarkInOnLogin(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  Also mark today&apos;s In-Time attendance on sign-in
                </span>
              </label>

              {loginError && (
                <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{loginError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors min-h-[44px]"
              >
                <span>Sign In to Student Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Quick Sample Accounts visible to Admin Only */}
              {isAdmin && (demoOverdueStudent || demoPaidStudent) && (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block">
                    Admin Quick Student Sign-In
                  </span>
                  <div className="grid grid-cols-1 gap-2">
                    {demoOverdueStudent && (
                      <button
                        type="button"
                        onClick={() => handleQuickDemoLogin(demoOverdueStudent, 'PAY_FEE')}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-left flex items-center justify-between gap-2 transition-colors"
                      >
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                            {demoOverdueStudent.name}
                          </span>
                          <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                            {demoOverdueStudent.id} · PIN {demoOverdueStudent.pin} · Due ₹{demoOverdueStudent.monthlyFee}
                          </span>
                        </div>
                        <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 whitespace-nowrap shrink-0">
                          Login &amp; Pay →
                        </span>
                      </button>
                    )}

                    {demoPaidStudent && demoPaidStudent.id !== demoOverdueStudent?.id && (
                      <button
                        type="button"
                        onClick={() => handleQuickDemoLogin(demoPaidStudent, 'OVERVIEW')}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-left flex items-center justify-between gap-2 transition-colors"
                      >
                        <div className="min-w-0">
                          <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                            {demoPaidStudent.name}
                          </span>
                          <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                            {demoPaidStudent.id} · PIN {demoPaidStudent.pin} · Active Paid
                          </span>
                        </div>
                        <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap shrink-0">
                          Open Profile →
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={onOpenSelfRegister}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>New student? Register for a library seat</span>
                </button>
              </div>
            </form>
          </div>

          {/* Card 2: Student Quick Attendance System right on Login Page */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-sm">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 bg-emerald-50/70 dark:bg-emerald-950/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
                    Daily Attendance System
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Mark In-Time or Out-Time directly · {formatDateReadable(loginTodayStr)}
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {attConfirmation ? (
                <div className="space-y-4">
                  <div
                    className={`p-4 rounded-2xl border flex items-center gap-3 ${
                      attConfirmation.action === 'IN'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
                        : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full shrink-0 flex items-center justify-center text-white ${
                        attConfirmation.action === 'IN' ? 'bg-emerald-600' : 'bg-blue-600'
                      }`}
                    >
                      {attConfirmation.action === 'IN' ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <LogOut className="w-5 h-5" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <span
                        className={`text-xs font-extrabold uppercase tracking-wider block ${
                          attConfirmation.action === 'IN'
                            ? 'text-emerald-700 dark:text-emerald-300'
                            : 'text-blue-700 dark:text-blue-300'
                        }`}
                      >
                        {attConfirmation.action === 'IN'
                          ? 'Attendance Marked · In-Time Recorded'
                          : 'Out-Time Marked · Session Completed'}
                      </span>
                      <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
                        {attConfirmation.student.name} ({attConfirmation.student.id} · Desk {attConfirmation.student.assignedDesk})
                      </p>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 font-mono text-xs space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">In Time:</span>
                      <strong className="text-emerald-600 dark:text-emerald-400">
                        {formatTime12h(attConfirmation.inTime)}
                      </strong>
                    </div>
                    {attConfirmation.action === 'OUT' && (
                      <>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Out Time:</span>
                          <strong className="text-indigo-600 dark:text-indigo-400">
                            {formatTime12h(attConfirmation.outTime)}
                          </strong>
                        </div>
                        {attConfirmation.durationMinutes !== undefined && (
                          <div className="flex justify-between pt-1.5 border-t border-slate-200 dark:border-slate-700">
                            <span className="text-slate-500">Study Duration:</span>
                            <strong className="text-slate-900 dark:text-white">
                              {Math.floor(attConfirmation.durationMinutes / 60)}h {attConfirmation.durationMinutes % 60}m
                            </strong>
                          </div>
                        )}
                      </>
                    )}
                    <div className="flex justify-between pt-1.5 border-t border-slate-200 dark:border-slate-700">
                      <span className="text-slate-500">Monthly Visits:</span>
                      <strong className="text-slate-900 dark:text-white">
                        {attConfirmation.student.totalVisitsThisMonth} days
                      </strong>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const targetId = attConfirmation.student.id;
                        setAttConfirmation(null);
                        setAttIdentifier('');
                        setAttPin('');
                        setPortalTab('ATTENDANCE');
                        onLoginStudent(targetId);
                      }}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 min-h-[42px]"
                    >
                      <span>Open My Student Dashboard</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setAttConfirmation(null);
                        setAttIdentifier('');
                        setAttPin('');
                        setAttTimeInput(getCurrentHHMM());
                      }}
                      className="py-2.5 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 min-h-[42px]"
                    >
                      Next Student
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleLoginPageAttendanceSubmit} className="space-y-3.5">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                      Student ID or Registered Mobile No.
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        required
                        value={attIdentifier}
                        onChange={e => {
                          setAttIdentifier(e.target.value);
                          setAttError('');
                        }}
                        placeholder="e.g. LIB-1001 or 9876500000"
                        className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[44px]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                        4-Digit PIN
                      </label>
                      <div className="relative">
                        <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="password"
                          inputMode="numeric"
                          maxLength={4}
                          required
                          value={attPin}
                          onChange={e => {
                            setAttPin(e.target.value);
                            setAttError('');
                          }}
                          placeholder="••••"
                          className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tracking-widest text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[44px]"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                        {liveMatchedAttStudent?.attendanceStatus === 'CHECKED_IN' ? 'Out Time' : 'In Time'}
                      </label>
                      <input
                        type="time"
                        value={attTimeInput}
                        onChange={e => setAttTimeInput(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[44px]"
                      />
                    </div>
                  </div>

                  {/* Live Verified Student Status Pill */}
                  {liveMatchedAttStudent && (
                    <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
                      <img
                        src={resolveStudentAvatar(liveMatchedAttStudent.avatarUrl)}
                        alt={liveMatchedAttStudent.name}
                        className="w-10 h-10 rounded-xl object-cover shrink-0 bg-slate-200"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {liveMatchedAttStudent.name}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          Desk {liveMatchedAttStudent.assignedDesk} ·{' '}
                          {liveMatchedAttStudent.attendanceStatus === 'CHECKED_IN'
                            ? `Inside since ${formatTime12h(liveMatchedAttStudent.currentCheckInTime)}`
                            : 'Currently Checked Out'}
                        </div>
                      </div>
                    </div>
                  )}

                  {attError && (
                    <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{attError}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className={`w-full py-3 rounded-xl text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors min-h-[44px] ${
                      liveMatchedAttStudent?.attendanceStatus === 'CHECKED_IN'
                        ? 'bg-indigo-600 hover:bg-indigo-700'
                        : 'bg-emerald-600 hover:bg-emerald-700'
                    }`}
                  >
                    {liveMatchedAttStudent?.attendanceStatus === 'CHECKED_IN' ? (
                      <>
                        <LogOut className="w-4 h-4" />
                        <span>Mark Out-Time (Check Out)</span>
                      </>
                    ) : (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>Mark In-Time / Out-Time</span>
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* Scan Kiosk QR Pass Option */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <button
                  type="button"
                  onClick={() => (onOpenKioskQr ? onOpenKioskQr() : onOpenKiosk())}
                  className="w-full py-2.5 px-4 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50/80 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors min-h-[44px]"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Scan Student ID QR with Kiosk Camera</span>
                </button>
                <p className="text-[11px] text-center text-slate-500 dark:text-slate-400">
                  Mandatory: Mark In-Time on entry &amp; Out-Time when leaving the reading hall.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================================================
  // AUTHENTICATED VIEW: PERSONAL STUDENT DASHBOARD
  // ============================================================================
  const isFeePending = activeStudent.paymentStatus === 'OVERDUE' || activeStudent.paymentStatus === 'DUE_SOON';
  const todayDateStr = getLocalTodayStr();
  const todaySessions = studentAttendance.filter(r => r.checkInTime.slice(0, 10) === todayDateStr);
  const isInsideNow = activeStudent.attendanceStatus === 'CHECKED_IN';
  const latestTodayCompleted = todaySessions.find(r => Boolean(r.checkOutTime));

  const handleMarkMyAttendance = () => {
    if (!onCheckInToggle) {
      onOpenKiosk();
      return;
    }
    const chosenTime = attendanceTimeInput || getCurrentHHMM();
    const res = onCheckInToggle(activeStudent.id, 'PIN_KIOSK', chosenTime);
    if (res.success) {
      if (res.action === 'IN') {
        sounds.playSuccess();
        setAttendanceActionNote(`Checked In today at ${formatTime12h(res.inTime || chosenTime)}. Remember to mark Out-Time when leaving.`);
      } else {
        sounds.playCheckOut();
        const durText = res.durationMinutes
          ? `${Math.floor(res.durationMinutes / 60)}h ${res.durationMinutes % 60}m`
          : '';
        setAttendanceActionNote(`Checked Out at ${formatTime12h(res.outTime || chosenTime)}${durText ? ` (${durText})` : ''}.`);
      }
      setAttendanceTimeInput(getCurrentHHMM());
    }
  };

  return (
    <div className="space-y-5 pb-24 md:pb-10">
      {/* Personal Student Identity Header */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <div className="w-16 h-16 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0">
              <img
                src={resolveStudentAvatar(activeStudent.avatarUrl)}
                alt={activeStudent.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                <span className="font-semibold text-indigo-600 dark:text-indigo-400">{activeStudent.id}</span>
                <span aria-hidden="true">·</span>
                <span>Desk {activeStudent.assignedDesk}</span>
                <span aria-hidden="true">·</span>
                <span>Admitted {formatDateReadable(activeStudent.joinedDate)}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate mt-0.5">
                Welcome, {activeStudent.name}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                {activeStudent.courseOrExam || 'Study Hall Member'} · {formatStudentShifts(activeStudent.shifts, activeStudent.shift)}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onViewStudentCard(activeStudent)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors whitespace-nowrap min-h-[42px]"
            >
              <QrCode className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Digital ID Card</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setLatestReceipt(null);
                setPortalTab('PAY_FEE');
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors whitespace-nowrap min-h-[42px]"
            >
              <IndianRupee className="w-4 h-4" />
              <span>{isFeePending ? `Pay Fee ₹${activeStudent.monthlyFee}` : 'Pay / Renew Online'}</span>
            </button>

            <button
              type="button"
              onClick={onLogoutStudent}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold transition-colors whitespace-nowrap min-h-[42px]"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>

        {/* 4-Column KPI Summary Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 border border-slate-200 dark:border-slate-800 rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800 bg-slate-50/60 dark:bg-slate-800/30">
          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Membership Fee Status</span>
            <div className="mt-1 flex items-center gap-1.5">
              {activeStudent.paymentStatus === 'PAID' ? (
                <span className="text-base font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Paid & Active</span>
                </span>
              ) : activeStudent.paymentStatus === 'DUE_SOON' ? (
                <span className="text-base font-bold text-amber-600 dark:text-amber-400 flex items-center gap-1">
                  <Clock className="w-4 h-4 shrink-0" />
                  <span>Due Soon</span>
                </span>
              ) : (
                <span className="text-base font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Fee Overdue</span>
                </span>
              )}
            </div>
            <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 block mt-0.5">
              Valid till {formatDateReadable(activeStudent.renewalDueDate)}
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Monthly Fee Rate</span>
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
              ₹{activeStudent.monthlyFee.toLocaleString('en-IN')}
              <span className="text-xs font-normal text-slate-500 dark:text-slate-400"> / mo</span>
            </div>
            <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 block mt-0.5">
              Last paid: {formatDateReadable(activeStudent.lastPaymentDate)}
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Assigned Desk & Locker</span>
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900 dark:text-white mt-0.5">
              {activeStudent.assignedDesk}
            </div>
            <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 block mt-0.5">
              Locker: {activeStudent.lockerNumber || 'Not Assigned'}
            </span>
          </div>

          <div className="p-3.5">
            <span className="text-xs text-slate-500 dark:text-slate-400 block">Attendance Summary</span>
            <div className="text-xl font-bold font-mono tabular-nums text-indigo-600 dark:text-indigo-400 mt-0.5">
              {activeStudent.totalVisitsThisMonth} visits
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5">
              {activeStudent.attendanceStatus === 'CHECKED_IN' ? 'Currently Checked In' : 'Checked Out'}
            </span>
          </div>
        </div>
      </div>

      {/* Mandatory Daily Attendance (In-Time & Out-Time) Card */}
      <div
        className={`p-4 sm:p-5 rounded-2xl border flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
          isInsideNow
            ? 'bg-indigo-50/80 dark:bg-indigo-950/35 border-indigo-200 dark:border-indigo-900/60'
            : todaySessions.length === 0
            ? 'bg-amber-50/90 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60'
            : 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-200 dark:border-emerald-900/50'
        }`}
      >
        <div className="flex items-start gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              isInsideNow
                ? 'bg-indigo-600 text-white'
                : todaySessions.length === 0
                ? 'bg-amber-500 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            {isInsideNow ? (
              <Clock className="w-5 h-5" />
            ) : todaySessions.length === 0 ? (
              <LogIn className="w-5 h-5" />
            ) : (
              <CheckCircle2 className="w-5 h-5" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {isInsideNow
                  ? `Inside Reading Hall · Checked In at ${formatTime12h(activeStudent.currentCheckInTime || todaySessions[0]?.checkInTime)}`
                  : todaySessions.length === 0
                  ? 'Mandatory Daily Attendance — Mark Your In-Time'
                  : "Today's Attendance Completed ✓"}
              </h3>
              <span className="text-[11px] font-mono tabular-nums px-2 py-0.5 rounded bg-white/80 dark:bg-slate-900/80 border border-slate-200/80 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold">
                {formatDateReadable(todayDateStr)}
              </span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
              {isInsideNow
                ? 'Out-Time is necessary before leaving the library. Confirm your exit time and tap Check Out.'
                : todaySessions.length === 0
                ? 'Every student must record In-Time on arrival and Out-Time on departure.'
                : `Logged In: ${formatTime12h(latestTodayCompleted?.checkInTime)} → Out: ${formatTime12h(latestTodayCompleted?.checkOutTime)} (${
                    latestTodayCompleted?.durationMinutes
                      ? `${Math.floor(latestTodayCompleted.durationMinutes / 60)}h ${latestTodayCompleted.durationMinutes % 60}m`
                      : 'Completed'
                  })`}
            </p>
            {attendanceActionNote && (
              <p className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-300 mt-1">
                {attendanceActionNote}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 min-h-[42px]">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              {isInsideNow ? 'Out Time:' : 'In Time:'}
            </span>
            <input
              type="time"
              value={attendanceTimeInput}
              onChange={e => setAttendanceTimeInput(e.target.value)}
              className="bg-transparent text-xs font-mono tabular-nums font-bold text-slate-900 dark:text-white focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={handleMarkMyAttendance}
            className={`px-4 py-2.5 rounded-xl text-white text-xs font-bold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap min-h-[42px] ${
              isInsideNow
                ? 'bg-indigo-600 hover:bg-indigo-700'
                : todaySessions.length === 0
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-slate-800 hover:bg-slate-900 dark:bg-indigo-600 dark:hover:bg-indigo-700'
            }`}
          >
            {isInsideNow ? (
              <>
                <LogOut className="w-4 h-4" />
                <span>Mark Out-Time (Check Out)</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4" />
                <span>{todaySessions.length === 0 ? 'Mark In-Time (Check In)' : '+ Check In Again'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Urgent Overdue / Due Soon Banner */}
      {isFeePending && portalTab !== 'PAY_FEE' && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-rose-900 dark:text-rose-200">
                Your library fee of ₹{activeStudent.monthlyFee.toLocaleString('en-IN')} is {activeStudent.paymentStatus === 'OVERDUE' ? 'overdue' : 'due soon'}
              </h3>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">
                Pay online via UPI, Card, or Net Banking to renew Desk {activeStudent.assignedDesk} immediately and update your Digital ID Card.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setLatestReceipt(null);
              setPortalTab('PAY_FEE');
            }}
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold whitespace-nowrap shrink-0 min-h-[42px]"
          >
            Pay ₹{activeStudent.monthlyFee} Online →
          </button>
        </div>
      )}

      {/* Segmented Workspace Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 dark:bg-slate-800/80 rounded-2xl w-fit">
        <button
          type="button"
          onClick={() => setPortalTab('OVERVIEW')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            portalTab === 'OVERVIEW'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <User className="w-4 h-4 text-indigo-600" />
          <span>My Details</span>
        </button>

        <button
          type="button"
          onClick={() => setPortalTab('PAY_FEE')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            portalTab === 'PAY_FEE'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <CreditCard className="w-4 h-4 text-emerald-600" />
          <span>Pay Fee Online</span>
        </button>

        <button
          type="button"
          onClick={() => setPortalTab('ATTENDANCE')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            portalTab === 'ATTENDANCE'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4 text-indigo-600" />
          <span>My Attendance ({studentAttendance.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setPortalTab('RECEIPTS')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
            portalTab === 'RECEIPTS'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4 text-slate-500" />
          <span>Fee Receipts ({studentInvoices.length})</span>
        </button>
      </div>

      {/* TAB 1: STUDENT PROFILE DETAILS */}
      {portalTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Complete Personal & Seat Information */}
          <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Student Profile & Desk Allocation
              </h3>
              <button
                type="button"
                onClick={() => onViewStudentCard(activeStudent)}
                className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                Open Digital Pass →
              </button>
            </div>

            <dl className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Full Name</dt>
                <dd className="font-semibold text-slate-900 dark:text-white text-right">{activeStudent.name}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Student ID</dt>
                <dd className="font-mono tabular-nums font-bold text-indigo-600 dark:text-indigo-400">{activeStudent.id}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Kiosk / Portal PIN</dt>
                <dd className="flex items-center gap-2 font-mono tabular-nums font-bold text-slate-900 dark:text-white">
                  <span>{showPin ? activeStudent.pin : '••••'}</span>
                  <button
                    type="button"
                    onClick={() => setShowPin(v => !v)}
                    className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    title={showPin ? 'Hide PIN' : 'Show PIN'}
                  >
                    {showPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Mobile Number</dt>
                <dd className="font-mono tabular-nums text-slate-900 dark:text-white text-right">{activeStudent.phone}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Email Address</dt>
                <dd className="text-slate-900 dark:text-white text-right truncate">{activeStudent.email}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Exam / Course Focus</dt>
                <dd className="font-medium text-slate-900 dark:text-white text-right">{activeStudent.courseOrExam || 'Self Study'}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Shift Timing</dt>
                <dd className="font-medium text-slate-900 dark:text-white text-right">
                  {formatStudentShifts(activeStudent.shifts, activeStudent.shift)}
                </dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Admission Date</dt>
                <dd className="font-mono tabular-nums text-slate-900 dark:text-white">{formatDateReadable(activeStudent.joinedDate)}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-slate-500 dark:text-slate-400">Card Validity</dt>
                <dd className="font-mono tabular-nums text-slate-900 dark:text-white">
                  {formatDateReadable(activeStudent.cardValidFrom || activeStudent.joinedDate)} → {formatDateReadable(activeStudent.renewalDueDate)}
                </dd>
              </div>
            </dl>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
              Need to update your seat, shift, or phone number? Contact Admin {settings.ownerName} at {settings.phone}.
            </p>
          </div>

          {/* Membership Billing Summary + Recent Visits */}
          <div className="space-y-5">
            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Fee & Membership Validity
                </h3>
                <span className="text-xs font-mono tabular-nums font-bold text-slate-700 dark:text-slate-300">
                  ₹{activeStudent.monthlyFee} / month
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 block">Last Payment Date</span>
                  <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-white block mt-1">
                    {formatDateReadable(activeStudent.lastPaymentDate)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 block">Next Renewal Due</span>
                  <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-white block mt-1">
                    {formatDateReadable(activeStudent.renewalDueDate)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setLatestReceipt(null);
                  setPortalTab('PAY_FEE');
                }}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors min-h-[44px]"
              >
                <CreditCard className="w-4 h-4" />
                <span>Pay Monthly Fee Online (UPI / Card / Net Banking)</span>
              </button>
            </div>

            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Recent Library Visits</h3>
                <button
                  type="button"
                  onClick={() => setPortalTab('ATTENDANCE')}
                  className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  View All
                </button>
              </div>
              {studentAttendance.length === 0 ? (
                <p className="text-xs text-slate-500 py-3">No visits logged yet.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {studentAttendance.slice(0, 4).map(rec => (
                    <div key={rec.id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {formatDateReadable(rec.checkInTime.slice(0, 10))}
                        </span>
                        <span className="text-slate-500 dark:text-slate-400 ml-2">
                          In: {formatTime12h(rec.checkInTime)} → Out: {rec.checkOutTime ? formatTime12h(rec.checkOutTime) : 'Inside (Out Pending)'}
                        </span>
                      </div>
                      <span className="font-mono tabular-nums font-semibold text-slate-600 dark:text-slate-400">
                        {rec.durationMinutes ? `${Math.floor(rec.durationMinutes / 60)}h ${rec.durationMinutes % 60}m` : 'Active'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ONLINE FEE PAYMENT GATEWAY */}
      {portalTab === 'PAY_FEE' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          {latestReceipt ? (
            (() => {
              const liveReceipt = invoices.find(inv => inv.id === latestReceipt.id) || latestReceipt;
              const isVerified = liveReceipt.status === 'PAID';
              const isRejected = liveReceipt.status === 'OVERDUE';
              return (
                <div className="p-6 sm:p-8 max-w-lg mx-auto text-center space-y-5">
                  <div
                    className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                      isVerified
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
                        : isRejected
                        ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                        : 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400'
                    }`}
                  >
                    {isVerified ? (
                      <CheckCircle2 className="w-9 h-9" />
                    ) : isRejected ? (
                      <XCircle className="w-9 h-9" />
                    ) : (
                      <Clock className="w-9 h-9" />
                    )}
                  </div>

                  <div>
                    <span
                      className={`text-xs font-bold uppercase tracking-wider ${
                        isVerified
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : isRejected
                          ? 'text-rose-600 dark:text-rose-400'
                          : 'text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {isVerified
                        ? 'Payment Verified & Approved'
                        : isRejected
                        ? 'Verification Failed — Invalid UTR'
                        : 'Submitted for Admin UTR Verification'}
                    </span>
                    <h3 className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 dark:text-white mt-1">
                      ₹{liveReceipt.amount.toLocaleString('en-IN')}{' '}
                      {isVerified ? 'Paid' : isRejected ? 'Declined' : 'Pending Check'}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      {isVerified
                        ? `Your desk reservation (${activeStudent.assignedDesk}) and Digital Library Pass have been renewed.`
                        : isRejected
                        ? 'Admin could not match this UTR in PhonePe. Please check your PhonePe receipt and resubmit the correct 12-digit UTR.'
                        : 'Your 12-digit UTR has been sent to library admin. Once matched in PhonePe, your fee receipt and ID card validity update automatically.'}
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-left text-xs font-mono tabular-nums space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Submission ID:</span>
                      <strong className="text-slate-900 dark:text-white">{liveReceipt.id}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">12-Digit UTR / Ref:</span>
                      <strong className="text-indigo-600 dark:text-indigo-400">{liveReceipt.transactionRef}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Payment Mode:</span>
                      <span className="text-slate-900 dark:text-white">{liveReceipt.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Submitted Date:</span>
                      <span className="text-slate-900 dark:text-white">{formatDateReadable(liveReceipt.paidDate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Verification Status:</span>
                      <strong
                        className={
                          isVerified
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : isRejected
                            ? 'text-rose-600 dark:text-rose-400'
                            : 'text-amber-600 dark:text-amber-400'
                        }
                      >
                        {isVerified ? 'VERIFIED PAID' : isRejected ? 'REJECTED' : 'AWAITING ADMIN CHECK'}
                      </strong>
                    </div>
                  </div>

                  {liveReceipt.proofImageUrl && (
                    <div className="p-3 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/40">
                      <span className="text-[11px] font-semibold text-slate-500 block mb-2">
                        Attached Payment Screenshot
                      </span>
                      <img
                        src={liveReceipt.proofImageUrl}
                        alt="Uploaded payment proof"
                        className="max-h-40 mx-auto rounded-lg object-contain border border-slate-200 dark:border-slate-700"
                      />
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
                    {isVerified && (
                      <>
                        <button
                          type="button"
                          onClick={() => window.print()}
                          className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 min-h-[42px]"
                        >
                          <Printer className="w-4 h-4" />
                          <span>Print Receipt</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onViewStudentCard(activeStudent)}
                          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold inline-flex items-center gap-1.5 min-h-[42px]"
                        >
                          <Sparkles className="w-4 h-4" />
                          <span>View Updated ID Card</span>
                        </button>
                      </>
                    )}
                    <button
                      type="button"
                      onClick={() => setLatestReceipt(null)}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      {isRejected ? 'Resubmit Valid UTR' : 'Submit Another Payment'}
                    </button>
                  </div>
                </div>
              );
            })()
          ) : (
            <form onSubmit={handlePayOnline} className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800">
              {/* Left Column: Fee Breakdown & Month Selection */}
              <div className="lg:col-span-5 p-5 sm:p-6 space-y-5">
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Online Library Fee Checkout
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Instant digital receipt & automatic ID card validity update
                  </p>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                    Select Billing Month
                  </label>
                  <select
                    value={selectedPayMonth}
                    onChange={e => setSelectedPayMonth(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                  >
                    {monthOptions.map(m => (
                      <option key={m.ym} value={m.ym}>
                        {m.label} — {m.isPaid ? 'Paid (Advance / Re-pay)' : 'Due / Unpaid'}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Student & Desk</span>
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {activeStudent.name} · {activeStudent.assignedDesk}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Shift Plan</span>
                    <span className="font-medium text-slate-900 dark:text-white">
                      {formatStudentShifts(activeStudent.shifts, activeStudent.shift)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Monthly Fee</span>
                    <span className="font-mono tabular-nums text-slate-900 dark:text-white">
                      ₹{activeStudent.monthlyFee.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Online Convenience Fee</span>
                    <span className="font-mono tabular-nums text-emerald-600 dark:text-emerald-400">₹0</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between items-baseline">
                    <span className="font-bold text-slate-900 dark:text-white">Total Payable</span>
                    <span className="text-xl font-extrabold font-mono tabular-nums text-indigo-600 dark:text-indigo-400">
                      ₹{activeStudent.monthlyFee.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-2">
                    Choose Payment Method
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setPayMethod('UPI')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-colors min-h-[56px] ${
                        payMethod === 'UPI'
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 text-indigo-700 dark:text-indigo-300'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Smartphone className="w-4 h-4" />
                      <span>UPI / QR</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPayMethod('CARD')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-colors min-h-[56px] ${
                        payMethod === 'CARD'
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 text-indigo-700 dark:text-indigo-300'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Card</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPayMethod('NETBANKING')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition-colors min-h-[56px] ${
                        payMethod === 'NETBANKING'
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 text-indigo-700 dark:text-indigo-300'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Building2 className="w-4 h-4" />
                      <span>Net Banking</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Payment Instrument Details */}
              <div className="lg:col-span-7 p-5 sm:p-6 flex flex-col justify-between space-y-5">
                {payMethod === 'UPI' && (
                  <div className="space-y-4">
                    <PhonePeScannerCard
                      settings={settings}
                      amount={activeStudent.monthlyFee}
                      note={`${activeStudent.id} Fee ${selectedPayMonth}`}
                      compact
                    />

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                          12-Digit PhonePe / UPI UTR Number <span className="text-rose-600">*</span>
                        </label>
                        <span
                          className={`text-[11px] font-mono tabular-nums font-bold ${
                            utrNumber.replace(/\D/g, '').length === 12
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-slate-400'
                          }`}
                        >
                          {utrNumber.replace(/\D/g, '').length}/12 digits
                        </span>
                      </div>
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={12}
                        required
                        value={utrNumber}
                        onChange={e => {
                          setUtrNumber(e.target.value.replace(/\D/g, '').slice(0, 12));
                          setPaymentError('');
                        }}
                        placeholder="Enter exact 12-digit UTR (e.g. 429185730214)"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums tracking-wider text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                      />
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1.5">
                        Required for verification: after paying on PhonePe / GPay / Paytm, copy the 12-digit UTR / Ref No. from your payment receipt.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-800/40 flex flex-wrap items-center justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-200 block">
                          Payment Screenshot (Optional)
                        </span>
                        <span className="text-[11px] text-slate-500 dark:text-slate-400">
                          {proofImageUrl ? 'Screenshot attached for faster admin check' : 'Helps admin verify your PhonePe transfer immediately'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {proofImageUrl && (
                          <button
                            type="button"
                            onClick={() => setProofImageUrl(undefined)}
                            className="px-2.5 py-1.5 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs font-semibold inline-flex items-center gap-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove</span>
                          </button>
                        )}
                        <label className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer inline-flex items-center gap-1.5">
                          <Upload className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{proofImageUrl ? 'Change Photo' : 'Upload Screenshot'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={e => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              const reader = new FileReader();
                              reader.onload = () => {
                                if (typeof reader.result === 'string') {
                                  setProofImageUrl(reader.result);
                                }
                              };
                              reader.readAsDataURL(file);
                            }}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                )}

                {payMethod === 'CARD' && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Cardholder Name
                      </label>
                      <input
                        type="text"
                        required
                        value={cardHolder}
                        onChange={e => setCardHolder(e.target.value)}
                        placeholder={activeStudent.name}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                        Debit / Credit Card Number
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        required
                        maxLength={19}
                        value={cardNumber}
                        onChange={e => setCardNumber(e.target.value)}
                        placeholder="4532 8810 2290 4412"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Expiry (MM/YY)
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={5}
                          value={cardExpiry}
                          onChange={e => setCardExpiry(e.target.value)}
                          placeholder="08/29"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          CVV
                        </label>
                        <input
                          type="password"
                          inputMode="numeric"
                          required
                          maxLength={4}
                          value={cardCvv}
                          onChange={e => setCardCvv(e.target.value)}
                          placeholder="•••"
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {payMethod === 'NETBANKING' && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                        Select Your Bank
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {[
                          'State Bank of India (SBI)',
                          'HDFC Bank',
                          'ICICI Bank',
                          'Axis Bank',
                          'Punjab National Bank',
                          'Kotak Mahindra Bank',
                        ].map(bank => (
                          <button
                            key={bank}
                            type="button"
                            onClick={() => setSelectedBank(bank)}
                            className={`p-3 rounded-xl border text-left text-xs font-semibold transition-colors ${
                              selectedBank === bank
                                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-600 text-indigo-700 dark:text-indigo-300'
                                : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                            }`}
                          >
                            {bank}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {paymentError && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300">
                    {paymentError}
                  </div>
                )}

                <div className="pt-2 space-y-2.5">
                  <button
                    type="submit"
                    disabled={isProcessingPayment}
                    className="w-full py-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2 transition-colors min-h-[48px]"
                  >
                    <Lock className="w-4 h-4" />
                    <span>
                      {isProcessingPayment
                        ? 'Submitting UTR for Verification...'
                        : `Submit ₹${activeStudent.monthlyFee.toLocaleString('en-IN')} Payment for Verification`}
                    </span>
                  </button>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 text-center flex items-center justify-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Submitted UTR is matched against {settings.name} PhonePe before receipt approval</span>
                  </p>
                </div>
              </div>
            </form>
          )}
        </div>
      )}

      {/* TAB 3: STUDENT ATTENDANCE LOGS */}
      {portalTab === 'ATTENDANCE' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 sm:px-6 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                My Daily Attendance & In / Out Timings
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {studentAttendance.length} recorded study sessions · Current Status:{' '}
                <strong className={isInsideNow ? 'text-emerald-600' : 'text-slate-700 dark:text-slate-200'}>
                  {isInsideNow
                    ? `Checked In at ${formatTime12h(activeStudent.currentCheckInTime)}`
                    : 'Checked Out'}
                </strong>
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleMarkMyAttendance}
                className={`px-3.5 py-2 rounded-xl text-white text-xs font-bold inline-flex items-center gap-1.5 ${
                  isInsideNow ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                {isInsideNow ? <LogOut className="w-3.5 h-3.5" /> : <LogIn className="w-3.5 h-3.5" />}
                <span>{isInsideNow ? 'Mark Out-Time Now' : 'Mark In-Time Now'}</span>
              </button>
              <button
                type="button"
                onClick={onOpenKiosk}
                className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>Self Kiosk</span>
              </button>
            </div>
          </div>

          {studentAttendance.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <p className="text-xs text-slate-500">
                No attendance entries recorded yet for {activeStudent.name}. Mark your In-Time when you arrive.
              </p>
              <button
                type="button"
                onClick={handleMarkMyAttendance}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Mark Today&apos;s In-Time</span>
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {studentAttendance.map(rec => (
                <div key={rec.id} className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                        {formatDateReadable(rec.checkInTime.slice(0, 10))}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                          rec.checkOutTime
                            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        {rec.checkOutTime ? 'Completed' : 'Out-Time Pending'}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono tabular-nums text-slate-600 dark:text-slate-300 mt-1">
                      In Time: <strong>{formatTime12h(rec.checkInTime)}</strong> · Out Time:{' '}
                      <strong>{rec.checkOutTime ? formatTime12h(rec.checkOutTime) : 'Inside Hall'}</strong>
                    </div>
                  </div>

                  <div className="sm:text-right">
                    <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-white block">
                      {rec.durationMinutes
                        ? `${Math.floor(rec.durationMinutes / 60)}h ${rec.durationMinutes % 60}m`
                        : 'Active Session'}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Desk {rec.assignedDesk} · {rec.method.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: STUDENT FEE RECEIPTS & INVOICES */}
      {portalTab === 'RECEIPTS' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 sm:px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Payment History & Digital Receipts
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                All verified receipts for {activeStudent.name} ({activeStudent.id})
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setLatestReceipt(null);
                setPortalTab('PAY_FEE');
              }}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
            >
              + Pay Fee
            </button>
          </div>

          {studentInvoices.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <p className="text-xs text-slate-500">No fee receipts recorded yet.</p>
              <button
                type="button"
                onClick={() => setPortalTab('PAY_FEE')}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold"
              >
                Pay First Monthly Fee Online
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {studentInvoices.map(inv => {
                const isPending = inv.status === 'PENDING';
                const isRejected = inv.status === 'OVERDUE';
                return (
                  <div
                    key={inv.id}
                    className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:bg-slate-50/70 dark:hover:bg-slate-800/40"
                  >
                    <div className="space-y-0.5">
                      <div className="flex flex-wrap items-center gap-2 font-mono tabular-nums">
                        <span className="font-bold text-slate-900 dark:text-white">{inv.id}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-indigo-600 dark:text-indigo-400">UTR: {inv.transactionRef}</span>
                        <span
                          className={`px-2 py-0.5 rounded font-sans text-[10px] font-bold ${
                            isPending
                              ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                              : isRejected
                              ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                              : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                          }`}
                        >
                          {isPending ? 'Pending Verification' : isRejected ? 'Verification Failed' : 'Verified Paid'}
                        </span>
                      </div>
                      <div className="text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                        {isPending ? 'Submitted' : isRejected ? 'Attempted' : 'Paid'} {formatDateReadable(inv.paidDate)} via {inv.paymentMethod} · Period {formatDateReadable(inv.periodStart)} to {formatDateReadable(inv.periodEnd)}
                      </div>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3">
                      <span
                        className={`text-sm font-extrabold font-mono tabular-nums ${
                          isPending
                            ? 'text-amber-600 dark:text-amber-400'
                            : isRejected
                            ? 'text-rose-600 dark:text-rose-400'
                            : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        ₹{inv.amount.toLocaleString('en-IN')}{' '}
                        {isPending ? 'Pending' : isRejected ? 'Failed' : 'Paid'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setReceiptModalInvoice(inv)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold inline-flex items-center gap-1"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>{isPending ? 'Details' : 'Receipt'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Printable Fee Receipt Modal */}
      {receiptModalInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">{settings.name}</h3>
                <p className="text-[11px] text-slate-500">
                  {receiptModalInvoice.status === 'PENDING'
                    ? 'Payment Submission — Pending Verification'
                    : receiptModalInvoice.status === 'OVERDUE'
                    ? 'Unverified Payment Submission'
                    : 'Official Student Fee Receipt'}
                </p>
              </div>
              <span
                className={`text-xs font-mono font-bold ${
                  receiptModalInvoice.status === 'PENDING'
                    ? 'text-amber-600'
                    : receiptModalInvoice.status === 'OVERDUE'
                    ? 'text-rose-600'
                    : 'text-emerald-600'
                }`}
              >
                {receiptModalInvoice.status === 'PENDING'
                  ? 'PENDING'
                  : receiptModalInvoice.status === 'OVERDUE'
                  ? 'FAILED'
                  : 'PAID'}
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono tabular-nums">
              <div className="flex justify-between">
                <span className="text-slate-500">Receipt ID</span>
                <strong className="text-slate-900 dark:text-white">{receiptModalInvoice.id}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Student</span>
                <strong className="text-slate-900 dark:text-white">{receiptModalInvoice.studentName}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Student ID</span>
                <span className="text-slate-900 dark:text-white">{receiptModalInvoice.studentId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction Ref</span>
                <span className="text-indigo-600 dark:text-indigo-400">{receiptModalInvoice.transactionRef}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Mode</span>
                <span className="text-slate-900 dark:text-white">{receiptModalInvoice.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Paid Date</span>
                <span className="text-slate-900 dark:text-white">{formatDateReadable(receiptModalInvoice.paidDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Valid Period</span>
                <span className="text-slate-900 dark:text-white">
                  {formatDateReadable(receiptModalInvoice.periodStart)} → {formatDateReadable(receiptModalInvoice.periodEnd)}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between text-sm">
                <span className="font-bold text-slate-900 dark:text-white">Amount Paid</span>
                <strong className="text-emerald-600 dark:text-emerald-400">
                  ₹{receiptModalInvoice.amount.toLocaleString('en-IN')}
                </strong>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 no-print">
              <button
                type="button"
                onClick={() => setReceiptModalInvoice(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white text-xs font-bold inline-flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Receipt</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
