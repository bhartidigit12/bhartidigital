import React, { useMemo, useState } from 'react';
import { 
  Users, 
  Clock, 
  IndianRupee, 
  AlertCircle, 
  QrCode, 
  UserPlus, 
  TrendingUp, 
  Sparkles,
  ArrowRight,
  ChevronRight,
  ShieldCheck,
  UserCheck,
  Armchair,
  Search,
  LayoutGrid,
  List
} from 'lucide-react';
import { Student, PeakHourData, LibrarySettings, StudentApplication, formatStudentShifts } from '../types';
import { libraryHeroImage } from '../utils/assets';

interface SeatSlotInfo {
  seatCode: string;
  zone: string;
  seatNumber: number;
  status: 'FULL' | 'VACANT_ABSENT' | 'VACANT_OPEN';
  presentStudents: Student[];
  absentStudents: Student[];
  allAssigned: Student[];
}

function formatLiveTime(isoStr?: string): string {
  if (!isoStr) return '—';
  const dt = new Date(isoStr);
  if (!Number.isNaN(dt.getTime())) {
    return dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  }
  return isoStr;
}

interface DashboardViewProps {
  students: Student[];
  peakHours: PeakHourData[];
  settings: LibrarySettings;
  pendingApplications: StudentApplication[];
  isAdmin?: boolean;
  onRequireAdmin?: () => void;
  onOpenKiosk: () => void;
  onOpenRegister: () => void;
  onOpenSelfRegister: () => void;
  onOpenApprovals: () => void;
  onOpenNotifications: () => void;
  onSelectStudent: (student: Student) => void;
  setActiveTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  students,
  peakHours,
  settings,
  pendingApplications,
  isAdmin = false,
  onOpenKiosk,
  onOpenRegister,
  onOpenSelfRegister,
  onOpenApprovals,
  onOpenNotifications,
  onSelectStudent,
  setActiveTab,
}) => {
  const [seatFilter, setSeatFilter] = useState<'ALL' | 'FULL' | 'VACANT_ALL' | 'VACANT_ABSENT' | 'VACANT_OPEN'>('ALL');
  const [zoneFilter, setZoneFilter] = useState<string>('ALL');
  const [seatSearch, setSeatSearch] = useState<string>('');
  const [seatViewMode, setSeatViewMode] = useState<'GRID' | 'LIST'>('GRID');

  const activeStudents = students.filter(s => s.attendanceStatus === 'CHECKED_IN');
  const absentStudentsList = students.filter(s => s.attendanceStatus !== 'CHECKED_IN');
  const overdueStudents = students.filter(s => s.paymentStatus === 'OVERDUE');
  const dueSoonStudents = students.filter(s => s.paymentStatus === 'DUE_SOON');
  const pendingCount = pendingApplications.filter(a => a.status === 'PENDING').length;

  // Build seat-by-seat occupancy map based on Present (CHECKED_IN) vs Absent (CHECKED_OUT)
  const seatSummary = useMemo(() => {
    const totalDesks = Math.max(1, settings.totalDesks || 120);
    const deskMap = new Map<string, Student[]>();

    students.forEach(s => {
      const code = (s.assignedDesk || '').trim().toUpperCase();
      if (!code || code === 'GENERAL / FLEX') return;
      const existing = deskMap.get(code) || [];
      existing.push(s);
      deskMap.set(code, existing);
    });

    const slots: SeatSlotInfo[] = [];
    const seenCodes = new Set<string>();
    const zonesPerBlock = 40;

    for (let i = 1; i <= totalDesks; i++) {
      const zoneIdx = Math.floor((i - 1) / zonesPerBlock);
      const zone = String.fromCharCode(65 + zoneIdx); // A, B, C...
      const numInZone = ((i - 1) % zonesPerBlock) + 1;
      const seatCode = `${zone}-${String(numInZone).padStart(2, '0')}`;
      seenCodes.add(seatCode);

      const assigned = deskMap.get(seatCode) || [];
      const present = assigned.filter(s => s.attendanceStatus === 'CHECKED_IN');
      const absent = assigned.filter(s => s.attendanceStatus !== 'CHECKED_IN');

      const status: SeatSlotInfo['status'] =
        present.length > 0 ? 'FULL' : absent.length > 0 ? 'VACANT_ABSENT' : 'VACANT_OPEN';

      slots.push({
        seatCode,
        zone,
        seatNumber: i,
        status,
        presentStudents: present,
        absentStudents: absent,
        allAssigned: assigned,
      });
    }

    // Include any custom desk codes assigned to students outside standard A-01..C-40 grid
    deskMap.forEach((assigned, code) => {
      if (seenCodes.has(code)) return;
      const present = assigned.filter(s => s.attendanceStatus === 'CHECKED_IN');
      const absent = assigned.filter(s => s.attendanceStatus !== 'CHECKED_IN');
      const status: SeatSlotInfo['status'] =
        present.length > 0 ? 'FULL' : absent.length > 0 ? 'VACANT_ABSENT' : 'VACANT_OPEN';

      slots.push({
        seatCode: code,
        zone: code.split('-')[0] || 'Custom',
        seatNumber: slots.length + 1,
        status,
        presentStudents: present,
        absentStudents: absent,
        allAssigned: assigned,
      });
    });

    const fullSeats = slots.filter(s => s.status === 'FULL');
    const vacantAbsentSeats = slots.filter(s => s.status === 'VACANT_ABSENT');
    const vacantOpenSeats = slots.filter(s => s.status === 'VACANT_OPEN');
    const totalVacantSeats = vacantAbsentSeats.length + vacantOpenSeats.length;
    const zones = Array.from(new Set(slots.map(s => s.zone)));

    return {
      slots,
      fullSeats,
      vacantAbsentSeats,
      vacantOpenSeats,
      totalVacantSeats,
      totalSeats: slots.length,
      zones,
    };
  }, [students, settings.totalDesks]);

  const filteredSeats = useMemo(() => {
    const q = seatSearch.trim().toLowerCase();
    return seatSummary.slots.filter(slot => {
      if (zoneFilter !== 'ALL' && slot.zone !== zoneFilter) return false;
      if (seatFilter === 'FULL' && slot.status !== 'FULL') return false;
      if (seatFilter === 'VACANT_ALL' && slot.status === 'FULL') return false;
      if (seatFilter === 'VACANT_ABSENT' && slot.status !== 'VACANT_ABSENT') return false;
      if (seatFilter === 'VACANT_OPEN' && slot.status !== 'VACANT_OPEN') return false;

      if (q) {
        const matchesCode = slot.seatCode.toLowerCase().includes(q);
        const matchesStudent = slot.allAssigned.some(
          s => s.name.toLowerCase().includes(q) || s.id.toLowerCase().includes(q)
        );
        if (!matchesCode && !matchesStudent) return false;
      }
      return true;
    });
  }, [seatSummary.slots, zoneFilter, seatFilter, seatSearch]);

  const occupancyRate = Math.round((seatSummary.fullSeats.length / Math.max(1, seatSummary.totalSeats)) * 100);

  // Financial calculations
  const totalCollectedMonth = students
    .filter(s => s.paymentStatus === 'PAID')
    .reduce((acc, s) => acc + s.monthlyFee, 0);

  const totalPendingDues = [...overdueStudents, ...dueSoonStudents]
    .reduce((acc, s) => acc + s.monthlyFee, 0);

  // Find peak hour today
  const highestPeak = peakHours.reduce((prev, current) => 
    (prev.occupancyCount > current.occupancyCount) ? prev : current
  );

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Welcome & Library Hero Card */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-xl">
        <img
          src={libraryHeroImage}
          alt="Library Study Hall"
          className="absolute inset-0 w-full h-full object-cover opacity-25"
        />
        <div className="relative z-10 p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
                <span>Director Overview</span>
                <span>·</span>
                <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white text-balance">
                {settings.name}
              </h1>
              <p className="text-sm text-slate-300 max-w-xl mt-1">
                <strong className="text-emerald-400 font-mono tabular-nums">{seatSummary.fullSeats.length}</strong> seats full ({activeStudents.length} present) ·{' '}
                <strong className="text-amber-300 font-mono tabular-nums">{seatSummary.totalVacantSeats}</strong> seats vacant ({absentStudentsList.length} absent) across {seatSummary.totalSeats} cubicles.
              </p>
            </div>

            {/* Quick Action Badges */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setActiveTab('student-portal')}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-emerald-500/90 hover:bg-emerald-500 text-white font-bold text-xs backdrop-blur-md transition-all whitespace-nowrap min-h-[44px]"
                title="Student Login, Profile & Online Fee Payment"
              >
                <IndianRupee className="w-4 h-4" />
                <span>Student Login & Pay</span>
              </button>

              <button
                onClick={onOpenSelfRegister}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs backdrop-blur-md transition-all whitespace-nowrap min-h-[44px]"
                title="Student Self-Registration Portal"
              >
                <UserPlus className="w-4 h-4 text-indigo-300" />
                <span>Self Register</span>
              </button>

              <button
                onClick={onOpenApprovals}
                className="relative flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Approvals</span>
                {pendingCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                    {pendingCount}
                  </span>
                )}
              </button>

              <button
                onClick={onOpenKiosk}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <QrCode className="w-4 h-4 text-indigo-600" />
                <span>Kiosk Mode</span>
              </button>

              <button
                onClick={onOpenRegister}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all whitespace-nowrap min-h-[44px]"
              >
                <span>+ Direct Add</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Pending Student Registrations Queue Card (Admin Only) */}
      {isAdmin && pendingCount > 0 && (
        <div className="p-5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold">
                <UserCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-amber-950 dark:text-amber-200">
                  {pendingCount} Students Self-Registered — Awaiting Admin Approval
                </h3>
                <p className="text-xs text-amber-800/80 dark:text-amber-300/80">
                  Verify identity proofs, assign designated desk numbers, and issue digital entry passes.
                </p>
              </div>
            </div>
            <button
              onClick={onOpenApprovals}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto shadow-sm"
            >
              <span>Review All ({pendingCount})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
            {pendingApplications.filter(a => a.status === 'PENDING').slice(0, 4).map(app => (
              <div
                key={app.id}
                className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-amber-200/60 dark:border-amber-900/40 text-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white truncate">{app.fullName}</span>
                  <span className="text-[10px] font-mono text-indigo-600 font-semibold">{app.desiredShift.replace('_', ' ')}</span>
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  Goal: {app.courseOrExam}
                </div>
                <div className="text-[10px] text-slate-400 font-mono flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span>Pref: {app.deskPreference || 'Any'}</span>
                  <button
                    onClick={onOpenApprovals}
                    className="text-amber-600 dark:text-amber-400 font-bold hover:underline"
                  >
                    Approve →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* KPI Metric Strip: Monthly Collected & Pending Dues visible to Admin only */}
      <div className={`grid gap-3 sm:gap-4 ${isAdmin ? 'grid-cols-2 lg:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2'}`}>
        {/* Occupancy Card: Full vs Vacant based on Present/Absent */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Seats Full / Vacant</span>
            <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2 flex-wrap">
            <span className="text-2xl sm:text-3xl font-bold font-mono tabular-nums tracking-tight text-emerald-600 dark:text-emerald-400">
              {seatSummary.fullSeats.length} Full
            </span>
            <span className="text-xs text-slate-500 font-mono tabular-nums">
              · {seatSummary.totalVacantSeats} Vacant
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs">
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden mr-2">
              <div 
                className={`h-full rounded-full ${occupancyRate > 90 ? 'bg-rose-500' : occupancyRate > 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                style={{ width: `${Math.min(100, occupancyRate)}%` }}
              ></div>
            </div>
            <span className="font-mono tabular-nums font-bold text-slate-700 dark:text-slate-300 shrink-0">
              {occupancyRate}%
            </span>
          </div>
        </div>

        {/* Total Registered Members */}
        <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
            <span className="text-xs font-semibold">Total Members</span>
            <Sparkles className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold font-mono tracking-tight text-slate-900 dark:text-white">
              {students.length}
            </span>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
              +{activeStudents.length} Present
            </span>
          </div>
          <div className="mt-3 text-xs text-slate-500 truncate">
            {absentStudentsList.length} Absent · {seatSummary.vacantOpenSeats.length} Open Seats
          </div>
        </div>

        {/* Month Revenue Collections (Admin Only) */}
        {isAdmin && (
          <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-semibold">Monthly Collected</span>
              <IndianRupee className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-bold font-mono tabular-nums tracking-tight text-slate-900 dark:text-white">
                ₹{totalCollectedMonth.toLocaleString('en-IN')}
              </span>
            </div>
            <div className="mt-3 text-xs text-slate-500 truncate">
              Automatic receipts & invoices issued
            </div>
          </div>
        )}

        {/* Pending & Overdue Fees (Admin Only) */}
        {isAdmin && (
          <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
              <span className="text-xs font-semibold">Pending Dues</span>
              <AlertCircle className="w-4 h-4 text-rose-600" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-bold font-mono tabular-nums tracking-tight text-rose-600 dark:text-rose-400">
                ₹{totalPendingDues.toLocaleString('en-IN')}
              </span>
              <span className="text-xs text-rose-600 font-semibold">
                ({overdueStudents.length} Overdue)
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between text-xs">
              <button
                onClick={onOpenNotifications}
                className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1"
              >
                <span>Send Reminders</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Live Seat Occupancy & Student Details (Present vs Absent) */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        {/* Section Header + Live Seat Breakdown */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Armchair className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Live Seat Availability & Student Roster
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Calculated live from student attendance: <strong className="text-emerald-600 dark:text-emerald-400">Present = Seat Full</strong> · <strong className="text-amber-600 dark:text-amber-400">Absent / Unassigned = Seat Vacant</strong>. Click any student seat for pass & fee details.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2 sm:gap-3 shrink-0">
            <div className="px-3 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/60 text-center">
              <span className="text-[10px] font-semibold uppercase tracking-wide text-emerald-700 dark:text-emerald-300 block">
                Full (Present)
              </span>
              <span className="text-lg font-extrabold font-mono tabular-nums text-emerald-700 dark:text-emerald-300">
                {seatSummary.fullSeats.length}
              </span>
            </div>
            <div className="px-3 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-center">
              <span className="text-[10px] font-semibold uppercase tracking-wide text-amber-700 dark:text-amber-300 block">
                Vacant (Absent)
              </span>
              <span className="text-lg font-extrabold font-mono tabular-nums text-amber-700 dark:text-amber-300">
                {seatSummary.vacantAbsentSeats.length}
              </span>
            </div>
            <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center">
              <span className="text-[10px] font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300 block">
                Vacant (Open)
              </span>
              <span className="text-lg font-extrabold font-mono tabular-nums text-slate-900 dark:text-white">
                {seatSummary.vacantOpenSeats.length}
              </span>
            </div>
          </div>
        </div>

        {/* Filter Controls, Zone Tabs, Search & Grid/List Toggle */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-1 border-t border-slate-100 dark:border-slate-800">
          {/* Status Filter Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            {[
              { id: 'ALL', label: `All (${seatSummary.totalSeats})` },
              { id: 'FULL', label: `Full · Present (${seatSummary.fullSeats.length})` },
              { id: 'VACANT_ALL', label: `All Vacant (${seatSummary.totalVacantSeats})` },
              { id: 'VACANT_ABSENT', label: `Absent Seats (${seatSummary.vacantAbsentSeats.length})` },
              { id: 'VACANT_OPEN', label: `Open Seats (${seatSummary.vacantOpenSeats.length})` },
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSeatFilter(tab.id as typeof seatFilter)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  seatFilter === tab.id
                    ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search + Zone + View Switcher */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[170px] sm:w-48">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={seatSearch}
                onChange={e => setSeatSearch(e.target.value)}
                placeholder="Search seat or student..."
                className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <select
              value={zoneFilter}
              onChange={e => setZoneFilter(e.target.value)}
              aria-label="Filter by zone"
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 focus:outline-none"
            >
              <option value="ALL">All Zones</option>
              {seatSummary.zones.map(z => (
                <option key={z} value={z}>
                  Zone {z}
                </option>
              ))}
            </select>

            <div className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setSeatViewMode('GRID')}
                className={`p-1.5 rounded-md transition-colors ${
                  seatViewMode === 'GRID'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Seat Grid View"
                aria-label="Seat Grid View"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setSeatViewMode('LIST')}
                className={`p-1.5 rounded-md transition-colors ${
                  seatViewMode === 'LIST'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
                title="Detailed Seat Table View"
                aria-label="Detailed Seat Table View"
              >
                <List className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Seat Details Display (Grid or Table) */}
        {filteredSeats.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500 dark:text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
            No seats match the current filter.
          </div>
        ) : seatViewMode === 'GRID' ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5 max-h-[420px] overflow-y-auto pr-1">
            {filteredSeats.map(slot => {
              const primaryStudent = slot.presentStudents[0] || slot.absentStudents[0];
              const isFull = slot.status === 'FULL';
              const isAbsent = slot.status === 'VACANT_ABSENT';

              return (
                <button
                  key={slot.seatCode}
                  type="button"
                  disabled={!primaryStudent}
                  onClick={() => primaryStudent && onSelectStudent(primaryStudent)}
                  className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 ${
                    isFull
                      ? 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-200 dark:border-emerald-800/70 hover:border-emerald-400 cursor-pointer'
                      : isAbsent
                      ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-200/80 dark:border-amber-900/60 hover:border-amber-400 cursor-pointer'
                      : 'bg-slate-50/80 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800 cursor-default opacity-85'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 w-full">
                    <span className="font-mono tabular-nums text-xs font-extrabold text-slate-900 dark:text-white">
                      {slot.seatCode}
                    </span>
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded ${
                        isFull
                          ? 'bg-emerald-600 text-white'
                          : isAbsent
                          ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {isFull ? 'Full' : isAbsent ? 'Vacant' : 'Open'}
                    </span>
                  </div>

                  {primaryStudent ? (
                    <div className="min-w-0 w-full">
                      <p className="text-[11px] font-bold text-slate-900 dark:text-white truncate">
                        {primaryStudent.name}
                      </p>
                      <p className="text-[10px] font-mono text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {isFull
                          ? `Present · In ${formatLiveTime(primaryStudent.currentCheckInTime)}`
                          : 'Absent · Seat Vacant'}
                      </p>
                    </div>
                  ) : (
                    <div className="min-w-0 w-full">
                      <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate">
                        Unassigned
                      </p>
                      <p className="text-[10px] font-mono text-slate-400 dark:text-slate-500 truncate mt-0.5">
                        Available Seat
                      </p>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl max-h-[420px] overflow-y-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 sticky top-0 z-10">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Seat No.</th>
                  <th className="py-2.5 px-3 font-semibold">Seat Status</th>
                  <th className="py-2.5 px-3 font-semibold">Student Name</th>
                  <th className="py-2.5 px-3 font-semibold">Attendance</th>
                  <th className="py-2.5 px-3 font-semibold">Shift &amp; In-Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredSeats.map(slot => {
                  const primaryStudent = slot.presentStudents[0] || slot.absentStudents[0];
                  const isFull = slot.status === 'FULL';
                  const isAbsent = slot.status === 'VACANT_ABSENT';

                  return (
                    <tr
                      key={slot.seatCode}
                      onClick={() => primaryStudent && onSelectStudent(primaryStudent)}
                      className={`${
                        primaryStudent
                          ? 'hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer'
                          : 'bg-slate-50/40 dark:bg-slate-900/40'
                      } transition-colors`}
                    >
                      <td className="py-2.5 px-3 font-mono tabular-nums font-bold text-slate-900 dark:text-white whitespace-nowrap">
                        {slot.seatCode}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isFull
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                              : isAbsent
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {isFull ? 'Full (Occupied)' : isAbsent ? 'Vacant (Absent)' : 'Vacant (Open)'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                        {slot.allAssigned.length > 0 ? (
                          <div className="space-y-0.5">
                            {slot.allAssigned.map(st => (
                              <div key={st.id} className="flex items-center gap-1.5">
                                <span>{st.name}</span>
                                <span className="text-[10px] font-mono text-slate-400">({st.id})</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400 font-normal">Unassigned · Open Seat</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {isFull ? (
                          <span className="font-semibold text-emerald-600 dark:text-emerald-400">Present</span>
                        ) : isAbsent ? (
                          <span className="font-semibold text-amber-600 dark:text-amber-400">Absent</span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 font-mono tabular-nums text-[11px] text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {primaryStudent ? (
                          <span>
                            {formatStudentShifts(primaryStudent.shifts, primaryStudent.shift)}
                            {isFull && primaryStudent.currentCheckInTime
                              ? ` · In ${formatLiveTime(primaryStudent.currentCheckInTime)}`
                              : ''}
                          </span>
                        ) : (
                          'Ready to assign'
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Daily Peak Rush Indicator & Mini Hourly Curve */}
      <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Daily Peak Hours & Real-Time Density
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Identifies congestion hours to optimize multi-shift desk allocations. Peak expected at <strong className="text-slate-800 dark:text-slate-200">{highestPeak.label} ({highestPeak.occupancyCount} seats)</strong>.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('analytics')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Full Analytics Report</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Hourly Histogram Bar Preview */}
        <div className="grid grid-cols-9 sm:grid-cols-[repeat(18,minmax(0,1fr))] gap-1 items-end h-28 pt-4 pb-2 border-b border-slate-100 dark:border-slate-800">
          {peakHours.map((hourData) => {
            const heightPercent = Math.round((hourData.occupancyCount / settings.totalDesks) * 100);
            const isHigh = hourData.occupancyCount >= 100;

            return (
              <div key={hourData.hour} className="flex flex-col items-center h-full justify-end group relative">
                {/* Tooltip on hover */}
                <div className="absolute -top-8 bg-slate-900 text-white text-[10px] py-1 px-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20 font-mono">
                  {hourData.label}: {hourData.occupancyCount} seats ({hourData.capacityPercentage}%)
                </div>
                <div
                  className={`w-full rounded-t transition-all ${
                    isHigh
                      ? 'bg-rose-500 group-hover:bg-rose-600'
                      : hourData.isPeak
                      ? 'bg-indigo-500 group-hover:bg-indigo-600'
                      : 'bg-slate-200 dark:bg-slate-700 group-hover:bg-slate-300'
                  }`}
                  style={{ height: `${heightPercent}%` }}
                ></div>
                <span className="text-[9px] text-slate-400 font-mono mt-1 scale-90">
                  {hourData.hour}h
                </span>
              </div>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-rose-500"></span>
              <span>Heavy Rush (&gt;85%)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500"></span>
              <span>Optimal Occupancy</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-slate-200 dark:bg-slate-700"></span>
              <span>Light Hours</span>
            </span>
          </div>
          <span className="font-mono text-[11px]">Next expected lull: 1:00 PM - 3:00 PM</span>
        </div>
      </div>

      {/* Currently Studying (Live) vs Urgent Payment Reminders (Admin Only) */}
      <div className={`grid grid-cols-1 gap-6 ${isAdmin ? 'lg:grid-cols-2' : ''}`}>
        {/* Live Attendance Inside Right Now */}
        <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span>Currently Inside Hall ({activeStudents.length})</span>
              </h3>
              <p className="text-xs text-slate-500">Real-time occupancy roster</p>
            </div>
            <button
              onClick={() => setActiveTab('attendance')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              View Roster
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {activeStudents.slice(0, 5).map(student => (
              <div
                key={student.id}
                onClick={() => onSelectStudent(student)}
                className="py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 px-2 rounded-xl transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs shrink-0">
                    {student.name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {student.name}
                    </h4>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Desk {student.assignedDesk} · Shift: {student.shift.replace('_', ' ')}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-mono tabular-nums font-semibold text-emerald-600 dark:text-emerald-400 block">
                    In since {formatLiveTime(student.currentCheckInTime)}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                    ~{student.currentCheckInDurationMinutes || 120} mins spent
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Urgent Monthly Payment Reminders (Admin Only) */}
        {isAdmin && (
          <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>Overdue & Expiring Memberships ({overdueStudents.length + dueSoonStudents.length})</span>
                </h3>
                <p className="text-xs text-slate-500">Automated reminder triggers</p>
              </div>
              <button
                onClick={onOpenNotifications}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
              >
                Push Center
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {[...overdueStudents, ...dueSoonStudents].slice(0, 5).map(student => (
                <div
                  key={student.id}
                  className="py-3 flex items-center justify-between gap-3 px-2 rounded-xl"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {student.name}
                      </span>
                      <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-semibold ${
                        student.paymentStatus === 'OVERDUE'
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {student.paymentStatus === 'OVERDUE' ? 'Overdue' : 'Due in 3d'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      Due: {student.renewalDueDate} · Desk {student.assignedDesk} · ₹{student.monthlyFee}
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectStudent(student)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 shrink-0"
                  >
                    Manage
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={() => setActiveTab('billing')}
              className="w-full py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Manage All Library Dues & Receipts</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
