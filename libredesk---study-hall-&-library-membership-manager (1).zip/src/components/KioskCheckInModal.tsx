import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { X, QrCode, Hash, CheckCircle2, LogOut, LogIn, AlertTriangle, Camera, Search, Clock, SwitchCamera, RefreshCw, Upload, Phone, CalendarRange, IndianRupee, IdCard, RotateCcw } from 'lucide-react';
import jsQR from 'jsqr';
import { Student, formatStudentShifts } from '../types';
import { resolveStudentAvatar } from '../utils/assets';
import { sounds } from '../utils/notifications';
import confetti from 'canvas-confetti';

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatKioskDate(iso?: string): string {
  if (!iso) return 'Pending';
  const clean = iso.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return iso;
  const [year, monthStr, day] = parts;
  const monthIdx = parseInt(monthStr, 10) - 1;
  return `${day} ${MONTHS_SHORT[monthIdx] || monthStr} ${year}`;
}

function getCurrentHHMM(): string {
  const dt = new Date();
  return `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
}

interface KioskCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  initialMode?: 'PIN' | 'SEARCH' | 'QR';
  onViewFullCard?: (student: Student) => void;
  onCheckInToggle: (
    studentId: string,
    method: 'QR_SCAN' | 'PIN_KIOSK',
    customTimeHHMM?: string
  ) => {
    success: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
    message?: string;
  };
}

function formatKioskTime(isoStr?: string): string {
  if (!isoStr) {
    const dt = new Date();
    return dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  }
  const dt = new Date(isoStr);
  if (!Number.isNaN(dt.getTime())) {
    return dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  }
  return isoStr;
}

export const KioskCheckInModal: React.FC<KioskCheckInModalProps> = ({
  isOpen,
  onClose,
  students,
  initialMode = 'PIN',
  onViewFullCard,
  onCheckInToggle,
}) => {
  const [mode, setMode] = useState<'PIN' | 'SEARCH' | 'QR'>(initialMode);
  const [qrScanAction, setQrScanAction] = useState<'AUTO' | 'CONFIRM'>('AUTO');
  const [kioskTimeInput, setKioskTimeInput] = useState<string>(() => getCurrentHHMM());
  const [pinInput, setPinInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraStatus, setCameraStatus] = useState<'idle' | 'starting' | 'active' | 'error'>('idle');
  const [cameraError, setCameraError] = useState<string>('');
  const [scanWarning, setScanWarning] = useState<string>('');
  const [feedback, setFeedback] = useState<{
    show: boolean;
    pendingConfirm?: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
    error?: string;
  }>({ show: false });

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const qrFileInputRef = useRef<HTMLInputElement | null>(null);
  const scanLockRef = useRef<boolean>(false);
  const feedbackTimerRef = useRef<number | null>(null);

  const clearFeedbackTimer = useCallback(() => {
    if (feedbackTimerRef.current !== null) {
      window.clearTimeout(feedbackTimerRef.current);
      feedbackTimerRef.current = null;
    }
  }, []);

  const resetToScanner = useCallback(() => {
    clearFeedbackTimer();
    setPinInput('');
    setSearchQuery('');
    setKioskTimeInput(getCurrentHHMM());
    scanLockRef.current = false;
    setFeedback({ show: false });
  }, [clearFeedbackTimer]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraStatus('idle');
  }, []);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setKioskTimeInput(getCurrentHHMM());
    } else {
      clearFeedbackTimer();
      stopCamera();
      setPinInput('');
      setSearchQuery('');
      setCameraError('');
      setScanWarning('');
      scanLockRef.current = false;
      setFeedback({ show: false });
    }
    return () => {
      clearFeedbackTimer();
    };
  }, [isOpen, initialMode, stopCamera, clearFeedbackTimer]);

  const handleToggleStudent = (
    target: Student,
    method: 'PIN_KIOSK' | 'QR_SCAN',
    customTimeHHMM?: string
  ) => {
    clearFeedbackTimer();
    const res = onCheckInToggle(target.id, method, customTimeHHMM);
    if (res.action === 'IN') {
      sounds.playSuccess();
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    } else {
      sounds.playCheckOut();
    }

    setFeedback({
      show: true,
      pendingConfirm: false,
      student: res.student || target,
      action: res.action,
      inTime: res.inTime,
      outTime: res.outTime,
      durationMinutes: res.durationMinutes,
    });

    feedbackTimerRef.current = window.setTimeout(() => {
      resetToScanner();
    }, 15000);
  };

  const handleReviewScannedStudent = (target: Student) => {
    clearFeedbackTimer();
    setKioskTimeInput(getCurrentHHMM());
    sounds.playSuccess();
    setFeedback({
      show: true,
      pendingConfirm: true,
      student: target,
    });
  };

  const resolveStudentFromQrText = useCallback(
    (rawText: string): Student | undefined => {
      const cleaned = rawText.trim();
      if (!cleaned) return undefined;

      let candidateId = cleaned;
      if (cleaned.includes('student_id=')) {
        try {
          const parsedUrl = new URL(cleaned);
          candidateId = parsedUrl.searchParams.get('student_id') || cleaned;
        } catch {
          const match = cleaned.match(/student_id=([^&\s]+)/i);
          if (match?.[1]) candidateId = decodeURIComponent(match[1]);
        }
      }

      const lower = candidateId.toLowerCase();
      return students.find(
        s =>
          s.id.toLowerCase() === lower ||
          s.pin.toLowerCase() === lower ||
          s.phone.toLowerCase() === lower
      );
    },
    [students]
  );

  const handleDecodedQr = useCallback(
    (rawText: string) => {
      if (scanLockRef.current) return;
      const matched = resolveStudentFromQrText(rawText);
      if (matched) {
        scanLockRef.current = true;
        setScanWarning('');
        stopCamera();
        if (qrScanAction === 'CONFIRM') {
          handleReviewScannedStudent(matched);
        } else {
          handleToggleStudent(matched, 'QR_SCAN');
        }
      } else {
        setScanWarning(`Unrecognized QR "${rawText.slice(0, 24)}". Hold a valid Student ID Pass.`);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [resolveStudentFromQrText, stopCamera, qrScanAction]
  );

  const isQrModeActiveRef = useRef(false);
  isQrModeActiveRef.current = isOpen && mode === 'QR' && !feedback.show;

  const startQrCamera = useCallback(async () => {
    if (!isQrModeActiveRef.current) return;
    stopCamera();
    setCameraError('');
    setScanWarning('');
    setCameraStatus('starting');

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraStatus('error');
      setCameraError('Live camera API is not supported in this browser. Use "Scan QR Photo" below.');
      return;
    }

    try {
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode,
            width: { ideal: 640 },
            height: { ideal: 640 },
          },
          audio: false,
        });
      } catch {
        // Fallback for desktops/devices that reject facingMode constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      if (!isQrModeActiveRef.current) {
        stream.getTracks().forEach(track => track.stop());
        return;
      }

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCameraStatus('active');
    } catch (err) {
      if (!isQrModeActiveRef.current) return;
      setCameraStatus('error');
      const isDenied =
        err instanceof Error &&
        (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError');
      setCameraError(
        isDenied
          ? 'Camera access blocked. Allow camera permission in browser settings, then tap Enable Camera.'
          : 'Unable to open camera right now. Tap Enable Camera or scan a QR photo below.'
      );
    }
  }, [facingMode, stopCamera]);

  useEffect(() => {
    if (cameraStatus === 'active' && videoRef.current && streamRef.current) {
      if (videoRef.current.srcObject !== streamRef.current) {
        videoRef.current.srcObject = streamRef.current;
      }
      videoRef.current.play().catch(() => {});
    }
  }, [cameraStatus]);

  useEffect(() => {
    if (isOpen && mode === 'QR' && !feedback.show) {
      scanLockRef.current = false;
      startQrCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, mode, feedback.show, startQrCamera, stopCamera]);

  // Continuous QR frame scanning loop while camera is active
  useEffect(() => {
    if (!isOpen || mode !== 'QR' || cameraStatus !== 'active' || feedback.show) return;

    let cancelled = false;
    const scanInterval = window.setInterval(() => {
      if (cancelled || scanLockRef.current) return;
      const video = videoRef.current;
      if (!video || video.readyState < 2 || video.videoWidth === 0 || video.videoHeight === 0) return;

      if (!scanCanvasRef.current) {
        scanCanvasRef.current = document.createElement('canvas');
      }
      const canvas = scanCanvasRef.current;
      const maxDim = 480;
      const scale = Math.min(1, maxDim / Math.max(video.videoWidth, video.videoHeight));
      const w = Math.max(1, Math.floor(video.videoWidth * scale));
      const h = Math.max(1, Math.floor(video.videoHeight * scale));
      if (canvas.width !== w) canvas.width = w;
      if (canvas.height !== h) canvas.height = h;

      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;

      ctx.drawImage(video, 0, 0, w, h);
      const imageData = ctx.getImageData(0, 0, w, h);
      const code = jsQR(imageData.data, w, h, { inversionAttempts: 'attemptBoth' });
      if (code?.data) {
        handleDecodedQr(code.data);
      }
    }, 180);

    return () => {
      cancelled = true;
      window.clearInterval(scanInterval);
    };
  }, [isOpen, mode, cameraStatus, feedback.show, handleDecodedQr]);

  const handleQrImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 720;
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.floor(img.width * scale));
        const h = Math.max(1, Math.floor(img.height * scale));
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, w, h);
        const imageData = ctx.getImageData(0, 0, w, h);
        const code = jsQR(imageData.data, w, h, { inversionAttempts: 'attemptBoth' });
        if (code?.data) {
          handleDecodedQr(code.data);
        } else {
          sounds.playAlert();
          setScanWarning('No QR code detected in that photo. Try a clearer photo of the ID card.');
        }
      };
      if (typeof reader.result === 'string') {
        img.src = reader.result;
      }
    };
    reader.readAsDataURL(file);
  };

  const processPin = (pin: string) => {
    const target = students.find(
      s => s.pin === pin || s.id.toLowerCase() === pin.toLowerCase() || s.id.endsWith(pin)
    );
    if (!target) {
      sounds.playAlert();
      clearFeedbackTimer();
      setFeedback({
        show: true,
        error: `No student found with PIN "${pin}". Try Quick Name/Mobile Search tab.`,
      });
      feedbackTimerRef.current = window.setTimeout(() => {
        resetToScanner();
      }, 2200);
      return;
    }
    handleToggleStudent(target, 'PIN_KIOSK');
  };

  const handleKeypadPress = (digit: string) => {
    if (pinInput.length < 6) {
      const nextPin = pinInput + digit;
      setPinInput(nextPin);
      if (nextPin.length === 4) {
        processPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPinInput(prev => prev.slice(0, -1));
  };

  // Support physical keyboard number typing in PIN mode
  useEffect(() => {
    if (!isOpen || mode !== 'PIN' || feedback.show) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (/^\d$/.test(e.key)) {
        e.preventDefault();
        handleKeypadPress(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const matchedStudents = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = q
      ? students.filter(
          s =>
            s.name.toLowerCase().includes(q) ||
            s.id.toLowerCase().includes(q) ||
            s.phone.toLowerCase().includes(q) ||
            s.assignedDesk.toLowerCase().includes(q)
        )
      : students;
    return list.slice(0, 8);
  }, [students, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md max-h-[94dvh] flex flex-col overflow-hidden shadow-2xl transition-all">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Daily Check-In / Out Kiosk</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Bharti Digital Library · Mandatory In/Out</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success or Error Overlay feedback */}
        {feedback.show ? (
          <div className="p-5 overflow-y-auto space-y-4">
            {feedback.error ? (
              <div className="py-4 text-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-600 mx-auto flex items-center justify-center">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">Not Found</h3>
                <p className="text-sm text-slate-600 dark:text-slate-300">{feedback.error}</p>
                <button
                  type="button"
                  onClick={resetToScanner}
                  className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 text-white text-xs font-semibold"
                >
                  Try Again
                </button>
              </div>
            ) : (
              <div className="space-y-3.5">
                {/* Status Banner */}
                {feedback.pendingConfirm && feedback.student ? (
                  <div className="p-3.5 rounded-2xl border bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
                        QR Verified · Confirm Attendance
                      </span>
                      <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-white/80 dark:bg-slate-900/80 text-slate-700 dark:text-slate-200">
                        {feedback.student.attendanceStatus === 'CHECKED_IN' ? 'Inside Hall' : 'Checked Out'}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-2 min-h-[40px]">
                        <span className="text-[11px] font-semibold text-slate-500">
                          {feedback.student.attendanceStatus === 'CHECKED_IN' ? 'Out Time:' : 'In Time:'}
                        </span>
                        <input
                          type="time"
                          value={kioskTimeInput}
                          onChange={e => setKioskTimeInput(e.target.value)}
                          className="bg-transparent text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleStudent(feedback.student!, 'QR_SCAN', kioskTimeInput)}
                        className={`flex-1 py-2.5 px-3 rounded-xl text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 min-h-[40px] transition-colors ${
                          feedback.student.attendanceStatus === 'CHECKED_IN'
                            ? 'bg-indigo-600 hover:bg-indigo-700'
                            : 'bg-emerald-600 hover:bg-emerald-700'
                        }`}
                      >
                        {feedback.student.attendanceStatus === 'CHECKED_IN' ? (
                          <LogOut className="w-4 h-4" />
                        ) : (
                          <LogIn className="w-4 h-4" />
                        )}
                        <span>
                          {feedback.student.attendanceStatus === 'CHECKED_IN'
                            ? 'Mark Out-Time'
                            : 'Mark In-Time'}
                        </span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`p-3 rounded-2xl border flex items-center gap-3 ${
                      feedback.action === 'IN'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
                        : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full shrink-0 flex items-center justify-center ${
                        feedback.action === 'IN'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-blue-600 text-white'
                      }`}
                    >
                      {feedback.action === 'IN' ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <LogOut className="w-5 h-5" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span
                        className={`text-[11px] font-bold uppercase tracking-wider block ${
                          feedback.action === 'IN'
                            ? 'text-emerald-700 dark:text-emerald-300'
                            : 'text-blue-700 dark:text-blue-300'
                        }`}
                      >
                        {feedback.action === 'IN'
                          ? 'In-Time Marked Successfully'
                          : 'Out-Time Marked Successfully'}
                      </span>
                      <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
                        Verified Student Full Details
                      </p>
                    </div>
                  </div>
                )}

                {/* Student Identity Card */}
                {feedback.student && (
                  <>
                    <div className="p-3.5 rounded-2xl bg-slate-900 dark:bg-slate-950 text-white flex items-center gap-3.5">
                      <img
                        src={resolveStudentAvatar(feedback.student.avatarUrl)}
                        alt={feedback.student.name}
                        className="w-14 h-14 rounded-xl object-cover border border-white/25 shrink-0 bg-slate-800"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0 flex-1">
                        <h3 className="text-base font-extrabold text-white truncate">
                          {feedback.student.name}
                        </h3>
                        <p className="text-xs font-mono text-slate-300 mt-0.5">
                          ID: {feedback.student.id} · PIN: {feedback.student.pin}
                        </p>
                        <p className="text-[11px] text-emerald-300 truncate mt-0.5">
                          {feedback.student.courseOrExam || 'Dedicated Study Scholar'}
                        </p>
                      </div>
                    </div>

                    {/* Desk, Locker & Contact Highlights */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 block">
                          Desk Slot
                        </span>
                        <strong className="text-sm font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
                          {feedback.student.assignedDesk}
                        </strong>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 block">
                          Locker
                        </span>
                        <strong className="text-sm font-extrabold font-mono text-slate-900 dark:text-white">
                          {feedback.student.lockerNumber || 'None'}
                        </strong>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
                        <span className="text-[10px] uppercase tracking-wider text-slate-500 block">
                          Visits (Mo)
                        </span>
                        <strong className="text-sm font-extrabold font-mono text-slate-900 dark:text-white">
                          {feedback.student.totalVisitsThisMonth}
                        </strong>
                      </div>
                    </div>

                    {/* Full Details Breakdown */}
                    <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          <span>Mobile</span>
                        </span>
                        <strong className="font-mono text-slate-900 dark:text-white">
                          {feedback.student.phone || 'Not provided'}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">Shift(s)</span>
                        <strong className="text-right text-slate-900 dark:text-white">
                          {formatStudentShifts(feedback.student.shifts, feedback.student.shift)}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">Admission Date</span>
                        <strong className="font-mono text-slate-900 dark:text-white">
                          {formatKioskDate(feedback.student.joinedDate)}
                        </strong>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500 flex items-center gap-1">
                          <IndianRupee className="w-3 h-3" />
                          <span>Monthly Fee</span>
                        </span>
                        <div className="flex items-center gap-1.5">
                          <strong className="font-mono text-slate-900 dark:text-white">
                            ₹{feedback.student.monthlyFee.toLocaleString('en-IN')}
                          </strong>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                              feedback.student.paymentStatus === 'PAID'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-200'
                                : feedback.student.paymentStatus === 'DUE_SOON'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200'
                                : 'bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-200'
                            }`}
                          >
                            {feedback.student.paymentStatus.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500 flex items-center gap-1">
                          <CalendarRange className="w-3 h-3" />
                          <span>Card Validity</span>
                        </span>
                        <strong className="font-mono text-slate-900 dark:text-white">
                          {formatKioskDate(
                            feedback.student.cardValidFrom ||
                              feedback.student.lastPaymentDate ||
                              feedback.student.joinedDate
                          )}{' '}
                          → {formatKioskDate(feedback.student.renewalDueDate)}
                        </strong>
                      </div>

                      {!feedback.pendingConfirm && (
                        <div className="pt-2 border-t border-slate-200 dark:border-slate-700 font-mono space-y-1.5">
                          <div className="flex justify-between">
                            <span className="text-slate-500">In Time:</span>
                            <strong className="text-emerald-600 dark:text-emerald-400">
                              {formatKioskTime(feedback.inTime)}
                            </strong>
                          </div>
                          {feedback.action === 'OUT' && (
                            <>
                              <div className="flex justify-between">
                                <span className="text-slate-500">Out Time:</span>
                                <strong className="text-indigo-600 dark:text-indigo-400">
                                  {formatKioskTime(feedback.outTime)}
                                </strong>
                              </div>
                              {feedback.durationMinutes !== undefined && (
                                <div className="flex justify-between">
                                  <span className="text-slate-500">Study Duration:</span>
                                  <strong className="text-slate-900 dark:text-white">
                                    {Math.floor(feedback.durationMinutes / 60)}h {feedback.durationMinutes % 60}m
                                  </strong>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                      )}
                    </div>

                    {(feedback.student.paymentStatus === 'OVERDUE' ||
                      feedback.student.paymentStatus === 'EXPIRED') && (
                      <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl text-left text-xs text-amber-800 dark:text-amber-300">
                        <strong>Payment Reminder:</strong> Your monthly fee was due on{' '}
                        {formatKioskDate(feedback.student.renewalDueDate)}. Please pay online in Student Portal.
                      </div>
                    )}
                  </>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={resetToScanner}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Done · Scan Next</span>
                  </button>
                  {!feedback.pendingConfirm && feedback.student && (
                    <button
                      type="button"
                      onClick={() => handleToggleStudent(feedback.student!, 'QR_SCAN')}
                      className="py-2.5 px-3 rounded-xl border border-indigo-200 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 text-xs font-semibold text-indigo-700 dark:text-indigo-300 inline-flex items-center gap-1 transition-colors"
                      title="Toggle attendance status again"
                    >
                      {feedback.action === 'IN' ? 'Mark Out' : 'Mark In'}
                    </button>
                  )}
                  {onViewFullCard && feedback.student && (
                    <button
                      type="button"
                      onClick={() => {
                        const target = feedback.student;
                        resetToScanner();
                        if (target) onViewFullCard(target);
                      }}
                      className="py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
                    >
                      <IdCard className="w-3.5 h-3.5" />
                      <span>ID Pass</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-6 space-y-5 overflow-y-auto">
            {/* Mode Switcher */}
            <div className="grid grid-cols-3 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setMode('PIN')}
                className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                  mode === 'PIN'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Hash className="w-3.5 h-3.5" />
                <span>4-Digit PIN</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('SEARCH')}
                className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                  mode === 'SEARCH'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>Name / Mobile</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('QR')}
                className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1 ${
                  mode === 'QR'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <Camera className="w-3.5 h-3.5" />
                <span>ID Scan</span>
              </button>
            </div>

            {mode === 'PIN' ? (
              <div className="space-y-4">
                <div className="text-center py-1">
                  <span className="text-xs text-slate-500 block mb-1.5">
                    Tap or type your 4-digit Student PIN to Check In / Check Out
                  </span>
                  <div className="h-12 flex items-center justify-center gap-2">
                    {[0, 1, 2, 3].map(i => (
                      <div
                        key={i}
                        className={`w-11 h-12 rounded-xl border flex items-center justify-center text-xl font-bold font-mono transition-all ${
                          pinInput[i]
                            ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-700 dark:text-indigo-400 shadow-sm'
                            : 'border-slate-200 dark:border-slate-700 text-slate-300'
                        }`}
                      >
                        {pinInput[i] || '·'}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Touch Keypad */}
                <div className="grid grid-cols-3 gap-2 max-w-xs mx-auto">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => handleKeypadPress(num)}
                      className="h-12 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-center active:scale-95 transition-all shadow-xs"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setPinInput('')}
                    className="h-12 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center justify-center active:scale-95"
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    onClick={() => handleKeypadPress('0')}
                    className="h-12 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-lg font-semibold text-slate-800 dark:text-slate-100 flex items-center justify-center active:scale-95 transition-all shadow-xs"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={handleBackspace}
                    className="h-12 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center justify-center active:scale-95"
                  >
                    ⌫ Delete
                  </button>
                </div>
              </div>
            ) : mode === 'SEARCH' ? (
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    autoFocus
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Type Name, Student ID, Desk, or Mobile..."
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[42px]"
                  />
                </div>
                <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl">
                  {matchedStudents.map(s => {
                    const isInside = s.attendanceStatus === 'CHECKED_IN';
                    return (
                      <div key={s.id} className="p-3 flex items-center justify-between gap-2 text-xs">
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white truncate">{s.name}</div>
                          <div className="text-[11px] font-mono text-slate-500">
                            {s.id} · Desk {s.assignedDesk}
                            {isInside && s.currentCheckInTime ? ` · In ${formatKioskTime(s.currentCheckInTime)}` : ''}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleStudent(s, 'PIN_KIOSK')}
                          className={`px-3 py-1.5 rounded-lg text-white font-bold text-xs shrink-0 transition-colors ${
                            isInside
                              ? 'bg-indigo-600 hover:bg-indigo-700'
                              : 'bg-emerald-600 hover:bg-emerald-700'
                          }`}
                        >
                          {isInside ? 'Mark Out-Time' : 'Mark In-Time'}
                        </button>
                      </div>
                    );
                  })}
                  {matchedStudents.length === 0 && (
                    <div className="p-6 text-center text-xs text-slate-500">No matching student found.</div>
                  )}
                </div>
              </div>
            ) : (
              <div className="space-y-3.5 text-center">
                {/* Scan Behavior Toggle */}
                <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-[11px] font-semibold">
                  <button
                    type="button"
                    onClick={() => setQrScanAction('AUTO')}
                    className={`py-1.5 rounded-lg transition-colors ${
                      qrScanAction === 'AUTO'
                        ? 'bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    Instant Mark on Scan
                  </button>
                  <button
                    type="button"
                    onClick={() => setQrScanAction('CONFIRM')}
                    className={`py-1.5 rounded-lg transition-colors ${
                      qrScanAction === 'CONFIRM'
                        ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-400 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    Scan Details → Mark
                  </button>
                </div>

                {/* Live Camera QR Scanner viewport box */}
                <div className="relative w-56 h-56 mx-auto rounded-2xl bg-slate-950 border-2 border-indigo-500 flex flex-col items-center justify-center overflow-hidden shadow-inner">
                  {cameraStatus === 'active' || cameraStatus === 'starting' ? (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        muted
                        className={`absolute inset-0 w-full h-full object-cover ${
                          facingMode === 'user' ? '-scale-x-100' : ''
                        }`}
                      />
                      <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/15 via-transparent to-indigo-500/15 pointer-events-none"></div>
                      {/* Scanner framing corners */}
                      <div className="absolute inset-5 border border-white/35 rounded-xl pointer-events-none"></div>
                      <div className="absolute left-5 right-5 h-0.5 bg-red-500 shadow-[0_0_10px_#ef4444] animate-bounce top-1/2 -translate-y-1/2 pointer-events-none"></div>
                      {cameraStatus === 'starting' && (
                        <div className="relative z-10 bg-slate-950/80 px-3 py-2 rounded-xl flex flex-col items-center gap-1.5">
                          <Camera className="w-6 h-6 text-indigo-400 animate-pulse" />
                          <p className="text-[11px] text-slate-200 font-medium">
                            Allow camera access...
                          </p>
                        </div>
                      )}
                      {cameraStatus === 'active' && (
                        <p className="absolute bottom-2 inset-x-2 text-[10px] text-white font-medium bg-slate-950/75 rounded-lg py-1 px-2 z-10">
                          Scanning · Hold ID QR in frame
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/15 via-transparent to-indigo-500/15 pointer-events-none"></div>
                      <QrCode className="w-14 h-14 text-slate-400/70" />
                      <p className="text-[11px] text-slate-200 font-medium mt-2.5 px-3 z-10 leading-snug">
                        {cameraError || 'Allow camera access to scan Student Digital ID'}
                      </p>
                    </>
                  )}
                </div>

                {scanWarning && (
                  <p className="text-[11px] font-medium text-amber-600 dark:text-amber-400 px-2">
                    {scanWarning}
                  </p>
                )}

                <input
                  ref={qrFileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleQrImageUpload}
                  className="hidden"
                />

                {/* Camera Controls */}
                <div className="flex items-center justify-center gap-2">
                  {cameraStatus === 'active' ? (
                    <button
                      type="button"
                      onClick={() =>
                        setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'))
                      }
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
                    >
                      <SwitchCamera className="w-3.5 h-3.5" />
                      <span>{facingMode === 'environment' ? 'Rear Cam' : 'Front Cam'}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={startQrCamera}
                      className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow-xs transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Enable Camera</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => qrFileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Scan QR Photo</span>
                  </button>
                </div>

                <div className="text-xs text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span>Or quick test with a sample student pass:</span>
                  <div className="flex flex-wrap justify-center gap-1.5 mt-2">
                    {students.slice(0, 3).map(s => (
                      <button
                        type="button"
                        key={s.id}
                        onClick={() =>
                          qrScanAction === 'CONFIRM'
                            ? handleReviewScannedStudent(s)
                            : handleToggleStudent(s, 'QR_SCAN')
                        }
                        className="px-2.5 py-1 text-[11px] bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-700 dark:text-slate-300 rounded-md font-mono transition-colors"
                      >
                        Scan {s.name.split(' ')[0]} ({s.assignedDesk})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 text-center flex items-center justify-between">
          <span className="inline-flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            <span>Mandatory: In-Time on entry & Out-Time on exit</span>
          </span>
          <span className="font-mono text-emerald-600 dark:text-emerald-400">● Active</span>
        </div>
      </div>
    </div>
  );
};
