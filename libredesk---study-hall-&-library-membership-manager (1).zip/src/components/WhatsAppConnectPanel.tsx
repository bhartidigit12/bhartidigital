import React, { useState, useEffect, useMemo } from 'react';
import {
  MessageSquare,
  CheckCircle2,
  Send,
  Copy,
  Check,
  Search,
  Lock,
  ExternalLink,
  Eye,
  AlertCircle,
  Play,
  SkipForward,
  X,
  Phone,
  Link2,
} from 'lucide-react';
import { Student, LibrarySettings, PushReminder } from '../types';
import {
  buildStudentWhatsAppUrl,
  formatWhatsAppPhoneDisplay,
  normalizeWhatsAppPhone,
  sounds,
} from '../utils/notifications';
import { generateQrDataUrl } from '../utils/qr';

interface WhatsAppConnectPanelProps {
  students: Student[];
  reminders: PushReminder[];
  settings: LibrarySettings;
  isAdmin: boolean;
  onRequireAdmin: () => void;
  onUpdateSettings?: (updates: Partial<LibrarySettings>) => void;
  onDispatchWhatsAppReminder: (student: Student, message: string) => void;
}

function getLocalTodayStr(): string {
  const dt = new Date();
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

export const WhatsAppConnectPanel: React.FC<WhatsAppConnectPanelProps> = ({
  students,
  reminders,
  settings,
  isAdmin,
  onRequireAdmin,
  onUpdateSettings,
  onDispatchWhatsAppReminder,
}) => {
  const [waNumberInput, setWaNumberInput] = useState(
    settings.whatsappNumber || settings.phone || '9973299354'
  );
  const [waBusinessInput, setWaBusinessInput] = useState(
    settings.whatsappBusinessName || settings.name || 'Bharti Digital Library'
  );
  const [waIncludeUpi, setWaIncludeUpi] = useState(settings.whatsappIncludeUpi !== false);
  const [waIncludeLink, setWaIncludeLink] = useState(settings.whatsappIncludePortalLink !== false);
  const [waCustomNote, setWaCustomNote] = useState(
    settings.whatsappCustomNote ||
      'Kindly clear your dues by the due date to keep your reserved desk active.'
  );
  const [waConnected, setWaConnected] = useState(settings.whatsappConnected !== false);
  const [savedToast, setSavedToast] = useState(false);
  const [waQrUrl, setWaQrUrl] = useState<string>('');

  const [filterMode, setFilterMode] = useState<'ALL_DUE' | 'OVERDUE' | 'DUE_SOON' | 'NOT_SENT'>('ALL_DUE');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [previewStudentId, setPreviewStudentId] = useState<string | null>(null);

  // Guided batch dispatch queue
  const [queueIds, setQueueIds] = useState<string[] | null>(null);
  const [queueIdx, setQueueIdx] = useState<number>(0);

  useEffect(() => {
    setWaNumberInput(settings.whatsappNumber || settings.phone || '9973299354');
    setWaBusinessInput(settings.whatsappBusinessName || settings.name || 'Bharti Digital Library');
    setWaIncludeUpi(settings.whatsappIncludeUpi !== false);
    setWaIncludeLink(settings.whatsappIncludePortalLink !== false);
    setWaCustomNote(
      settings.whatsappCustomNote ||
        'Kindly clear your dues by the due date to keep your reserved desk active.'
    );
    setWaConnected(settings.whatsappConnected !== false);
  }, [settings]);

  useEffect(() => {
    const normalized = normalizeWhatsAppPhone(waNumberInput);
    if (normalized.length >= 10) {
      generateQrDataUrl(`https://wa.me/${normalized}`, 180).then(setWaQrUrl);
    } else {
      setWaQrUrl('');
    }
  }, [waNumberInput]);

  const todayStr = getLocalTodayStr();

  const sentTodaySet = useMemo(() => {
    const ids = new Set<string>();
    reminders.forEach(r => {
      if (r.channel === 'WHATSAPP' && r.sentAt.startsWith(todayStr)) {
        ids.add(r.studentId);
      }
    });
    return ids;
  }, [reminders, todayStr]);

  const pendingDueStudents = useMemo(
    () =>
      students.filter(
        s =>
          s.paymentStatus === 'OVERDUE' ||
          s.paymentStatus === 'DUE_SOON' ||
          s.paymentStatus === 'EXPIRED'
      ),
    [students]
  );

  const filteredStudents = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return pendingDueStudents.filter(s => {
      if (filterMode === 'OVERDUE' && s.paymentStatus !== 'OVERDUE' && s.paymentStatus !== 'EXPIRED') {
        return false;
      }
      if (filterMode === 'DUE_SOON' && s.paymentStatus !== 'DUE_SOON') {
        return false;
      }
      if (filterMode === 'NOT_SENT' && sentTodaySet.has(s.id)) {
        return false;
      }
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.assignedDesk.toLowerCase().includes(q) ||
        s.phone.toLowerCase().includes(q)
      );
    });
  }, [pendingDueStudents, filterMode, searchQuery, sentTodaySet]);

  const overdueCount = pendingDueStudents.filter(
    s => s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'EXPIRED'
  ).length;
  const dueSoonCount = pendingDueStudents.filter(s => s.paymentStatus === 'DUE_SOON').length;
  const dispatchedTodayCount = pendingDueStudents.filter(s => sentTodaySet.has(s.id)).length;

  const livePreviewSettings: LibrarySettings = {
    ...settings,
    whatsappConnected: waConnected,
    whatsappNumber: waNumberInput.trim() || settings.phone,
    whatsappBusinessName: waBusinessInput.trim() || settings.name,
    whatsappIncludeUpi: waIncludeUpi,
    whatsappIncludePortalLink: waIncludeLink,
    whatsappCustomNote: waCustomNote.trim(),
  };

  const handleSaveWhatsAppConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      onRequireAdmin();
      return;
    }
    const cleanNum = waNumberInput.trim() || settings.phone;
    setWaConnected(true);
    onUpdateSettings?.({
      whatsappConnected: true,
      whatsappNumber: cleanNum,
      whatsappBusinessName: waBusinessInput.trim() || settings.name,
      whatsappIncludeUpi: waIncludeUpi,
      whatsappIncludePortalLink: waIncludeLink,
      whatsappCustomNote: waCustomNote.trim(),
    });
    sounds.playSuccess();
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  const handleToggleConnection = () => {
    if (!isAdmin) {
      onRequireAdmin();
      return;
    }
    const nextState = !waConnected;
    setWaConnected(nextState);
    onUpdateSettings?.({
      whatsappConnected: nextState,
      whatsappNumber: waNumberInput.trim() || settings.phone,
    });
    sounds.playSuccess();
  };

  const handleCopyMessage = (studentId: string, msg: string) => {
    navigator.clipboard.writeText(msg);
    setCopiedId(studentId);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleStartQueue = () => {
    if (!isAdmin) {
      onRequireAdmin();
      return;
    }
    const targets = filteredStudents.filter(s => !sentTodaySet.has(s.id));
    const list = (targets.length > 0 ? targets : filteredStudents).map(s => s.id);
    if (list.length === 0) return;
    setQueueIds(list);
    setQueueIdx(0);
  };

  const currentQueuedStudent =
    queueIds && queueIdx < queueIds.length
      ? students.find(s => s.id === queueIds[queueIdx]) || null
      : null;

  const advanceQueue = () => {
    if (!queueIds) return;
    if (queueIdx + 1 >= queueIds.length) {
      setQueueIds(null);
      setQueueIdx(0);
      sounds.playSuccess();
    } else {
      setQueueIdx(queueIdx + 1);
    }
  };

  const normalizedOwnWa = normalizeWhatsAppPhone(waNumberInput);
  const testOwnWaUrl = normalizedOwnWa
    ? `https://wa.me/${normalizedOwnWa}?text=${encodeURIComponent(
        `[${waBusinessInput || settings.name}] WhatsApp Fee Reminder dispatch is connected and ready!`
      )}`
    : 'https://wa.me/';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Column: Connect Our Library WhatsApp */}
      <div className="lg:col-span-5 p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-start justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3.5">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>Connect Our Library WhatsApp</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Configure your WhatsApp Business / official number for dispatching student fee reminders.
            </p>
          </div>
          <span
            className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wide shrink-0 ${
              waConnected
                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
            }`}
          >
            {waConnected ? '● Connected' : 'Paused'}
          </span>
        </div>

        {/* Connected WhatsApp Identity & QR Link */}
        <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/25 border border-emerald-200/80 dark:border-emerald-900/50 flex items-center gap-3.5">
          {waQrUrl ? (
            <div className="p-1.5 rounded-xl bg-white border border-emerald-200 shrink-0">
              <img src={waQrUrl} alt="Library WhatsApp QR" className="w-16 h-16" />
            </div>
          ) : null}
          <div className="min-w-0 flex-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
              Official Sender WhatsApp
            </span>
            <div className="text-sm font-extrabold font-mono text-slate-900 dark:text-white mt-0.5 truncate">
              {formatWhatsAppPhoneDisplay(waNumberInput)}
            </div>
            <div className="text-[11px] text-slate-600 dark:text-slate-300 truncate">
              {waBusinessInput || settings.name}
            </div>
            <a
              href={testOwnWaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-300 hover:underline mt-1"
            >
              <ExternalLink className="w-3 h-3" />
              <span>Open / Test WhatsApp Web</span>
            </a>
          </div>
        </div>

        <form onSubmit={handleSaveWhatsAppConfig} className="space-y-3.5">
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Our WhatsApp Number (10-digit Indian Mobile) *
            </label>
            <div className="relative">
              <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="tel"
                required
                disabled={!isAdmin}
                value={waNumberInput}
                onChange={e => setWaNumberInput(e.target.value)}
                placeholder="9973299354"
                className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tabular-nums text-slate-900 dark:text-white disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Business Signature Name
            </label>
            <input
              type="text"
              disabled={!isAdmin}
              value={waBusinessInput}
              onChange={e => setWaBusinessInput(e.target.value)}
              placeholder="Bharti Digital Library"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 cursor-pointer">
              <input
                type="checkbox"
                disabled={!isAdmin}
                checked={waIncludeUpi}
                onChange={e => setWaIncludeUpi(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200">
                Include UPI ID ({settings.upiId || '9973299354@ybl'}) &amp; PhonePe details
              </span>
            </label>

            <label className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/70 cursor-pointer">
              <input
                type="checkbox"
                disabled={!isAdmin}
                checked={waIncludeLink}
                onChange={e => setWaIncludeLink(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span className="text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1">
                <Link2 className="w-3.5 h-3.5 text-indigo-500" />
                <span>Include Student Digital Pass &amp; Pay Link</span>
              </span>
            </label>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Custom Reminder Footer Note
            </label>
            <textarea
              rows={2}
              disabled={!isAdmin}
              value={waCustomNote}
              onChange={e => setWaCustomNote(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white disabled:opacity-60 focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
            />
          </div>

          {savedToast && (
            <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-xs text-emerald-700 dark:text-emerald-300 font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Library WhatsApp connected &amp; reminder template saved!</span>
            </div>
          )}

          <div className="flex items-center justify-between gap-2 pt-1">
            <button
              type="button"
              onClick={handleToggleConnection}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
            >
              {waConnected ? 'Pause' : 'Reconnect'}
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors min-h-[42px]"
            >
              {isAdmin ? <CheckCircle2 className="w-4 h-4" /> : <Lock className="w-3.5 h-3.5" />}
              <span>{isAdmin ? 'Connect & Save WhatsApp' : 'Unlock Admin to Connect'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Right Column: Student WhatsApp Fee Reminder Dispatch Console */}
      <div className="lg:col-span-7 p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3.5">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Dispatch Fee Reminders to Student WhatsApp
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              <strong className="text-rose-600 dark:text-rose-400">{overdueCount} Overdue</strong> ·{' '}
              <strong className="text-amber-600 dark:text-amber-400">{dueSoonCount} Due Soon</strong> ·{' '}
              <strong className="text-emerald-600 dark:text-emerald-400">{dispatchedTodayCount} Sent Today</strong>
            </p>
          </div>

          <button
            type="button"
            disabled={!waConnected || filteredStudents.length === 0}
            onClick={handleStartQueue}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
          >
            <Play className="w-3.5 h-3.5" />
            <span>
              Start WhatsApp Dispatch Queue ({filteredStudents.filter(s => !sentTodaySet.has(s.id)).length || filteredStudents.length})
            </span>
          </button>
        </div>

        {!waConnected && (
          <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>WhatsApp connection is paused. Click &ldquo;Reconnect&rdquo; or save settings on the left to dispatch reminders.</span>
          </div>
        )}

        {/* Active Guided Sequential Queue Panel */}
        {currentQueuedStudent && queueIds && (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/35 border-2 border-emerald-500/70 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-mono text-[11px] font-bold">
                  Queue {queueIdx + 1} / {queueIds.length}
                </span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {currentQueuedStudent.name} ({currentQueuedStudent.id} · Desk {currentQueuedStudent.assignedDesk})
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setQueueIds(null);
                  setQueueIdx(0);
                }}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                title="Stop Queue"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {(() => {
              const info = buildStudentWhatsAppUrl(currentQueuedStudent, livePreviewSettings);
              return (
                <>
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-[11px] text-slate-700 dark:text-slate-200 whitespace-pre-wrap max-h-40 overflow-y-auto font-sans">
                    {info.message}
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <a
                      href={info.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        onDispatchWhatsAppReminder(currentQueuedStudent, info.message);
                        advanceQueue();
                      }}
                      className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send to {info.formattedPhone} &amp; Next →</span>
                    </a>
                    <button
                      type="button"
                      onClick={advanceQueue}
                      className="px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1"
                    >
                      <SkipForward className="w-3.5 h-3.5" />
                      <span>Skip</span>
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        )}

        {/* Filter Bar + Search */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex flex-wrap gap-1.5">
            {(
              [
                { id: 'ALL_DUE', label: `All Pending (${pendingDueStudents.length})` },
                { id: 'OVERDUE', label: `Overdue (${overdueCount})` },
                { id: 'DUE_SOON', label: `Due Soon (${dueSoonCount})` },
                { id: 'NOT_SENT', label: 'Not Sent Today' },
              ] as const
            ).map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterMode(tab.id)}
                className={`px-2.5 py-1.5 rounded-xl text-[11px] font-semibold transition-colors ${
                  filterMode === tab.id
                    ? 'bg-slate-900 dark:bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search student / desk / phone..."
              className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none w-full sm:w-48"
            />
          </div>
        </div>

        {/* Pending Student WhatsApp Dispatch List */}
        {filteredStudents.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs text-slate-500">
            No pending fee reminders match this filter.
          </div>
        ) : (
          <div className="max-h-[460px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200/80 dark:border-slate-800 rounded-2xl">
            {filteredStudents.map(student => {
              const waInfo = buildStudentWhatsAppUrl(student, livePreviewSettings);
              const isSentToday = sentTodaySet.has(student.id);
              const isExpanded = previewStudentId === student.id;
              return (
                <div key={student.id} className="p-3.5 space-y-2.5 hover:bg-slate-50/70 dark:hover:bg-slate-800/30">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                          {student.name}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                            student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED'
                              ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                              : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                          }`}
                        >
                          {student.paymentStatus.replace('_', ' ')}
                        </span>
                        {isSentToday && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                            ✓ Sent Today
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-0.5">
                        {student.id} · Desk {student.assignedDesk} · {waInfo.formattedPhone} · Due {student.renewalDueDate} ·{' '}
                        <strong className="text-slate-800 dark:text-slate-200">
                          ₹{student.monthlyFee.toLocaleString('en-IN')}
                        </strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => setPreviewStudentId(isExpanded ? null : student.id)}
                        className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                        title="Preview WhatsApp Reminder Message"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCopyMessage(student.id, waInfo.message)}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1 transition-colors"
                        title="Copy Reminder Message"
                      >
                        {copiedId === student.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedId === student.id ? 'Copied' : 'Copy'}</span>
                      </button>

                      <a
                        href={waInfo.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={e => {
                          if (!waConnected) {
                            e.preventDefault();
                            return;
                          }
                          onDispatchWhatsAppReminder(student, waInfo.message);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-[11px] font-bold inline-flex items-center gap-1 transition-colors ${
                          waConnected
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Send WhatsApp</span>
                      </a>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-700 dark:text-slate-300 whitespace-pre-wrap">
                      {waInfo.message}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
