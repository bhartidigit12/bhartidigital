import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ShieldCheck, 
  Sparkles, 
  Smartphone, 
  QrCode, 
  ExternalLink,
  ArrowRight,
  Camera
} from 'lucide-react';
import { ShiftType, PlanType, StudentApplication, LibrarySettings, Student, SHIFT_LIST, formatStudentShifts, calculateShiftFee, getTotalShiftHours } from '../types';
import { sounds, sendBrowserPushNotification } from '../utils/notifications';
import { CameraCaptureModal } from './CameraCaptureModal';
import confetti from 'canvas-confetti';

interface StudentSelfRegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitApplication: (app: Omit<StudentApplication, 'id' | 'submittedAt' | 'status'>) => StudentApplication;
  applications: StudentApplication[];
  students: Student[];
  settings: LibrarySettings;
  onViewStudentCard: (student: Student) => void;
}

export const StudentSelfRegisterModal: React.FC<StudentSelfRegisterModalProps> = ({
  isOpen,
  onClose,
  onSubmitApplication,
  applications,
  students,
  settings,
  onViewStudentCard,
}) => {
  const [tab, setTab] = useState<'REGISTER' | 'TRACK'>('REGISTER');
  
  // Registration form state
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [courseOrExam, setCourseOrExam] = useState('Civil Services / UPSC');
  const [desiredShifts, setDesiredShifts] = useState<ShiftType[]>(['DAY_9TO5']);
  const [desiredPlan, setDesiredPlan] = useState<PlanType>('MONTHLY_FULL_DAY');
  const [deskPreference, setDeskPreference] = useState('Zone A (Quiet AC)');
  const [hasLocker, setHasLocker] = useState(false);
  const [govtIdType, setGovtIdType] = useState('Aadhaar / National ID');
  const [govtIdNumber, setGovtIdNumber] = useState('');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  // Post-submission state
  const [submittedApp, setSubmittedApp] = useState<StudentApplication | null>(null);

  // Tracking tab state
  const [trackQuery, setTrackQuery] = useState('');
  const [trackedResult, setTrackedResult] = useState<{
    app?: StudentApplication;
    student?: Student;
    searched: boolean;
  }>({ searched: false });

  if (!isOpen) return null;

  const handleToggleShift = (shiftId: ShiftType) => {
    if (desiredShifts.includes(shiftId)) {
      if (desiredShifts.length > 1) {
        setDesiredShifts(desiredShifts.filter(s => s !== shiftId));
      }
    } else {
      if (shiftId === 'TWENTY_FOUR_HOURS') {
        setDesiredShifts(['TWENTY_FOUR_HOURS']);
      } else {
        const without24 = desiredShifts.filter(s => s !== 'TWENTY_FOUR_HOURS');
        setDesiredShifts([...without24, shiftId]);
      }
    }
  };

  const handleSelectPreset = (presetShifts: ShiftType[]) => {
    setDesiredShifts(presetShifts);
  };

  const estimatedFee = calculateShiftFee(desiredShifts, settings.monthlyFees, desiredPlan, hasLocker);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phone.trim() || !govtIdNumber.trim() || desiredShifts.length === 0) return;

    const newApp = onSubmitApplication({
      fullName: fullName.trim(),
      phone: phone.trim(),
      email: email.trim() || `${fullName.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      courseOrExam,
      desiredShift: desiredShifts[0],
      desiredShifts,
      desiredPlan,
      deskPreference,
      hasLocker,
      govtIdType,
      govtIdNumber: govtIdNumber.trim(),
      avatarUrl: capturedPhoto || undefined,
    });

    sounds.playSuccess();
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    sendBrowserPushNotification(
      '📥 New Student Registration Received',
      `${fullName} applied for ${formatStudentShifts(desiredShifts)}. Awaiting admin review.`
    );

    setSubmittedApp(newApp);
  };

  const handleTrackSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = trackQuery.trim().toLowerCase();
    if (!query) return;

    // Search in applications
    const foundApp = applications.find(
      a => a.phone.replace(/\D/g, '').includes(query.replace(/\D/g, '')) ||
           a.id.toLowerCase() === query ||
           a.fullName.toLowerCase().includes(query)
    );

    // Search in approved students
    const foundStudent = students.find(
      s => s.phone.replace(/\D/g, '').includes(query.replace(/\D/g, '')) ||
           s.id.toLowerCase() === query ||
           s.name.toLowerCase().includes(query)
    );

    setTrackedResult({
      app: foundApp,
      student: foundStudent,
      searched: true,
    });
  };

  const resetForm = () => {
    setSubmittedApp(null);
    setFullName('');
    setPhone('');
    setEmail('');
    setGovtIdNumber('');
    setCapturedPhoto(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-start sm:items-center justify-center p-2.5 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg max-h-[94dvh] flex flex-col overflow-hidden shadow-2xl my-auto transition-all">
        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <UserPlus className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Student Registration Portal</h2>
              <p className="text-xs text-slate-500">{settings.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-4 sm:px-6 pt-3 border-b border-slate-100 dark:border-slate-800 flex gap-4 text-xs font-semibold shrink-0">
          <button
            onClick={() => { setTab('REGISTER'); setSubmittedApp(null); }}
            className={`pb-2.5 transition-colors border-b-2 ${
              tab === 'REGISTER'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Self-Register Form
          </button>
          <button
            onClick={() => setTab('TRACK')}
            className={`pb-2.5 transition-colors border-b-2 ${
              tab === 'TRACK'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Check Application Status
          </button>
        </div>

        {/* Tab 1: Self Register */}
        {tab === 'REGISTER' ? (
          submittedApp ? (
            <div className="p-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mx-auto flex items-center justify-center">
                <Clock className="w-8 h-8" />
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                  Application Under Admin Review
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                  Thank you, {submittedApp.fullName}!
                </h3>
                <div className="mt-3 p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 text-left text-xs font-mono space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Application ID:</span>
                    <strong className="text-indigo-600 dark:text-indigo-400">{submittedApp.id}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Desired Shift(s):</span>
                    <strong className="text-slate-900 dark:text-slate-100">
                      {formatStudentShifts(submittedApp.desiredShifts, submittedApp.desiredShift)}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Seat Preference:</span>
                    <span>{submittedApp.deskPreference}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Status:</span>
                    <span className="text-amber-600 font-bold">Pending Admin Approval</span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Admin Raj has been notified. Once approved, your dedicated desk and 4-digit Entry PIN will be activated.
              </p>

              <div className="pt-2 flex items-center justify-center gap-3">
                <button
                  onClick={resetForm}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  Submit Another
                </button>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white font-bold text-xs"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-3.5 sm:space-y-4 overflow-y-auto flex-1 overscroll-contain">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder="e.g. Ramesh Chandra"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Mobile / WhatsApp No. *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+91 98765 00000"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="p-2.5 sm:p-3 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 text-xs text-indigo-900 dark:text-indigo-300 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Fill your details below. Library admin will verify your ID proof and approve your desk.</span>
              </div>

              <div className="flex items-center justify-between gap-3 p-2.5 sm:p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl overflow-hidden bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 shrink-0 flex items-center justify-center">
                    {capturedPhoto ? (
                      <img src={capturedPhoto} alt="Student selfie" className="w-full h-full object-cover" />
                    ) : (
                      <Camera className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 dark:text-white block">
                      Your Pass Photo
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {capturedPhoto ? 'Photo captured for ID card' : 'Take a quick selfie with camera'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsCameraOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{capturedPhoto ? 'Retake' : 'Open Camera'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="student@example.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Target Exam / Goal *
                  </label>
                  <select
                    value={courseOrExam}
                    onChange={e => setCourseOrExam(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Civil Services / UPSC">Civil Services / UPSC</option>
                    <option value="Medical School / NEET PG">Medical School / NEET PG</option>
                    <option value="SSC CGL / Banking / Railways">SSC CGL / Banking / Railways</option>
                    <option value="State PSC / Judiciary">State PSC / Judiciary</option>
                    <option value="Chartered Accountancy / CA / CFA">Chartered Accountancy / CA / CFA</option>
                    <option value="GATE / Engineering PG">GATE / Engineering PG</option>
                    <option value="Remote Software / Freelance">Remote Software / Freelance</option>
                    <option value="University / College Exams">University / College Exams</option>
                  </select>
                </div>
              </div>

              {/* Multi-shift selection panel */}
              <div className="space-y-2 p-3.5 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Select Study Shift(s) *
                  </label>
                  <span className="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold">
                    Multiple selections allowed
                  </span>
                </div>

                {/* Quick Presets */}
                <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                  <span className="text-slate-400 text-[10px] uppercase font-mono mr-1">Quick Slots:</span>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['AFTERNOON'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.length === 1 && desiredShifts[0] === 'AFTERNOON'
                        ? 'bg-orange-600 text-white border-orange-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    4 Hr (₹300)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['MORNING'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.length === 1 && desiredShifts[0] === 'MORNING'
                        ? 'bg-amber-600 text-white border-amber-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    6 Hr (₹400)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['DAY_9TO5'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.length === 1 && desiredShifts[0] === 'DAY_9TO5'
                        ? 'bg-emerald-600 text-white border-emerald-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    8 Hr · 9AM-5PM (₹500)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['TWELVE_HOURS'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.length === 1 && desiredShifts[0] === 'TWELVE_HOURS'
                        ? 'bg-cyan-600 text-white border-cyan-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    12 Hr (₹700)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['TWENTY_FOUR_HOURS'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.length === 1 && desiredShifts[0] === 'TWENTY_FOUR_HOURS'
                        ? 'bg-purple-600 text-white border-purple-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    24 Hr · 9AM-9AM (₹800)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectPreset(['MORNING', 'EVENING'])}
                    className={`px-2 py-1 rounded-lg border transition-all ${
                      desiredShifts.includes('MORNING') && desiredShifts.includes('EVENING') && desiredShifts.length === 2
                        ? 'bg-indigo-600 text-white border-indigo-600 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    Morning+Eve (12h · ₹700)
                  </button>
                </div>

                {/* Shift Chips Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {SHIFT_LIST.map(shiftDef => {
                    const isSelected = desiredShifts.includes(shiftDef.id);
                    return (
                      <button
                        type="button"
                        key={shiftDef.id}
                        onClick={() => handleToggleShift(shiftDef.id)}
                        className={`p-2.5 rounded-xl border text-left transition-all flex items-start justify-between gap-2 ${
                          isSelected
                            ? 'border-indigo-600 dark:border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 shadow-xs'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className={`w-3.5 h-3.5 rounded-md flex items-center justify-center text-[10px] border ${
                              isSelected
                                ? 'bg-indigo-600 border-indigo-600 text-white font-bold'
                                : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-700'
                            }`}>
                              {isSelected ? '✓' : ''}
                            </span>
                            <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                              {shiftDef.shortLabel}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 pl-5">
                            {shiftDef.timing} ({shiftDef.hours}h)
                          </p>
                        </div>
                        <span className="text-[11px] font-mono font-semibold text-indigo-700 dark:text-indigo-300 shrink-0">
                          ₹{settings.monthlyFees[shiftDef.id] || shiftDef.defaultFee}/m
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Summary Strip */}
                <div className="mt-2 p-2.5 rounded-xl bg-indigo-100/60 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-mono">
                      Selected: {getTotalShiftHours(desiredShifts)} Hours/Day ({desiredShifts.length} slot{desiredShifts.length > 1 ? 's' : ''})
                    </span>
                    <strong className="text-indigo-900 dark:text-indigo-200 font-semibold">
                      {formatStudentShifts(desiredShifts)}
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 dark:text-slate-400 block text-[10px] uppercase font-mono">
                      Shift Monthly Fee
                    </span>
                    <strong className="text-emerald-700 dark:text-emerald-400 font-bold font-mono text-sm">
                      ₹{estimatedFee}/mo
                    </strong>
                  </div>
                </div>
              </div>

              {/* Desk & Seating Preference */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Desk / Seating Preference
                </label>
                <select
                  value={deskPreference}
                  onChange={e => setDeskPreference(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Zone A (Quiet AC)">Zone A (Quiet AC Cubicle)</option>
                  <option value="Window Seat / Natural Light">Window Seat / Natural Light</option>
                  <option value="Near Power Socket">Near Dedicated Power Socket</option>
                  <option value="Corner Desk / Privacy">Corner Desk / Extra Privacy</option>
                  <option value="Any Available Seat">Any Available Seat</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Government / College ID Type *
                  </label>
                  <select
                    value={govtIdType}
                    onChange={e => setGovtIdType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Aadhaar / National ID">Aadhaar / National ID</option>
                    <option value="College / University ID">College / University ID</option>
                    <option value="Driving License">Driving License</option>
                    <option value="Voter ID Card">Voter ID Card</option>
                    <option value="Passport">Passport</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    ID Number / Roll Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={govtIdNumber}
                    onChange={e => setGovtIdNumber(e.target.value)}
                    placeholder="Enter ID / Roll number"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                <input
                  type="checkbox"
                  id="selfLocker"
                  checked={hasLocker}
                  onChange={e => setHasLocker(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded"
                />
                <label htmlFor="selfLocker" className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  Request personal book locker space
                </label>
              </div>

              {/* Submit */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all"
                >
                  <span>Submit for Admin Approval</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )
        ) : (
          /* Tab 2: Track status */
          <div className="p-4 sm:p-6 space-y-4 overflow-y-auto flex-1 overscroll-contain">
            <form onSubmit={handleTrackSearch} className="flex gap-2">
              <input
                type="text"
                required
                value={trackQuery}
                onChange={e => setTrackQuery(e.target.value)}
                placeholder="Enter your Mobile No. or Application ID..."
                className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white font-semibold text-xs flex items-center gap-1.5"
              >
                <Search className="w-3.5 h-3.5" />
                <span>Search</span>
              </button>
            </form>

            {trackedResult.searched && (
              <div className="space-y-3 pt-2">
                {trackedResult.student ? (
                  <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Application Approved & Active!
                      </span>
                      <span className="font-mono text-emerald-700 font-bold">
                        Desk: {trackedResult.student.assignedDesk}
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">
                      Welcome, <strong>{trackedResult.student.name}</strong>! Your admission has been approved (Admission Date: <strong className="font-mono">{trackedResult.student.joinedDate}</strong>). Your 4-digit Entry PIN is <strong className="font-mono text-indigo-600">{trackedResult.student.pin}</strong>.
                    </p>
                    <button
                      onClick={() => {
                        onClose();
                        onViewStudentCard(trackedResult.student!);
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>Open My Digital Student ID Pass</span>
                    </button>
                  </div>
                ) : trackedResult.app ? (
                  <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-amber-600" />
                        Application In Review
                      </span>
                      <span className="font-mono text-slate-500">{trackedResult.app.id}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">
                      Hi <strong>{trackedResult.app.fullName}</strong>, your application submitted on {trackedResult.app.submittedAt.split('T')[0]} is currently pending verification by library management.
                    </p>
                    <div className="text-[11px] text-slate-500">
                      Requested Shift(s): <strong className="text-slate-700 dark:text-slate-300">{formatStudentShifts(trackedResult.app.desiredShifts, trackedResult.app.desiredShift)}</strong> · {trackedResult.app.deskPreference}
                    </div>
                  </div>
                ) : (
                  <div className="p-6 text-center text-slate-400 text-xs">
                    No application or membership found for "{trackQuery}". Please double check your mobile number or submit a new registration.
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        studentName={fullName}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => setCapturedPhoto(dataUrl)}
      />
    </div>
  );
};
