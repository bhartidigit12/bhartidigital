import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  LogOut,
  LogIn,
  Phone,
  Mail,
  BookOpen,
  CalendarRange,
  IndianRupee,
  Clock,
  IdCard,
  ShieldCheck,
  KeyRound,
  Armchair,
  Lock,
  TrendingUp,
} from 'lucide-react';
import { Student, AttendanceRecord, LibrarySettings, formatStudentShifts } from '../types';
import { resolveStudentAvatar } from '../utils/assets';
import { sounds } from '../utils/notifications';

interface ScannedStudentDetailModalProps {
  student: Student | null;
  attendanceRecords?: AttendanceRecord[];
  settings: LibrarySettings;
  onClose: () => void;
  onOpenDigitalPass: (student: Student) => void;
  onCheckInToggle: (
    studentId: string,
    method: 'QR_SCAN' | 'PIN_KIOSK' | 'STAFF_MANUAL' | 'BIOMETRIC_SIM',
    customTimeHHMM?: string
  ) => {
    success: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
    message?: string;
  };
}

const MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatDateReadable(iso?: string): string {
  if (!iso) return 'Pending';
  const clean = iso.slice(0, 10);
  const parts = clean.split('-');
  if (parts.length !== 3) return iso;
  const [year, monthStr, day] = parts;
  const monthIdx = parseInt(monthStr, 10) - 1;
  return `${day} ${MONTHS_SHORT[monthIdx] || monthStr} ${year}`;
}

function formatTimeReadable(isoStr?: string): string {
  if (!isoStr) return '—';
  if (/^\d{2}:\d{2}$/.test(isoStr)) {
    const [hStr, mStr] = isoStr.split(':');
    const h = Number(hStr);
    const period = h >= 12 ? 'PM' : 'AM';
    const hour12 = h % 12 === 0 ? 12 : h % 12;
    return `${String(hour12).padStart(2, '0')}:${mStr} ${period}`;
  }
  const dt = new Date(isoStr);
  if (!Number.isNaN(dt.getTime())) {
    return dt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  }
  return isoStr;
}

function getCurrentHHMM(): string {
  const dt = new Date();
  return `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
}

function getLocalTodayStr(): string {
  const dt = new Date();
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

export const ScannedStudentDetailModal: React.FC<ScannedStudentDetailModalProps> = ({
  student,
  attendanceRecords = [],
  settings,
  onClose,
  onOpenDigitalPass,
  onCheckInToggle,
}) => {
  const [timeInput, setTimeInput] = useState<string>(() => getCurrentHHMM());
  const [lastActionFeedback, setLastActionFeedback] = useState<{
    action: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
  } | null>(null);

  useEffect(() => {
    setLastActionFeedback(null);
    setTimeInput(getCurrentHHMM());
  }, [student?.id]);

  if (!student) return null;

  const isInside = student.attendanceStatus === 'CHECKED_IN';
  const avatarSrc = resolveStudentAvatar(student.avatarUrl);
  const todayStr = getLocalTodayStr();
  const todayRecords = attendanceRecords
    .filter(r => r.studentId === student.id && r.checkInTime.startsWith(todayStr))
    .sort((a, b) => b.checkInTime.localeCompare(a.checkInTime));

  const handleToggleAttendance = () => {
    const chosenTime = timeInput || getCurrentHHMM();
    const res = onCheckInToggle(student.id, 'QR_SCAN', chosenTime);
    if (res.success && res.action) {
      if (res.action === 'IN') {
        sounds.playSuccess();
      } else {
        sounds.playCheckOut();
      }
      setLastActionFeedback({
        action: res.action,
        inTime: res.inTime,
        outTime: res.outTime,
        durationMinutes: res.durationMinutes,
      });
      setTimeInput(getCurrentHHMM());
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl my-auto max-h-[94dvh] flex flex-col">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Scanned Student Full Details &amp; Attendance
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {settings.name || 'Bharti Digital Library'} · Verified QR Profile
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-200/70 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500 transition-colors"
            aria-label="Close scanned student details"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Profile Hero Card */}
          <div className="p-4 rounded-2xl bg-slate-900 dark:bg-slate-950 text-white border border-slate-800 flex items-center gap-4">
            <img
              src={avatarSrc}
              alt={student.name}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white/20 shrink-0 bg-slate-800"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-md bg-white/10 text-slate-200 border border-white/15">
                  ID: {student.id}
                </span>
                <span
                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                    isInside
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                      : 'bg-slate-700/80 text-slate-300 border border-slate-600'
                  }`}
                >
                  {isInside ? '● Present Inside' : 'Checked Out'}
                </span>
              </div>
              <h4 className="text-lg font-extrabold text-white truncate">{student.name}</h4>
              <p className="text-xs text-slate-300 flex items-center gap-1.5 truncate">
                <BookOpen className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">{student.courseOrExam || 'Dedicated Study Scholar'}</span>
              </p>
            </div>
          </div>

          {/* Dedicated Daily Attendance System Card */}
          <div
            className={`p-4 rounded-2xl border space-y-3 ${
              isInside
                ? 'bg-indigo-50/80 dark:bg-indigo-950/35 border-indigo-200 dark:border-indigo-900/60'
                : 'bg-emerald-50/75 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/60'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>Mark Today&apos;s Attendance</span>
                </h4>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                  {isInside
                    ? `Currently inside since ${formatTimeReadable(student.currentCheckInTime)}`
                    : `Tap below to record today's In-Time (${formatDateReadable(todayStr)})`}
                </p>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-1 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shrink-0">
                {formatDateReadable(todayStr)}
              </span>
            </div>

            {lastActionFeedback && (
              <div
                className={`p-2.5 rounded-xl border text-xs flex items-center justify-between gap-2 ${
                  lastActionFeedback.action === 'IN'
                    ? 'bg-emerald-100/80 dark:bg-emerald-900/40 border-emerald-300 dark:border-emerald-700 text-emerald-900 dark:text-emerald-100'
                    : 'bg-blue-100/80 dark:bg-blue-900/40 border-blue-300 dark:border-blue-700 text-blue-900 dark:text-blue-100'
                }`}
              >
                <div className="flex items-center gap-1.5 font-semibold">
                  {lastActionFeedback.action === 'IN' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <LogOut className="w-4 h-4 shrink-0" />
                  )}
                  <span>
                    {lastActionFeedback.action === 'IN'
                      ? `Attendance Marked: In-Time ${formatTimeReadable(lastActionFeedback.inTime)}`
                      : `Out-Time Marked: ${formatTimeReadable(lastActionFeedback.outTime)}`}
                  </span>
                </div>
                {lastActionFeedback.action === 'OUT' && lastActionFeedback.durationMinutes !== undefined && (
                  <span className="font-mono font-bold shrink-0">
                    {Math.floor(lastActionFeedback.durationMinutes / 60)}h {lastActionFeedback.durationMinutes % 60}m
                  </span>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 min-h-[40px]">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  {isInside ? 'Out Time:' : 'In Time:'}
                </span>
                <input
                  type="time"
                  value={timeInput}
                  onChange={e => setTimeInput(e.target.value)}
                  className="bg-transparent text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <button
                type="button"
                onClick={handleToggleAttendance}
                className={`flex-1 min-w-[150px] py-2.5 px-4 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 shadow-xs transition-colors min-h-[40px] ${
                  isInside
                    ? 'bg-indigo-600 hover:bg-indigo-700'
                    : 'bg-emerald-600 hover:bg-emerald-700'
                }`}
              >
                {isInside ? <LogOut className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
                <span>{isInside ? 'Mark Out-Time (Check Out)' : 'Mark In-Time (Check In)'}</span>
              </button>
            </div>

            {todayRecords.length > 0 && (
              <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/60 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                  Today&apos;s Attendance Log
                </span>
                {todayRecords.slice(0, 2).map(rec => (
                  <div
                    key={rec.id}
                    className="flex items-center justify-between text-[11px] font-mono text-slate-700 dark:text-slate-300"
                  >
                    <span>
                      In: <strong>{formatTimeReadable(rec.checkInTime)}</strong> · Out:{' '}
                      <strong>{rec.checkOutTime ? formatTimeReadable(rec.checkOutTime) : 'Inside Hall'}</strong>
                    </span>
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                      {rec.durationMinutes
                        ? `${Math.floor(rec.durationMinutes / 60)}h ${rec.durationMinutes % 60}m`
                        : 'Active'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Desk, PIN & Locker Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1">
                <Armchair className="w-3 h-3" />
                <span>Desk Slot</span>
              </span>
              <span className="text-base font-extrabold font-mono text-slate-900 dark:text-white mt-0.5 block">
                {student.assignedDesk}
              </span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1">
                <KeyRound className="w-3 h-3" />
                <span>Kiosk PIN</span>
              </span>
              <span className="text-base font-extrabold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5 block">
                {student.pin}
              </span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center">
              <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1">
                <Lock className="w-3 h-3" />
                <span>Locker</span>
              </span>
              <span className="text-base font-extrabold font-mono text-slate-900 dark:text-white mt-0.5 block">
                {student.lockerNumber || 'None'}
              </span>
            </div>
          </div>

          {/* Contact & Shift Details */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900/60">
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" />
                <span>Mobile Number</span>
              </span>
              <strong className="font-mono text-slate-900 dark:text-white">{student.phone || 'Not provided'}</strong>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                <span>Email</span>
              </span>
              <strong className="text-slate-900 dark:text-white truncate max-w-[220px]">
                {student.email || 'Not provided'}
              </strong>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Allocated Shift(s)</span>
              </span>
              <strong className="text-right text-slate-900 dark:text-white">
                {formatStudentShifts(student.shifts, student.shift)}
              </strong>
            </div>
          </div>

          {/* Membership, Fee & Attendance Summary */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 bg-slate-50/70 dark:bg-slate-800/40">
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400">Admission Date</span>
              <strong className="font-mono text-slate-900 dark:text-white">
                {formatDateReadable(student.joinedDate)}
              </strong>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5" />
                <span>Monthly Fee &amp; Status</span>
              </span>
              <div className="flex items-center gap-2">
                <strong className="font-mono text-slate-900 dark:text-white">
                  ₹{student.monthlyFee.toLocaleString('en-IN')}
                </strong>
                <span
                  className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                    student.paymentStatus === 'PAID'
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-200'
                      : student.paymentStatus === 'DUE_SOON'
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200'
                      : 'bg-rose-100 text-rose-800 dark:bg-rose-900/60 dark:text-rose-200'
                  }`}
                >
                  {student.paymentStatus.replace('_', ' ')}
                </span>
              </div>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400">Last Payment Date</span>
              <strong className="font-mono text-slate-900 dark:text-white">
                {student.lastPaymentDate ? formatDateReadable(student.lastPaymentDate) : 'Not Paid'}
              </strong>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <CalendarRange className="w-3.5 h-3.5" />
                <span>Card Validity</span>
              </span>
              <strong className="font-mono text-slate-900 dark:text-white">
                {formatDateReadable(student.cardValidFrom || student.lastPaymentDate || student.joinedDate)} →{' '}
                <span
                  className={
                    student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED'
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-emerald-600 dark:text-emerald-400'
                  }
                >
                  {formatDateReadable(student.renewalDueDate)}
                </span>
              </strong>
            </div>
            <div className="px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Attendance Stats</span>
              </span>
              <strong className="font-mono text-slate-900 dark:text-white">
                {student.totalVisitsThisMonth} visits this month · {student.avgHoursPerVisit}h avg
              </strong>
            </div>
          </div>

          {(student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED') && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-800 dark:text-amber-200">
              <strong>Fee Reminder:</strong> Renewal was due on {formatDateReadable(student.renewalDueDate)}.
            </div>
          )}
        </div>

        {/* Footer Action Bar */}
        <div className="px-5 py-3.5 bg-slate-50 dark:bg-slate-800/60 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenDigitalPass(student);
            }}
            className="flex-1 py-2.5 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
          >
            <IdCard className="w-4 h-4" />
            <span>Open Digital ID Pass</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-xs font-semibold text-white transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
