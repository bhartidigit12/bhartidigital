import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  ShieldCheck,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  RefreshCw,
  Copy,
  Check,
  ShieldAlert,
} from 'lucide-react';
import { sounds } from '../utils/notifications';

interface AdminAuthModalProps {
  isOpen: boolean;
  isAdmin: boolean;
  currentPin: string;
  onClose: () => void;
  onUnlock: () => void;
  onLock: () => void;
  onChangePin: (newPin: string) => void;
}

const WEAK_PIN_PATTERNS = new Set([
  '1234',
  '12345',
  '123456',
  '12345678',
  '654321',
  '0000',
  '000000',
  '1111',
  '111111',
  'admin',
  'admin123',
  'password',
  'qwerty',
  'library',
]);

function evaluatePinStrength(pin: string): {
  score: number; // 0-4
  label: string;
  colorClass: string;
  barClass: string;
  valid: boolean;
  reason?: string;
} {
  const trimmed = pin.trim();
  if (!trimmed) {
    return {
      score: 0,
      label: 'Enter a strong PIN',
      colorClass: 'text-slate-400',
      barClass: 'bg-slate-200 dark:bg-slate-700',
      valid: false,
    };
  }

  if (WEAK_PIN_PATTERNS.has(trimmed.toLowerCase()) || /^(.)\1+$/.test(trimmed)) {
    return {
      score: 1,
      label: 'Too Weak',
      colorClass: 'text-rose-600 dark:text-rose-400',
      barClass: 'bg-rose-500',
      valid: false,
      reason: 'Avoid common or repeated PINs like 1234, 000000, or admin.',
    };
  }

  const hasUpper = /[A-Z]/.test(trimmed);
  const hasLower = /[a-z]/.test(trimmed);
  const hasDigit = /\d/.test(trimmed);
  const hasSymbol = /[^A-Za-z0-9]/.test(trimmed);
  const varietyCount = [hasUpper, hasLower, hasDigit, hasSymbol].filter(Boolean).length;

  if (trimmed.length < 6) {
    return {
      score: 1,
      label: 'Too Short',
      colorClass: 'text-rose-600 dark:text-rose-400',
      barClass: 'bg-rose-500',
      valid: false,
      reason: 'Strong Admin PIN must be at least 6 characters long.',
    };
  }

  if (varietyCount < 2) {
    return {
      score: 2,
      label: 'Weak',
      colorClass: 'text-amber-600 dark:text-amber-400',
      barClass: 'bg-amber-500',
      valid: false,
      reason: 'Mix letters, numbers, or symbols (e.g. Bdl@8492) so it cannot be guessed.',
    };
  }

  if (trimmed.length >= 8 && varietyCount >= 3) {
    return {
      score: 4,
      label: 'Very Strong',
      colorClass: 'text-emerald-600 dark:text-emerald-400',
      barClass: 'bg-emerald-500',
      valid: true,
    };
  }

  return {
    score: 3,
    label: 'Strong',
    colorClass: 'text-indigo-600 dark:text-indigo-400',
    barClass: 'bg-indigo-500',
    valid: true,
  };
}

function generateStrongAdminPin(length = 10): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghijkmnpqrstuvwxyz';
  const digits = '23456789';
  const symbols = '@#$%&*!';
  const all = upper + lower + digits + symbols;

  const pick = (pool: string) => {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    return pool[arr[0] % pool.length];
  };

  const chars: string[] = [pick(upper), pick(lower), pick(digits), pick(symbols)];
  while (chars.length < length) {
    chars.push(pick(all));
  }

  // Fisher-Yates shuffle with crypto randomness
  for (let i = chars.length - 1; i > 0; i--) {
    const arr = new Uint32Array(1);
    window.crypto.getRandomValues(arr);
    const j = arr[0] % (i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join('');
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  isOpen,
  isAdmin,
  currentPin,
  onClose,
  onUnlock,
  onLock,
  onChangePin,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [showUnlockPin, setShowUnlockPin] = useState(false);
  const [error, setError] = useState('');
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutSeconds, setLockoutSeconds] = useState(0);

  const [currentPinCheck, setCurrentPinCheck] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showNewPin, setShowNewPin] = useState(false);
  const [pinSavedMsg, setPinSavedMsg] = useState('');
  const [copiedNewPin, setCopiedNewPin] = useState(false);

  useEffect(() => {
    if (lockoutSeconds <= 0) return;
    const timer = window.setInterval(() => {
      setLockoutSeconds(prev => (prev <= 1 ? 0 : prev - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [lockoutSeconds]);

  useEffect(() => {
    if (!isOpen) {
      setPinInput('');
      setShowUnlockPin(false);
      setError('');
      setCurrentPinCheck('');
      setNewPin('');
      setConfirmPin('');
      setShowNewPin(false);
      setPinSavedMsg('');
      setCopiedNewPin(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const strength = evaluatePinStrength(newPin);

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutSeconds > 0) {
      setError(`Too many wrong attempts. Wait ${lockoutSeconds}s before trying again.`);
      return;
    }

    if (pinInput.trim() === currentPin) {
      setError('');
      setPinInput('');
      setFailedAttempts(0);
      sounds.playSuccess();
      onUnlock();
      onClose();
    } else {
      const nextAttempts = failedAttempts + 1;
      setFailedAttempts(nextAttempts);
      sounds.playAlert();
      if (nextAttempts >= 5) {
        setLockoutSeconds(30);
        setFailedAttempts(0);
        setError('5 incorrect PIN attempts. Admin unlock paused for 30 seconds.');
      } else {
        setError(
          `Incorrect Admin PIN (${5 - nextAttempts} attempts left). Only the library admin can make changes.`
        );
      }
    }
  };

  const handleGeneratePin = () => {
    const generated = generateStrongAdminPin(10);
    setNewPin(generated);
    setConfirmPin(generated);
    setShowNewPin(true);
    setError('');
    setPinSavedMsg('');
    setCopiedNewPin(false);
  };

  const handleCopyGenerated = () => {
    if (!newPin) return;
    navigator.clipboard.writeText(newPin);
    setCopiedNewPin(true);
    setTimeout(() => setCopiedNewPin(false), 2000);
  };

  const handleChangePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinSavedMsg('');

    if (currentPinCheck.trim() !== currentPin) {
      setError('Current Admin PIN is incorrect.');
      sounds.playAlert();
      return;
    }

    if (!strength.valid) {
      setError(strength.reason || 'Please use a stronger Admin PIN.');
      sounds.playAlert();
      return;
    }

    if (newPin.trim() !== confirmPin.trim()) {
      setError('New PIN and confirmation do not match.');
      sounds.playAlert();
      return;
    }

    setError('');
    onChangePin(newPin.trim());
    setCurrentPinCheck('');
    setNewPin('');
    setConfirmPin('');
    setShowNewPin(false);
    setPinSavedMsg('Strong Admin PIN saved successfully.');
    sounds.playSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl">
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                isAdmin
                  ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600'
                  : 'bg-slate-900 dark:bg-indigo-600 text-white'
              }`}
            >
              {isAdmin ? <ShieldCheck className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAdmin ? 'Admin Controls Active' : 'Protected Admin Vault'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {isAdmin ? 'Strong Admin PIN protection active' : 'Only admin can modify records, fees & settings'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
            aria-label="Close Admin Auth"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {!isAdmin ? (
            <form onSubmit={handleUnlockSubmit} className="space-y-4">
              <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-200 flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <span>
                  Protected by a <strong>Strong Admin PIN</strong>. Only the library admin can edit students, approve admissions, collect fees, or change UPI &amp; library settings.
                </span>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Enter Strong Admin PIN
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showUnlockPin ? 'text' : 'password'}
                    autoComplete="current-password"
                    autoFocus
                    required
                    disabled={lockoutSeconds > 0}
                    value={pinInput}
                    onChange={e => {
                      setPinInput(e.target.value);
                      setError('');
                    }}
                    placeholder="Enter Admin PIN / Passcode"
                    className="w-full pl-9 pr-10 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono tracking-wider text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-60"
                  />
                  <button
                    type="button"
                    onClick={() => setShowUnlockPin(prev => !prev)}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 p-1"
                    title={showUnlockPin ? 'Hide PIN' : 'Show PIN'}
                    aria-label={showUnlockPin ? 'Hide PIN' : 'Show PIN'}
                  >
                    {showUnlockPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="flex items-start gap-1.5 text-xs text-rose-600 dark:text-rose-400 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={lockoutSeconds > 0}
                  className="px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{lockoutSeconds > 0 ? `Locked (${lockoutSeconds}s)` : 'Unlock Admin Edit'}</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 flex items-center justify-between gap-2">
                <div className="text-xs text-emerald-900 dark:text-emerald-200">
                  <strong>Admin Mode Unlocked</strong>
                  <p className="text-[11px] opacity-80">Lock before handing device to students.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onLock();
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center gap-1 shrink-0"
                >
                  <Lock className="w-3 h-3" />
                  <span>Lock Now</span>
                </button>
              </div>

              <form onSubmit={handleChangePinSubmit} className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Strong Admin PIN Generator
                  </h3>
                  <button
                    type="button"
                    onClick={handleGeneratePin}
                    className="px-2.5 py-1 rounded-lg bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Generate Strong PIN</span>
                  </button>
                </div>

                <div>
                  <input
                    type="password"
                    required
                    value={currentPinCheck}
                    onChange={e => {
                      setCurrentPinCheck(e.target.value);
                      setError('');
                    }}
                    placeholder="Verify Current Admin PIN"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div className="relative">
                  <input
                    type={showNewPin ? 'text' : 'password'}
                    required
                    value={newPin}
                    onChange={e => {
                      setNewPin(e.target.value);
                      setError('');
                      setPinSavedMsg('');
                    }}
                    placeholder="New Strong PIN (6+ mixed chars)"
                    className="w-full pl-3 pr-16 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                  />
                  <div className="absolute right-1.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    {newPin && (
                      <button
                        type="button"
                        onClick={handleCopyGenerated}
                        className="p-1 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400"
                        title="Copy New PIN"
                        aria-label="Copy New PIN"
                      >
                        {copiedNewPin ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowNewPin(prev => !prev)}
                      className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                      title={showNewPin ? 'Hide New PIN' : 'Show New PIN'}
                      aria-label={showNewPin ? 'Hide New PIN' : 'Show New PIN'}
                    >
                      {showNewPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <input
                  type={showNewPin ? 'text' : 'password'}
                  required
                  value={confirmPin}
                  onChange={e => {
                    setConfirmPin(e.target.value);
                    setError('');
                  }}
                  placeholder="Confirm New Strong PIN"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono text-slate-900 dark:text-white"
                />

                {/* Strength Bar */}
                {newPin && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-500">PIN Strength</span>
                      <span className={`font-bold ${strength.colorClass}`}>{strength.label}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1 h-1.5">
                      {[1, 2, 3, 4].map(level => (
                        <div
                          key={level}
                          className={`rounded-full transition-colors ${
                            strength.score >= level ? strength.barClass : 'bg-slate-200 dark:bg-slate-800'
                          }`}
                        />
                      ))}
                    </div>
                    {strength.reason && (
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">{strength.reason}</p>
                    )}
                  </div>
                )}

                {error && <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">{error}</p>}
                {pinSavedMsg && (
                  <p className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{pinSavedMsg}</span>
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors"
                >
                  Save Strong Admin PIN
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
