import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Bell,
  Send,
  CheckCircle2,
  MessageSquare,
  ShieldCheck,
  Copy,
  Check,
  Settings,
} from 'lucide-react';
import { PushReminder, Student, LibrarySettings } from '../types';
import {
  requestPushPermission,
  sendBrowserPushNotification,
  buildStudentWhatsAppUrl,
  formatWhatsAppPhoneDisplay,
  sounds,
} from '../utils/notifications';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  reminders: PushReminder[];
  students: Student[];
  settings: LibrarySettings;
  onTriggerDailyReminderRun: () => { sentCount: number; affectedStudents: Student[] };
  onDispatchWhatsAppReminder?: (student: Student, message: string) => void;
  onOpenWhatsAppSetup?: () => void;
}

function getLocalTodayStr(): string {
  const dt = new Date();
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  reminders,
  students,
  settings,
  onTriggerDailyReminderRun,
  onDispatchWhatsAppReminder,
  onOpenWhatsAppSetup,
}) => {
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [lastBatchCount, setLastBatchCount] = useState<number | null>(null);
  const [copiedStudentId, setCopiedStudentId] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermissionGranted(Notification.permission === 'granted');
    }
  }, [isOpen]);

  const todayStr = getLocalTodayStr();
  const sentWhatsAppToday = useMemo(() => {
    const ids = new Set<string>();
    reminders.forEach(r => {
      if (r.channel === 'WHATSAPP' && r.sentAt.startsWith(todayStr)) {
        ids.add(r.studentId);
      }
    });
    return ids;
  }, [reminders, todayStr]);

  if (!isOpen) return null;

  const handleEnablePush = async () => {
    const granted = await requestPushPermission();
    setPermissionGranted(granted);
    if (granted) {
      sounds.playSuccess();
      sendBrowserPushNotification(
        `${settings.name} Notifications Enabled`,
        'You will now receive automated monthly payment reminders and peak capacity alerts.'
      );
    }
  };

  const handleRunReminders = () => {
    const res = onTriggerDailyReminderRun();
    setLastBatchCount(res.sentCount);
    sounds.playSuccess();

    if (permissionGranted) {
      sendBrowserPushNotification(
        'Payment Reminders Dispatched',
        `Automated reminders queued for ${res.sentCount} members with upcoming or overdue dues.`
      );
    }

    setTimeout(() => {
      setLastBatchCount(null);
    }, 4000);
  };

  const overdueOrDueSoon = students.filter(
    s => s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'DUE_SOON' || s.paymentStatus === 'EXPIRED'
  );
  const waConnected = settings.whatsappConnected !== false;
  const waDisplayPhone = formatWhatsAppPhoneDisplay(settings.whatsappNumber || settings.phone);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex justify-end">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800 transition-all">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">WhatsApp &amp; Fee Reminders</h3>
              <p className="text-[11px] text-slate-500">Automated Member Fee Dispatch</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5">
          {/* Connected Library WhatsApp Banner */}
          <div className="p-4 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-200/80 dark:border-emerald-900/60 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold text-emerald-950 dark:text-emerald-200 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-emerald-600" />
                <span>Our Library WhatsApp</span>
              </span>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  waConnected
                    ? 'bg-emerald-100 dark:bg-emerald-900/70 text-emerald-700 dark:text-emerald-300'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600'
                }`}
              >
                {waConnected ? '● Connected' : 'Paused'}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <div className="text-xs text-slate-700 dark:text-slate-300 font-mono">
                {waDisplayPhone}
              </div>
              {onOpenWhatsAppSetup && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenWhatsAppSetup();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-emerald-200 dark:border-emerald-800 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 inline-flex items-center gap-1 hover:bg-emerald-100/60"
                >
                  <Settings className="w-3 h-3" />
                  <span>WhatsApp Settings &amp; Queue</span>
                </button>
              )}
            </div>
          </div>

          {/* Push Status Banner */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-indigo-600" />
                Browser Web Push Status
              </span>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                  permissionGranted
                    ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-semibold'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-600'
                }`}
              >
                {permissionGranted ? 'Active / Permitted' : 'Not Enabled'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              Enable browser push alerts for automatic notifications when student passes expire.
            </p>
            {!permissionGranted && (
              <button
                onClick={handleEnablePush}
                className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-slate-900 dark:bg-indigo-600 text-white hover:bg-slate-800 transition-colors"
              >
                Enable Push Notifications on This Device
              </button>
            )}
          </div>

          {/* Automated Batch Reminder Trigger */}
          <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
            <div className="flex items-center justify-between mb-1.5">
              <h4 className="text-xs font-bold text-indigo-950 dark:text-indigo-200">
                Fee Reminder Dispatch Queue
              </h4>
              <span className="text-xs font-mono font-bold text-rose-600 dark:text-rose-400">
                {overdueOrDueSoon.length} Pending Dues
              </span>
            </div>
            <p className="text-xs text-indigo-800/80 dark:text-indigo-300/80 mb-3">
              Prepares personalized fee reminders with UPI details and generates 1-tap WhatsApp messages for every pending student.
            </p>
            <button
              onClick={handleRunReminders}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Log &amp; Queue Reminders ({overdueOrDueSoon.length} Students)</span>
            </button>

            {lastBatchCount !== null && (
              <div className="mt-2.5 p-2 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-xs font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Queued {lastBatchCount} student fee reminders! Send individually on WhatsApp below.</span>
              </div>
            )}
          </div>

          {/* Pending Students Quick List */}
          <div>
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Send Fee Reminder to Student WhatsApp ({overdueOrDueSoon.length})
            </h4>
            <div className="space-y-2 max-h-80 overflow-y-auto pr-0.5">
              {overdueOrDueSoon.map(s => {
                const waInfo = buildStudentWhatsAppUrl(s, settings);
                const isSent = sentWhatsAppToday.has(s.id);
                return (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-slate-900 dark:text-white truncate">{s.name}</span>
                        <span
                          className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                            s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'EXPIRED'
                              ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                              : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                          }`}
                        >
                          {s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'EXPIRED' ? 'Overdue' : 'Due Soon'}
                        </span>
                        {isSent && (
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                            ✓ Sent
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5 truncate">
                        {waInfo.formattedPhone} · Desk {s.assignedDesk} · ₹{s.monthlyFee}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(waInfo.message);
                          setCopiedStudentId(s.id);
                          setTimeout(() => setCopiedStudentId(null), 1600);
                        }}
                        className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                        title="Copy Reminder Text"
                      >
                        {copiedStudentId === s.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <a
                        href={waInfo.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={e => {
                          if (!waConnected) {
                            e.preventDefault();
                            return;
                          }
                          onDispatchWhatsAppReminder?.(s, waInfo.message);
                        }}
                        className={`px-2.5 py-2 rounded-lg text-xs font-bold inline-flex items-center gap-1 transition-colors ${
                          waConnected
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                        }`}
                        title="Send WhatsApp Reminder"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Send</span>
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Notification Log */}
          <div>
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Recent Dispatched Activity
            </h4>
            <div className="space-y-2">
              {reminders.slice(0, 8).map(rem => (
                <div
                  key={rem.id}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">{rem.title}</span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                        {rem.channel}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {rem.sentAt.split('T')[1]?.substring(0, 5) || 'Just now'}
                      </span>
                    </div>
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px] line-clamp-2">{rem.message}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
