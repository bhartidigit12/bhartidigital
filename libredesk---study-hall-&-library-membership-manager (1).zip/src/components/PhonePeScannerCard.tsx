import React, { useState, useEffect } from 'react';
import { QrCode, Copy, Check, Smartphone, ExternalLink, Download } from 'lucide-react';
import { LibrarySettings } from '../types';
import { generateQrDataUrl } from '../utils/qr';

interface PhonePeScannerCardProps {
  settings: LibrarySettings;
  amount?: number;
  note?: string;
  compact?: boolean;
  onEditClick?: () => void;
  isAdmin?: boolean;
}

export function getEffectiveUpiDetails(settings: LibrarySettings) {
  const upiNumber = (settings.upiNumber || settings.phone || '9973299354').trim();
  const digits = upiNumber.replace(/\D/g, '').slice(-10) || '9973299354';
  const upiId = (settings.upiId || `${digits}@ybl`).trim();
  const payeeName = (settings.upiPayeeName || settings.name || 'Bharti Digital Library').trim();
  return { upiNumber, upiId, payeeName };
}

export const PhonePeScannerCard: React.FC<PhonePeScannerCardProps> = ({
  settings,
  amount,
  note = 'Library Fee',
  compact = false,
  onEditClick,
  isAdmin,
}) => {
  const { upiNumber, upiId, payeeName } = getEffectiveUpiDetails(settings);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copiedField, setCopiedField] = useState<'NUMBER' | 'ID' | null>(null);

  const upiParams = new URLSearchParams({
    pa: upiId,
    pn: payeeName,
    cu: 'INR',
    tn: note,
  });
  if (amount && amount > 0) {
    upiParams.set('am', String(amount));
  }
  const upiUri = `upi://pay?${upiParams.toString()}`;

  useEffect(() => {
    if (!settings.phonePeQrImageUrl) {
      generateQrDataUrl(upiUri, compact ? 180 : 240).then(setQrDataUrl);
    }
  }, [upiUri, settings.phonePeQrImageUrl, compact]);

  const activeQrSrc = settings.phonePeQrImageUrl || qrDataUrl;

  const handleCopy = (text: string, field: 'NUMBER' | 'ID') => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 1800);
  };

  const handleDownloadQr = () => {
    if (!activeQrSrc) return;
    const link = document.createElement('a');
    link.href = activeQrSrc;
    link.download = `bharti_library_phonepe_qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="rounded-2xl border border-purple-200 dark:border-purple-900/60 bg-white dark:bg-slate-900 overflow-hidden shadow-xs">
      {/* Authentic PhonePe Scanner Header */}
      <div className="px-4 py-3 bg-[#5f259f] text-white flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded-full bg-white text-[#5f259f] font-extrabold text-sm flex items-center justify-center shrink-0">
            पे
          </div>
          <div className="min-w-0">
            <span className="text-xs font-extrabold tracking-wide block truncate">
              PhonePe · BHIM UPI Scanner
            </span>
            <span className="text-[10px] text-purple-200 block truncate">
              {payeeName}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {activeQrSrc && (
            <button
              type="button"
              onClick={handleDownloadQr}
              className="px-2 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-white text-[11px] font-semibold inline-flex items-center gap-1 transition-colors whitespace-nowrap"
              title="Download QR Scanner"
            >
              <Download className="w-3 h-3" />
              {!compact && <span>Save QR</span>}
            </button>
          )}
          {onEditClick && (
            <button
              type="button"
              onClick={onEditClick}
              className="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-white text-[11px] font-semibold transition-colors whitespace-nowrap"
            >
              {isAdmin ? 'Edit UPI / QR' : 'Admin Edit'}
            </button>
          )}
        </div>
      </div>

      {/* Scanner Body */}
      <div className={`${compact ? 'p-3.5' : 'p-5'} flex flex-col ${compact ? 'sm:flex-row' : 'items-center'} gap-4`}>
        {/* QR Image Box */}
        <div className="flex flex-col items-center shrink-0">
          <div className="p-2.5 bg-white rounded-xl border-2 border-purple-100 dark:border-slate-700 shadow-xs">
            {activeQrSrc ? (
              <img
                src={activeQrSrc}
                alt={`PhonePe UPI QR for ${upiId}`}
                className={`${compact ? 'w-28 h-28' : 'w-44 h-44'} object-contain`}
              />
            ) : (
              <div className={`${compact ? 'w-28 h-28' : 'w-44 h-44'} bg-slate-100 flex items-center justify-center rounded-lg`}>
                <QrCode className="w-8 h-8 text-slate-400" />
              </div>
            )}
          </div>
          {amount && amount > 0 && (
            <span className="mt-2 text-xs font-mono tabular-nums font-bold text-[#5f259f] dark:text-purple-300">
              Scan & Pay ₹{amount.toLocaleString('en-IN')}
            </span>
          )}
        </div>

        {/* UPI Number & UPI ID Details */}
        <div className={`w-full space-y-2.5 ${compact ? '' : 'text-center'}`}>
          <div className="p-2.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/50 flex items-center justify-between gap-2 text-left">
            <div className="min-w-0">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-purple-700 dark:text-purple-300 block">
                PhonePe / UPI Number
              </span>
              <span className="text-sm font-extrabold font-mono tabular-nums text-slate-900 dark:text-white truncate block">
                {upiNumber}
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(upiNumber, 'NUMBER')}
              className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-purple-200 dark:border-purple-800 text-xs font-semibold text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900/50 inline-flex items-center gap-1 shrink-0"
              title="Copy UPI / PhonePe Number"
            >
              {copiedField === 'NUMBER' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedField === 'NUMBER' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2 text-left">
            <div className="min-w-0">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
                UPI ID (GPay · PhonePe · Paytm)
              </span>
              <span className="text-xs font-bold font-mono text-slate-900 dark:text-white truncate block">
                {upiId}
              </span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy(upiId, 'ID')}
              className="px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 inline-flex items-center gap-1 shrink-0"
              title="Copy UPI ID"
            >
              {copiedField === 'ID' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedField === 'ID' ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <a
            href={upiUri}
            className="w-full py-2 px-3 rounded-xl bg-[#5f259f] hover:bg-[#4e1d84] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Pay in PhonePe / UPI App</span>
            <ExternalLink className="w-3 h-3 opacity-80" />
          </a>
        </div>
      </div>
    </div>
  );
};
