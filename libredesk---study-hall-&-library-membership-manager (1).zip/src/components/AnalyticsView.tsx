import React, { useState } from 'react';
import { 
  TrendingUp, 
  Users, 
  Clock, 
  Target, 
  Award, 
  AlertTriangle, 
  Download, 
  Lightbulb, 
  CheckCircle2, 
  Calendar,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { PeakHourData, RetentionCohort, LibrarySettings } from '../types';
import { CHURN_REASONS } from '../data/mockData';

interface AnalyticsViewProps {
  peakHours: PeakHourData[];
  retentionCohorts: RetentionCohort[];
  settings: LibrarySettings;
  totalStudentsCount: number;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  peakHours,
  retentionCohorts,
  settings,
  totalStudentsCount,
}) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'TODAY' | 'WEEK' | 'MONTH'>('TODAY');

  const maxOccupancy = Math.max(...peakHours.map(p => p.occupancyCount));
  const avgOccupancy = Math.round(peakHours.reduce((acc, p) => acc + p.occupancyCount, 0) / peakHours.length);

  const handleExportReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Library Analytics & Intelligence
          </h2>
          <p className="text-xs text-slate-500">
            Real-time daily peak hours, retention cohort metrics, and strategic administrative decisions
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
            {(['TODAY', 'WEEK', 'MONTH'] as const).map(tf => (
              <button
                key={tf}
                onClick={() => setSelectedTimeframe(tf)}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  selectedTimeframe === tf
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {tf === 'TODAY' ? 'Today' : tf === 'WEEK' ? '7 Days' : '30 Days'}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportReport}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-xl transition-colors min-h-[40px]"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export Report</span>
          </button>
        </div>
      </div>

      {/* Top Intelligence Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Daily Peak Load</span>
            <TrendingUp className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-900 dark:text-white">
            {maxOccupancy} <span className="text-xs font-normal text-slate-400">/ {settings.totalDesks} seats</span>
          </div>
          <span className="text-xs text-rose-600 font-semibold mt-1 block">
            98% Capacity (6:00 PM)
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Avg Study Duration</span>
            <Clock className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-900 dark:text-white">
            5.8 <span className="text-xs font-normal text-slate-400">hrs/day</span>
          </div>
          <span className="text-xs text-emerald-600 font-semibold mt-1 block">
            +0.4h vs last month
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">3-Month Retention</span>
            <Target className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-900 dark:text-white">
            81.2%
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            Industry Benchmark: 68%
          </span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold">Desk Turnover Rate</span>
            <Layers className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-900 dark:text-white">
            2.3 <span className="text-xs font-normal text-slate-400">students/seat</span>
          </div>
          <span className="text-xs text-slate-400 mt-1 block">
            Across {totalStudentsCount} active members · {avgOccupancy} avg/hr
          </span>
        </div>
      </div>

      {/* Section 1: Daily Peak Hours Detailed Visualizer */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Hourly Traffic & Desk Occupancy Distribution (6 AM - 11 PM)
            </h3>
            <p className="text-xs text-slate-500">
              Clear double-peak pattern: Morning competitive exam prep (10-12 AM) and Evening professional batch (5-8 PM)
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <span className="w-3 h-3 rounded bg-rose-500"></span>
              <span>Near Capacity (&gt;90%)</span>
            </span>
            <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
              <span className="w-3 h-3 rounded bg-indigo-500"></span>
              <span>Moderate (60-89%)</span>
            </span>
          </div>
        </div>

        {/* Detailed Graph Visualization */}
        <div className="space-y-2 pt-2">
          {peakHours.map(item => {
            const pct = item.capacityPercentage;
            const isRed = pct >= 90;
            const isOrange = pct >= 70 && pct < 90;

            return (
              <div key={item.hour} className="flex items-center gap-3 text-xs">
                <span className="w-14 font-mono font-semibold text-slate-600 dark:text-slate-400 text-right shrink-0">
                  {item.label}
                </span>

                <div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-lg h-6 overflow-hidden relative flex items-center px-2">
                  <div
                    className={`absolute inset-y-0 left-0 rounded-lg transition-all ${
                      isRed 
                        ? 'bg-gradient-to-r from-rose-500 to-rose-600' 
                        : isOrange 
                        ? 'bg-gradient-to-r from-indigo-500 to-indigo-600' 
                        : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                    style={{ width: `${pct}%` }}
                  ></div>

                  <span className="relative z-10 font-mono font-bold text-[11px] text-white drop-shadow-xs">
                    {item.occupancyCount} seated ({pct}%)
                  </span>
                </div>

                <span className="w-20 text-[11px] font-mono text-slate-400 text-right shrink-0">
                  {settings.totalDesks - item.occupancyCount} open
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 2: Student Retention Cohort Analysis */}
      <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-5">
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            Student Retention & Lifecycle Cohorts (Past 6 Months)
          </h3>
          <p className="text-xs text-slate-500">
            Measures the percentage of student cohorts that stay enrolled over subsequent months
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider font-mono">
                <th className="py-3 px-3">Registration Cohort</th>
                <th className="py-3 px-3 text-right">Registered</th>
                <th className="py-3 px-3 text-right">Month 1</th>
                <th className="py-3 px-3 text-right">Month 2</th>
                <th className="py-3 px-3 text-right">Month 3</th>
                <th className="py-3 px-3 text-right">Month 6</th>
                <th className="py-3 px-3">Top Exit Factor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {retentionCohorts.map(c => (
                <tr key={c.cohortMonth} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3 font-semibold text-slate-900 dark:text-white">{c.cohortMonth}</td>
                  <td className="py-3 px-3 text-right font-mono">{c.totalRegistered}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600">{c.retainedMonth1}%</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600">{c.retainedMonth2}%</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-indigo-600">{c.retainedMonth3}%</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">{c.retainedMonth6}%</td>
                  <td className="py-3 px-3 text-slate-500 text-[11px]">{c.dropReasonTop}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Churn Reasons Breakdown */}
        <div className="pt-2">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-3">
            Primary Drop-off & Departure Reasons
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {CHURN_REASONS.map(r => (
              <div key={r.reason} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 block truncate">{r.reason}</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-xl font-bold font-mono text-slate-900 dark:text-white">{r.percentage}%</span>
                  <span className="text-[10px] text-slate-400">({r.count} students)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section 3: Administrative Strategic Decision Making (Informed Decisions) */}
      <div className="p-6 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 space-y-4">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h3 className="text-base font-bold text-indigo-950 dark:text-indigo-200">
            Informed Administrative Recommendations
          </h3>
        </div>
        <p className="text-xs text-indigo-800/80 dark:text-indigo-300/80">
          Synthesized from {totalStudentsCount} enrolled members, peak logs, and billing renewals:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 shadow-xs space-y-1.5">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              1. Open 15 Auxiliary Flex Desks in Zone C
            </span>
            <p className="text-xs text-slate-500 leading-relaxed">
              Evening slot (5 PM - 8 PM) hit 98% capacity with 4 waitlisted members. Converting 15 unassigned open desks into dedicated evening passes unlocks <strong>+₹9,000/month</strong> in new registration revenue.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 shadow-xs space-y-1.5">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              2. Launch 45-Day Exam Revision Fast-Pass
            </span>
            <p className="text-xs text-slate-500 leading-relaxed">
              42% of member churn coincides with university & civil services exam cycles. Offering targeted 45-day intensive revision packages recaptures exiting students for final sprint prep.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 shadow-xs space-y-1.5">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              3. Automated Morning Shift Overtime Policy
            </span>
            <p className="text-xs text-slate-500 leading-relaxed">
              14 Morning slot members stayed into the afternoon shift unbilled. Enabling kiosk auto-alert notifications upon afternoon check-in ensures fair desk availability for incoming students.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 shadow-xs space-y-1.5">
            <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              4. Prompt Payment Retention Incentive
            </span>
            <p className="text-xs text-slate-500 leading-relaxed">
              Members receiving automated WhatsApp push reminders 3 days before renewal showed a <strong>94% on-time settlement rate</strong> compared to 62% for manual follow-ups.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
