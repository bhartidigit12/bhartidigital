import type { Invoice, Student, StudentApplication } from '../types';

/**
 * Extracts trailing 10 digits if an Indian number (10 digits, 0+10, or 91+10)
 */
export function normalizePhone10(raw: string): string {
  const digits = (raw || '').replace(/\D/g, '');
  if (digits.length === 10) return digits;
  if (digits.length === 11 && digits.startsWith('0')) return digits.slice(1);
  if (digits.length === 12 && digits.startsWith('91')) return digits.slice(2);
  return digits;
}

export function isValidIndianPhone(raw: string): boolean {
  const d = normalizePhone10(raw);
  return /^[6-9]\d{9}$/.test(d) || /^\d{10}$/.test(d);
}

export function isValidEmail(raw: string): boolean {
  const trimmed = (raw || '').trim();
  if (!trimmed) return true; // Optional unless explicitly required
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(trimmed);
}

export function isValidUpiId(vpa: string): boolean {
  const trimmed = (vpa || '').trim();
  return /^[^\s@]+@[a-zA-Z0-9.-]{2,}$/.test(trimmed);
}

export function isValidCardNumber(raw: string): boolean {
  const digits = (raw || '').replace(/\D/g, '');
  if (digits.length < 13 || digits.length > 19) return false;
  if (/^(\d)\1+$/.test(digits)) return false; // Reject all identical digits like 0000...
  // Luhn checksum
  let sum = 0;
  let shouldDouble = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}

export function isValidCardExpiry(mmYy: string): boolean {
  const match = (mmYy || '').trim().match(/^(\d{2})\/(\d{2})$/);
  if (!match) return false;
  const month = parseInt(match[1], 10);
  const year = 2000 + parseInt(match[2], 10);
  if (month < 1 || month > 12) return false;

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  if (year < currentYear) return false;
  if (year === currentYear && month < currentMonth) return false;
  return true;
}

export async function safeCopyToClipboard(text: string): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback below
    }
  }
  if (typeof document === 'undefined') return false;
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}

export function compressImageFile(
  file: File,
  opts: { maxDim?: number; quality?: number } = {}
): Promise<string> {
  const { maxDim = 720, quality = 0.78 } = opts;
  return new Promise((resolve, reject) => {
    if (!file.type || !file.type.startsWith('image/')) {
      reject(new Error('Please select a valid image file (PNG, JPG, or WEBP).'));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the selected image file.'));
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid or corrupted image file.'));
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width || 1, img.height || 1));
        const width = Math.max(1, Math.round(img.width * scale));
        const height = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}

export function getNextStudentId(students: Student[]): string {
  const existing = new Set(students.map(s => s.id.toUpperCase()));
  let maxNum = 1000;
  for (const s of students) {
    const match = s.id.match(/LIB-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  }
  let nextNum = maxNum + 1;
  while (existing.has(`LIB-${nextNum}`)) {
    nextNum += 1;
  }
  return `LIB-${nextNum}`;
}

export function getNextApplicationId(apps: StudentApplication[]): string {
  const year = new Date().getFullYear();
  const existing = new Set(apps.map(a => a.id.toUpperCase()));
  let maxSeq = 1000;
  for (const a of apps) {
    const match = a.id.match(/APP-\d{4}-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxSeq) maxSeq = num;
    }
  }
  let nextSeq = maxSeq + 1;
  while (existing.has(`APP-${year}-${nextSeq}`)) {
    nextSeq += 1;
  }
  return `APP-${year}-${nextSeq}`;
}

export function generateUniqueInvoiceId(invoices: Invoice[]): string {
  const existing = new Set(invoices.map(i => i.id.toUpperCase()));
  let candidate = `INV-${Date.now().toString().slice(-6)}-${Math.floor(10 + Math.random() * 90)}`;
  while (existing.has(candidate)) {
    candidate = `INV-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
  }
  return candidate;
}
