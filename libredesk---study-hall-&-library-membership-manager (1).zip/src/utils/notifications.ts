import type { Student, LibrarySettings } from '../types';

/**
 * Audio synthesis for tactile check-in/out chimes & alert sounds
 */
class SoundEffects {
  private ctx: AudioContext | null = null;

  private initCtx() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playSuccess() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.12); // G5
      
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  playCheckOut() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(659.25, now); // E5
      osc.frequency.exponentialRampToValueAtTime(440.00, now + 0.15); // A4
      
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.25);
    } catch {
      // Audio autoplay fallback
    }
  }

  playAlert() {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.setValueAtTime(300, now + 0.1);
      
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // fallback
    }
  }
}

export const sounds = new SoundEffects();

/**
 * Browser Push Notification API
 */
export async function requestPushPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    const perm = await Notification.requestPermission();
    return perm === 'granted';
  } catch {
    return false;
  }
}

export function isPushSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getPushPermissionStatus(): NotificationPermission | 'unsupported' {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission;
}

export function sendBrowserPushNotification(title: string, body: string, icon = '/favicon.ico') {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return;
  }
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon,
        badge: icon,
        tag: 'libredesk-reminder',
      });
    } catch {
      // fallback
    }
  }
}

/**
 * Normalize phone number to international digits (defaults 10-digit Indian numbers to 91 prefix)
 */
export function normalizeWhatsAppPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return `91${digits}`;
  if (digits.length === 11 && digits.startsWith('0')) return `91${digits.slice(1)}`;
  return digits;
}

export function formatWhatsAppPhoneDisplay(phone: string): string {
  const normalized = normalizeWhatsAppPhone(phone);
  if (normalized.length === 12 && normalized.startsWith('91')) {
    return `+91 ${normalized.slice(2, 7)} ${normalized.slice(7)}`;
  }
  return phone || 'Not provided';
}

export function generateWhatsAppReminderMessage(
  student: Student,
  settings: LibrarySettings,
  portalOrigin?: string
): string {
  const libName = settings.whatsappBusinessName || settings.name || 'Bharti Digital Library';
  const statusLabel =
    student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED'
      ? 'OVERDUE'
      : 'DUE SOON';
  const lines: string[] = [
    `*${libName} — Fee Reminder (${statusLabel})*`,
    ``,
    `Dear *${student.name}*,`,
    `Your monthly study hall fee for *Desk ${student.assignedDesk}* (ID: ${student.id}) is ${
      statusLabel === 'OVERDUE' ? 'overdue' : 'due for renewal'
    }.`,
    ``,
    `• *Amount Due:* ₹${student.monthlyFee.toLocaleString('en-IN')}`,
    `• *Renewal Due Date:* ${student.renewalDueDate}`,
  ];

  if (settings.whatsappIncludeUpi !== false) {
    const upiId = settings.upiId || '9973299354@ybl';
    const upiNum = settings.upiNumber || settings.phone || '9973299354';
    const payee = settings.upiPayeeName || libName;
    lines.push(
      ``,
      `*Pay Online via PhonePe / UPI:*`,
      `• UPI ID: ${upiId}`,
      `• PhonePe / Mobile: ${upiNum}`,
      `• Account Name: ${payee}`
    );
  }

  if (settings.whatsappIncludePortalLink !== false) {
    const origin =
      portalOrigin ||
      (typeof window !== 'undefined' ? window.location.origin : '');
    if (origin) {
      lines.push(
        ``,
        `*Your Digital Pass & Online Pay Link:*`,
        `${origin}/?student_id=${encodeURIComponent(student.id)}`
      );
    }
  }

  const footerNote =
    settings.whatsappCustomNote?.trim() ||
    'Kindly pay on time and share your 12-digit UTR or counter receipt.';
  const ourWa = formatWhatsAppPhoneDisplay(settings.whatsappNumber || settings.phone || '9973299354');

  lines.push(``, footerNote, `— ${libName} (${ourWa})`);
  return lines.join('\n');
}

export function buildStudentWhatsAppUrl(
  student: Student,
  settings: LibrarySettings
): { url: string; message: string; formattedPhone: string; isValidPhone: boolean } {
  const normalized = normalizeWhatsAppPhone(student.phone);
  const formattedPhone = formatWhatsAppPhoneDisplay(student.phone);
  const message = generateWhatsAppReminderMessage(student, settings);
  const url = normalized
    ? `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`
    : `https://wa.me/?text=${encodeURIComponent(message)}`;
  return {
    url,
    message,
    formattedPhone,
    isValidPhone: normalized.length >= 10,
  };
}

/**
 * WhatsApp Reminder Link Generator
 */
export function generateWhatsAppReminderUrl(
  phone: string,
  studentName: string,
  dueDate: string,
  amount: number,
  libraryName: string,
  desk: string,
  customMessage?: string
): string {
  const cleanPhone = normalizeWhatsAppPhone(phone);
  const message =
    customMessage ||
    `Dear ${studentName},\n\nThis is a friendly reminder from ${libraryName}. Your study space membership for Desk ${desk} is due on ${dueDate}.\nAmount Due: ₹${amount.toLocaleString('en-IN')}\n\nPlease renew via UPI/Cash/Card at the counter or reply to this message to confirm online transfer.\n\nThank you for studying with us!`;
  return cleanPhone
    ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`
    : `https://wa.me/?text=${encodeURIComponent(message)}`;
}

/**
 * SMS / Copy Reminder Text Generator
 */
export function generateReminderTextMessage(studentName: string, dueDate: string, amount: number, libraryName: string, desk: string): string {
  return `[${libraryName}] Hi ${studentName}, membership for Seat ${desk} expires on ${dueDate}. Fee due: ₹${amount.toLocaleString('en-IN')}. Kindly clear payment to secure your reserved slot.`;
}
