/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Student, 
  AttendanceRecord, 
  Invoice, 
  PushReminder, 
  LibrarySettings,
  ShiftType,
  StudentApplication,
  calculateShiftFee
} from './types';
import { 
  DEFAULT_SETTINGS, 
  generateInitialStudents, 
  generateInitialAttendanceHistory, 
  generateInitialInvoices, 
  generateInitialReminders,
  generateInitialApplications,
  HOURLY_PEAK_DATA,
  RETENTION_COHORTS
} from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { DashboardView } from './components/DashboardView';
import { AttendanceView } from './components/AttendanceView';
import { MembersView } from './components/MembersView';
import { BillingView } from './components/BillingView';
import { AnalyticsView } from './components/AnalyticsView';
import { KioskCheckInModal } from './components/KioskCheckInModal';
import { StudentCardModal } from './components/StudentCardModal';
import { RegisterMemberModal } from './components/RegisterMemberModal';
import { StudentSelfRegisterModal } from './components/StudentSelfRegisterModal';
import { AdminApprovalModal } from './components/AdminApprovalModal';
import { EditStudentModal } from './components/EditStudentModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { NotificationDrawer } from './components/NotificationDrawer';
import { StudentPortalView } from './components/StudentPortalView';
import { PhonePeScannerCard } from './components/PhonePeScannerCard';
import { ScannedStudentDetailModal } from './components/ScannedStudentDetailModal';
import { sendBrowserPushNotification, sounds } from './utils/notifications';
import { defaultStudentAvatar } from './utils/assets';
import { generateUniqueInvoiceId, getNextApplicationId, getNextStudentId } from './utils/validation';

const STORAGE_KEYS = {
  STUDENTS: 'bharti_students_v3',
  ATTENDANCE: 'bharti_attendance_v4',
  INVOICES: 'bharti_invoices_v4',
  REMINDERS: 'bharti_reminders_v3',
  SETTINGS: 'bharti_settings_v3',
  UPI_VAULT: 'bharti_upi_vault_v1',
  APPLICATIONS: 'bharti_applications_v3',
  ADMIN_PIN: 'bharti_admin_pin_v2',
  STUDENT_SESSION: 'bharti_student_session_v1',
};

const DEFAULT_STRONG_ADMIN_PIN = 'BDL@9973';

export default function App() {
  // Primary state initialized from localStorage with fallback to the 72-student sheet roster
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return generateInitialStudents();
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ATTENDANCE);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return generateInitialAttendanceHistory(generateInitialStudents());
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.INVOICES);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return generateInitialInvoices(generateInitialStudents());
  });

  const [reminders, setReminders] = useState<PushReminder[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.REMINDERS);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return generateInitialReminders(generateInitialStudents());
  });

  const [applications, setApplications] = useState<StudentApplication[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
      if (stored) return JSON.parse(stored);
    } catch {
      // fallback
    }
    return generateInitialApplications();
  });

  const [settings, setSettings] = useState<LibrarySettings>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      const vaultRaw = localStorage.getItem(STORAGE_KEYS.UPI_VAULT);
      const vault = vaultRaw ? JSON.parse(vaultRaw) : {};
      const parsed = stored ? JSON.parse(stored) : {};

      const resolvedPhone =
        !parsed.phone || parsed.phone === '+91 98765 43210' ? '9973299354' : parsed.phone;

      const rawUpiNum = vault.upiNumber ?? parsed.upiNumber;
      const resolvedUpiNumber =
        !rawUpiNum || rawUpiNum === '+91 98765 43210' ? '9973299354' : rawUpiNum;

      const rawUpiId = vault.upiId ?? parsed.upiId;
      const resolvedUpiId =
        !rawUpiId || rawUpiId === '9876543210@ybl' ? '9973299354@ybl' : rawUpiId;

      const resolvedPayee = vault.upiPayeeName ?? parsed.upiPayeeName ?? DEFAULT_SETTINGS.upiPayeeName;
      const resolvedQr =
        vault.phonePeQrImageUrl !== undefined
          ? vault.phonePeQrImageUrl
          : parsed.phonePeQrImageUrl;

      if (stored || vaultRaw) {
        return {
          ...DEFAULT_SETTINGS,
          ...parsed,
          name: 'Bharti Digital Library',
          ownerName:
            !parsed.ownerName || parsed.ownerName === 'Chandu Yadav' || parsed.ownerName === 'Mukesh Kumar'
              ? 'Raj'
              : parsed.ownerName,
          phone: resolvedPhone,
          address:
            !parsed.address || parsed.address === 'Civil Lines, Near University Gate'
              ? 'Sekhwara More, Bodhgaya 824234'
              : parsed.address,
          upiNumber: resolvedUpiNumber,
          upiId: resolvedUpiId,
          upiPayeeName: resolvedPayee,
          phonePeQrImageUrl: resolvedQr,
          whatsappConnected: parsed.whatsappConnected ?? true,
          whatsappNumber: parsed.whatsappNumber || resolvedPhone,
          whatsappBusinessName: parsed.whatsappBusinessName || 'Bharti Digital Library',
          whatsappIncludeUpi: parsed.whatsappIncludeUpi ?? true,
          whatsappIncludePortalLink: parsed.whatsappIncludePortalLink ?? true,
          whatsappCustomNote:
            parsed.whatsappCustomNote ?? DEFAULT_SETTINGS.whatsappCustomNote,
          currency: '₹',
          monthlyFees: {
            ...DEFAULT_SETTINGS.monthlyFees,
            ...(parsed.monthlyFees || {}),
            NIGHT_OWL:
              !parsed.monthlyFees?.NIGHT_OWL || parsed.monthlyFees.NIGHT_OWL === 500
                ? 350
                : parsed.monthlyFees.NIGHT_OWL,
          },
        };
      }
    } catch {
      // fallback
    }
    return DEFAULT_SETTINGS;
  });

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'dashboard' | 'attendance' | 'members' | 'billing' | 'analytics' | 'student-portal'>('dashboard');
  const [billingInitialSubTab, setBillingInitialSubTab] = useState<'LEDGER' | 'YEARLY_MATRIX' | 'PHONEPE_SCANNER' | 'WHATSAPP_REMINDERS'>('LEDGER');
  const [loggedInStudentId, setLoggedInStudentId] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.STUDENT_SESSION);
    } catch {
      return null;
    }
  });

  // Modal dialog states
  const [isKioskOpen, setIsKioskOpen] = useState(false);
  const [kioskInitialMode, setKioskInitialMode] = useState<'PIN' | 'SEARCH' | 'QR'>('PIN');
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [isSelfRegisterOpen, setIsSelfRegisterOpen] = useState(false);
  const [isApprovalsOpen, setIsApprovalsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [selectedStudentForCard, setSelectedStudentForCard] = useState<Student | null>(null);
  const [scannedStudentId, setScannedStudentId] = useState<string | null>(() => {
    try {
      const idParam = new URLSearchParams(window.location.search).get('student_id');
      return idParam ? idParam.trim() : null;
    } catch {
      return null;
    }
  });
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [selectedStudentForPayment, setSelectedStudentForPayment] = useState<Student | null>(null);
  const [quickPayAmount, setQuickPayAmount] = useState<number>(500);
  const [quickPayMethod, setQuickPayMethod] = useState<'UPI' | 'CASH' | 'CARD'>('UPI');
  const [quickPayError, setQuickPayError] = useState<string | null>(null);
  const [storageWarning, setStorageWarning] = useState<string | null>(null);

  // Admin-only edit protection (locked by default so non-admins cannot edit)
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isAdminAuthOpen, setIsAdminAuthOpen] = useState<boolean>(false);
  const [adminPin, setAdminPin] = useState<string>(() => {
    try {
      const v2 = localStorage.getItem(STORAGE_KEYS.ADMIN_PIN);
      if (v2 && v2.trim().length >= 6) return v2.trim();

      // Migrate custom strong PIN from v1 if present; replace weak defaults like '1234'
      const v1 = localStorage.getItem('bharti_admin_pin_v1');
      if (v1 && v1.trim().length >= 6 && !/^(.)\1+$/.test(v1.trim()) && v1.trim() !== '123456') {
        localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, v1.trim());
        return v1.trim();
      }
      localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, DEFAULT_STRONG_ADMIN_PIN);
      return DEFAULT_STRONG_ADMIN_PIN;
    } catch {
      return DEFAULT_STRONG_ADMIN_PIN;
    }
  });
  const [pendingAdminAction, setPendingAdminAction] = useState<(() => void) | null>(null);

  const runAsAdmin = (action?: () => void) => {
    if (isAdmin) {
      action?.();
    } else {
      if (action) {
        setPendingAdminAction(() => action);
      }
      setIsAdminAuthOpen(true);
    }
  };

  // Sync to local storage with quota warning
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    } catch {
      setStorageWarning('Browser storage limit reached while saving members. Clear old screenshots or export a CSV backup.');
    }
  }, [students]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
    } catch {
      setStorageWarning('Browser storage limit reached while saving applications. Consider approving or clearing old entries.');
    }
  }, [applications]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendanceRecords));
    } catch {
      setStorageWarning('Browser storage limit reached while saving attendance history.');
    }
  }, [attendanceRecords]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    } catch {
      setStorageWarning('Browser storage limit reached while saving invoices/screenshots.');
    }
  }, [invoices]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.REMINDERS, JSON.stringify(reminders));
    } catch {
      setStorageWarning('Browser storage limit reached while saving reminders.');
    }
  }, [reminders]);

  useEffect(() => {
    const upiVaultPayload = {
      upiNumber: settings.upiNumber,
      upiId: settings.upiId,
      upiPayeeName: settings.upiPayeeName,
      phonePeQrImageUrl: settings.phonePeQrImageUrl || null,
    };
    try {
      localStorage.setItem(STORAGE_KEYS.UPI_VAULT, JSON.stringify(upiVaultPayload));
    } catch {
      setStorageWarning('Storage limit reached while saving UPI QR image.');
    }
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch {
      // Fallback: save settings without large QR if full settings exceeds quota; QR stays in UPI_VAULT
      try {
        const { phonePeQrImageUrl: _qr, ...liteSettings } = settings;
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(liteSettings));
      } catch {
        setStorageWarning('Browser storage limit reached while saving settings.');
      }
    }
  }, [settings]);

  // Clear stale student session if member ID no longer exists
  useEffect(() => {
    if (loggedInStudentId && !students.some(s => s.id === loggedInStudentId)) {
      setLoggedInStudentId(null);
      try {
        localStorage.removeItem(STORAGE_KEYS.STUDENT_SESSION);
      } catch {
        // ignore
      }
    }
  }, [loggedInStudentId, students]);

  const handleUpdateSettings = (updates: Partial<LibrarySettings>) => {
    if (!isAdmin) {
      setIsAdminAuthOpen(true);
      return;
    }
    setSettings(prev => {
      const next = { ...prev, ...updates };
      try {
        localStorage.setItem(
          STORAGE_KEYS.UPI_VAULT,
          JSON.stringify({
            upiNumber: next.upiNumber,
            upiId: next.upiId,
            upiPayeeName: next.upiPayeeName,
            phonePeQrImageUrl: next.phonePeQrImageUrl || null,
          })
        );
      } catch {
        // ignore
      }
      return next;
    });
    sounds.playSuccess();
  };

  // Automated check-in / check-out handler (local date/time + optional custom HH:mm time)
  const handleCheckInToggle = (
    studentId: string,
    method: 'QR_SCAN' | 'PIN_KIOSK' | 'STAFF_MANUAL' | 'BIOMETRIC_SIM',
    customTimeHHMM?: string
  ): {
    success: boolean;
    student?: Student;
    action?: 'IN' | 'OUT';
    inTime?: string;
    outTime?: string;
    durationMinutes?: number;
    message?: string;
  } => {
    const student = students.find(s => s.id === studentId);
    if (!student) {
      return { success: false, message: 'Student not found' };
    }

    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const nowHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const resolvedHHMM = customTimeHHMM && /^\d{2}:\d{2}$/.test(customTimeHHMM) ? customTimeHHMM : nowHHMM;
    const nowIso = `${todayStr}T${resolvedHHMM}:00`;
    const isCheckingIn = student.attendanceStatus === 'CHECKED_OUT';

    let updatedStudents: Student[];
    let action: 'IN' | 'OUT';
    let resolvedInTime = nowIso;
    let resolvedOutTime: string | undefined;
    let resolvedDuration: number | undefined;

    if (isCheckingIn) {
      action = 'IN';
      updatedStudents = students.map(s => {
        if (s.id === studentId) {
          return {
            ...s,
            attendanceStatus: 'CHECKED_IN',
            currentCheckInTime: nowIso,
            currentCheckInDurationMinutes: 0,
            totalVisitsThisMonth: s.totalVisitsThisMonth + 1,
          };
        }
        return s;
      });

      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}`,
        studentId: student.id,
        studentName: student.name,
        assignedDesk: student.assignedDesk,
        shift: student.shift,
        checkInTime: nowIso,
        method: method === 'STAFF_MANUAL' ? 'STAFF_MANUAL' : method,
        overtimeAlert: false,
      };

      setAttendanceRecords(prev => [newRecord, ...prev]);

      sendBrowserPushNotification(
        `✓ Check-in: ${student.name}`,
        `In Time: ${resolvedHHMM} · Desk ${student.assignedDesk}.`
      );
    } else {
      action = 'OUT';
      resolvedOutTime = nowIso;
      resolvedInTime = student.currentCheckInTime || nowIso;

      const parseLocalOrIso = (isoStr: string) => new Date(isoStr);
      const entryDate = student.currentCheckInTime
        ? parseLocalOrIso(student.currentCheckInTime)
        : new Date(now.getTime() - 120 * 60000);
      const exitDate = customTimeHHMM ? new Date(nowIso) : now;
      let durationMins = Math.round((exitDate.getTime() - entryDate.getTime()) / 60000);
      if (durationMins < 0) durationMins += 24 * 60;
      durationMins = Math.max(1, durationMins);
      resolvedDuration = durationMins;

      updatedStudents = students.map(s => {
        if (s.id === studentId) {
          return {
            ...s,
            attendanceStatus: 'CHECKED_OUT',
            currentCheckInTime: undefined,
            currentCheckInDurationMinutes: undefined,
          };
        }
        return s;
      });

      setAttendanceRecords(prev => {
        let matched = false;
        return prev.map(rec => {
          if (!matched && rec.studentId === studentId && !rec.checkOutTime) {
            matched = true;
            resolvedInTime = rec.checkInTime;
            return {
              ...rec,
              checkOutTime: nowIso,
              durationMinutes: durationMins,
            };
          }
          return rec;
        });
      });

      sendBrowserPushNotification(
        `👋 Check-out: ${student.name}`,
        `Out Time: ${resolvedHHMM} · Studied ${Math.floor(durationMins / 60)}h ${durationMins % 60}m.`
      );
    }

    setStudents(updatedStudents);
    const updatedStudent = updatedStudents.find(s => s.id === studentId);

    return {
      success: true,
      student: updatedStudent,
      action,
      inTime: resolvedInTime,
      outTime: resolvedOutTime,
      durationMinutes: resolvedDuration,
      message: action === 'IN' ? 'Checked in successfully' : 'Checked out successfully',
    };
  };

  // Daily Attendance Sheet: mark single student Present, Check-Out, Absent, or update In/Out times
  const handleMarkDailyAttendance = (
    studentId: string,
    dateStr: string,
    action: 'PRESENT' | 'ABSENT' | 'CHECK_OUT',
    inTime?: string,
    outTime?: string
  ) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const nowHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const isToday = dateStr === todayStr;

    const calcMinutes = (startHHMM: string, endHHMM: string) => {
      const [sH, sM] = startHHMM.split(':').map(Number);
      const [eH, eM] = endHHMM.split(':').map(Number);
      let diff = (eH * 60 + eM) - (sH * 60 + sM);
      if (diff <= 0) diff += 24 * 60;
      return Math.max(1, diff);
    };

    const hadRecordOnDate = attendanceRecords.some(
      r => r.studentId === studentId && r.checkInTime.startsWith(dateStr)
    );

    if (action === 'ABSENT') {
      setAttendanceRecords(prev =>
        prev.filter(r => !(r.studentId === studentId && r.checkInTime.startsWith(dateStr)))
      );
      if (isToday) {
        setStudents(prev =>
          prev.map(s =>
            s.id === studentId
              ? {
                  ...s,
                  attendanceStatus: 'CHECKED_OUT',
                  currentCheckInTime: undefined,
                  currentCheckInDurationMinutes: undefined,
                  totalVisitsThisMonth: hadRecordOnDate
                    ? Math.max(0, s.totalVisitsThisMonth - 1)
                    : s.totalVisitsThisMonth,
                }
              : s
          )
        );
      }
      return;
    }

    if (action === 'CHECK_OUT') {
      const targetOut = outTime || nowHHMM;
      const outIso = `${dateStr}T${targetOut}:00`;
      setAttendanceRecords(prev => {
        let updated = false;
        return prev.map(r => {
          if (!updated && r.studentId === studentId && r.checkInTime.startsWith(dateStr) && !r.checkOutTime) {
            updated = true;
            const inHHMM = r.checkInTime.split('T')[1]?.substring(0, 5) || '08:30';
            return {
              ...r,
              checkOutTime: outIso,
              durationMinutes: calcMinutes(inHHMM, targetOut),
            };
          }
          return r;
        });
      });
      if (isToday) {
        setStudents(prev =>
          prev.map(s =>
            s.id === studentId
              ? {
                  ...s,
                  attendanceStatus: 'CHECKED_OUT',
                  currentCheckInTime: undefined,
                  currentCheckInDurationMinutes: undefined,
                }
              : s
          )
        );
      }
      return;
    }

    // action === 'PRESENT'
    const resolvedIn = inTime || (isToday ? nowHHMM : '08:30');
    const resolvedOut = outTime !== undefined ? (outTime || undefined) : isToday ? undefined : '14:30';
    const inIso = `${dateStr}T${resolvedIn}:00`;
    const outIso = resolvedOut ? `${dateStr}T${resolvedOut}:00` : undefined;
    const durationMins = resolvedOut ? calcMinutes(resolvedIn, resolvedOut) : undefined;

    if (hadRecordOnDate) {
      setAttendanceRecords(prev => {
        let updated = false;
        return prev.map(r => {
          if (!updated && r.studentId === studentId && r.checkInTime.startsWith(dateStr)) {
            updated = true;
            return {
              ...r,
              checkInTime: inIso,
              checkOutTime: outIso,
              durationMinutes: durationMins,
            };
          }
          return r;
        });
      });
    } else {
      const newRecord: AttendanceRecord = {
        id: `ATT-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        studentId: student.id,
        studentName: student.name,
        assignedDesk: student.assignedDesk,
        shift: student.shift,
        checkInTime: inIso,
        checkOutTime: outIso,
        durationMinutes: durationMins,
        method: 'STAFF_MANUAL',
        overtimeAlert: false,
      };
      setAttendanceRecords(prev => [newRecord, ...prev]);
    }

    const isSameMonthAsCurrent = dateStr.startsWith(todayStr.slice(0, 7));
    setStudents(prev =>
      prev.map(s => {
        if (s.id !== studentId) return s;
        return {
          ...s,
          ...(isToday
            ? {
                attendanceStatus: resolvedOut ? 'CHECKED_OUT' : 'CHECKED_IN',
                currentCheckInTime: resolvedOut ? undefined : inIso,
                currentCheckInDurationMinutes: resolvedOut ? undefined : 0,
              }
            : {}),
          totalVisitsThisMonth:
            !hadRecordOnDate && isSameMonthAsCurrent ? s.totalVisitsThisMonth + 1 : s.totalVisitsThisMonth,
        };
      })
    );
  };

  // Daily Attendance Sheet: atomic bulk mark
  const handleBulkMarkDailyAttendance = (
    studentIds: string[],
    dateStr: string,
    action: 'PRESENT' | 'ABSENT'
  ) => {
    const idSet = new Set(studentIds);
    const now = new Date();
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const nowHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const isToday = dateStr === todayStr;
    const isSameMonthAsCurrent = dateStr.startsWith(todayStr.slice(0, 7));

    if (action === 'ABSENT') {
      const hadSet = new Set(
        attendanceRecords
          .filter(r => idSet.has(r.studentId) && r.checkInTime.startsWith(dateStr))
          .map(r => r.studentId)
      );
      setAttendanceRecords(prev =>
        prev.filter(r => !(idSet.has(r.studentId) && r.checkInTime.startsWith(dateStr)))
      );
      if (isToday) {
        setStudents(prev =>
          prev.map(s =>
            idSet.has(s.id)
              ? {
                  ...s,
                  attendanceStatus: 'CHECKED_OUT',
                  currentCheckInTime: undefined,
                  currentCheckInDurationMinutes: undefined,
                  totalVisitsThisMonth: hadSet.has(s.id)
                    ? Math.max(0, s.totalVisitsThisMonth - 1)
                    : s.totalVisitsThisMonth,
                }
              : s
          )
        );
      }
      return;
    }

    const alreadyPresentIds = new Set(
      attendanceRecords
        .filter(r => r.checkInTime.startsWith(dateStr))
        .map(r => r.studentId)
    );
    const toMark = students.filter(s => idSet.has(s.id) && !alreadyPresentIds.has(s.id));
    if (toMark.length === 0) return;

    const inTime = isToday ? nowHHMM : '08:30';
    const inIso = `${dateStr}T${inTime}:00`;
    const outIso = isToday ? undefined : `${dateStr}T14:30:00`;
    const durationMins = isToday ? undefined : 360;
    const newIdSet = new Set(toMark.map(s => s.id));

    const newRecords: AttendanceRecord[] = toMark.map((s, idx) => ({
      id: `ATT-BULK-${Date.now()}-${idx}`,
      studentId: s.id,
      studentName: s.name,
      assignedDesk: s.assignedDesk,
      shift: s.shift,
      checkInTime: inIso,
      checkOutTime: outIso,
      durationMinutes: durationMins,
      method: 'STAFF_MANUAL',
      overtimeAlert: false,
    }));

    setAttendanceRecords(prev => [...newRecords, ...prev]);
    setStudents(prev =>
      prev.map(s => {
        if (!newIdSet.has(s.id)) return s;
        return {
          ...s,
          ...(isToday
            ? {
                attendanceStatus: 'CHECKED_IN',
                currentCheckInTime: inIso,
                currentCheckInDurationMinutes: 0,
              }
            : {}),
          totalVisitsThisMonth: isSameMonthAsCurrent ? s.totalVisitsThisMonth + 1 : s.totalVisitsThisMonth,
        };
      })
    );
  };

  // Register new student handler
  const handleRegister = (newStudentData: Omit<Student, 'id' | 'pin'>): Student => {
    const id = getNextStudentId(students);
    const pin = String(1000 + Math.floor(Math.random() * 9000));

    const newStudent: Student = {
      ...newStudentData,
      id,
      pin,
    };

    setStudents(prev => [newStudent, ...prev]);

    // If initial fee was paid, create invoice
    if (newStudent.paymentStatus === 'PAID') {
      const today = new Date().toISOString().split('T')[0];
      const newInvoice: Invoice = {
        id: generateUniqueInvoiceId(invoices),
        studentId: id,
        studentName: newStudent.name,
        phone: newStudent.phone,
        planName: newStudent.plan.replace('_', ' '),
        amount: newStudent.monthlyFee,
        paidDate: newStudent.lastPaymentDate || today,
        periodStart: newStudent.cardValidFrom || today,
        periodEnd: newStudent.renewalDueDate,
        paymentMethod: 'UPI',
        transactionRef: `REG${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        status: 'PAID',
      };
      setInvoices(prev => [newInvoice, ...prev]);
    }

    // Automatically show their digital pass ID card so the owner can print it or hand it to them!
    setSelectedStudentForCard(newStudent);

    return newStudent;
  };

  // Student self-registration handler
  const handleSubmitApplication = (appData: Omit<StudentApplication, 'id' | 'submittedAt' | 'status'>): StudentApplication => {
    const id = getNextApplicationId(applications);
    const newApp: StudentApplication = {
      ...appData,
      id,
      submittedAt: new Date().toISOString(),
      status: 'PENDING',
    };
    setApplications(prev => [newApp, ...prev]);
    return newApp;
  };

  // Admin approval handler
  const handleApproveApplication = (
    applicationId: string,
    assignedDesk: string,
    feePaidNow: boolean,
    approvedShifts?: ShiftType[],
    admissionDate?: string
  ): { student: Student; application: StudentApplication } => {
    const app = applications.find(a => a.id === applicationId);
    const studentId = getNextStudentId(students);
    const pin = String(1000 + Math.floor(Math.random() * 9000));
    const today = new Date().toISOString().split('T')[0];
    const effectiveAdmissionDate = admissionDate || today;
    const [admY, admM, admD] = effectiveAdmissionDate.split('-').map(Number);
    const dueDate = Number.isFinite(admY) && Number.isFinite(admM) && Number.isFinite(admD)
      ? new Date(Date.UTC(admY, admM - 1, admD + 30)).toISOString().split('T')[0]
      : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const finalShifts: ShiftType[] =
      approvedShifts && approvedShifts.length > 0
        ? approvedShifts
        : app?.desiredShifts && app.desiredShifts.length > 0
        ? app.desiredShifts
        : [app?.desiredShift || 'DAY_9TO5'];
    const monthlyFee = calculateShiftFee(finalShifts, settings.monthlyFees);

    const newStudent: Student = {
      id: studentId,
      pin,
      name: app?.fullName || 'Student',
      phone: app?.phone || '',
      email: app?.email || '',
      avatarUrl: app?.avatarUrl || defaultStudentAvatar,
      assignedDesk: assignedDesk || 'General / Flex',
      hasLocker: app?.hasLocker || false,
      lockerNumber: app?.hasLocker ? `L-${Math.floor(100 + Math.random() * 899)}` : undefined,
      shift: finalShifts[0],
      shifts: finalShifts,
      plan: app?.desiredPlan || 'MONTHLY_FULL_DAY',
      monthlyFee,
      paymentStatus: feePaidNow ? 'PAID' : 'DUE_SOON',
      joinedDate: effectiveAdmissionDate,
      cardValidFrom: effectiveAdmissionDate,
      renewalDueDate: dueDate,
      lastPaymentDate: feePaidNow ? effectiveAdmissionDate : undefined,
      attendanceStatus: 'CHECKED_OUT',
      totalVisitsThisMonth: 0,
      avgHoursPerVisit: 0,
      courseOrExam: app?.courseOrExam || 'Study Hall Member',
    };

    setStudents(prev => [newStudent, ...prev]);

    if (feePaidNow) {
      const newInvoice: Invoice = {
        id: generateUniqueInvoiceId(invoices),
        studentId: newStudent.id,
        studentName: newStudent.name,
        phone: newStudent.phone,
        planName: newStudent.plan.replace('_', ' '),
        amount: newStudent.monthlyFee,
        paidDate: effectiveAdmissionDate,
        periodStart: effectiveAdmissionDate,
        periodEnd: dueDate,
        paymentMethod: 'UPI',
        transactionRef: `APP${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        status: 'PAID',
      };
      setInvoices(prev => [newInvoice, ...prev]);
    }

    const updatedApp: StudentApplication = {
      ...(app as StudentApplication),
      status: 'APPROVED',
      reviewedAt: new Date().toISOString(),
      admissionDate: effectiveAdmissionDate,
      assignedDesk,
      studentIdCreated: newStudent.id,
    };

    setApplications(prev => prev.map(a => a.id === applicationId ? updatedApp : a));
    setSelectedStudentForCard(newStudent);

    return { student: newStudent, application: updatedApp };
  };

  // Admin rejection handler
  const handleRejectApplication = (applicationId: string, reason: string) => {
    setApplications(prev => prev.map(a => {
      if (a.id === applicationId) {
        return {
          ...a,
          status: 'REJECTED',
          reviewedAt: new Date().toISOString(),
          rejectionReason: reason,
        };
      }
      return a;
    }));
  };

  // High-volume batch registration simulator (e.g. 50-100 students at once!)
  const handleBatchSimulate = (count = 50) => {
    const shifts: ShiftType[] = ['DAY_9TO5', 'TWELVE_HOURS', 'MORNING', 'EVENING', 'AFTERNOON', 'NIGHT_OWL', 'TWENTY_FOUR_HOURS', 'FULL_DAY'];
    const sampleNames = ['Aditi Rao', 'Kunal Verma', 'Simran Gill', 'Farhan Khan', 'Tanvi Sengupta', 'Nikhil Joshi', 'Deepak Yadav', 'Pooja Agarwal'];

    const newBatch: Student[] = [];
    const nextStartNum = parseInt(getNextStudentId(students).replace('LIB-', ''), 10) || (1000 + students.length + 1);

    for (let i = 0; i < count; i++) {
      const num = nextStartNum + i;
      const sName = `${sampleNames[i % sampleNames.length]} #${i + 1}`;
      const sShift = shifts[i % shifts.length];
      const sShifts = i % 5 === 0 ? (['MORNING', 'EVENING'] as ShiftType[]) : [sShift];
      const zone = i % 2 === 0 ? 'B' : 'C';
      const deskNum = (i % 40) + 1;
      const today = new Date().toISOString().split('T')[0];
      const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      newBatch.push({
        id: `LIB-${num}`,
        pin: String(1000 + Math.floor(Math.random() * 9000)),
        name: sName,
        phone: `+91 98${String(100 + (i % 899)).padStart(3, '0')} ${String(10000 + ((i * 71) % 89999)).padStart(5, '0')}`,
        email: `student.${num}@bhartilibrary.in`,
        avatarUrl: defaultStudentAvatar,
        assignedDesk: `${zone}-${String(deskNum).padStart(2, '0')}`,
        hasLocker: i % 4 === 0,
        lockerNumber: i % 4 === 0 ? `L-${String(num).slice(-3)}` : undefined,
        shift: sShifts[0],
        shifts: sShifts,
        plan: 'MONTHLY_FULL_DAY',
        monthlyFee: calculateShiftFee(sShifts, settings.monthlyFees),
        paymentStatus: 'PAID',
        joinedDate: today,
        cardValidFrom: today,
        renewalDueDate: dueDate,
        lastPaymentDate: today,
        attendanceStatus: 'CHECKED_OUT',
        totalVisitsThisMonth: 0,
        avgHoursPerVisit: 0,
        courseOrExam: 'Civil Services / UPSC',
      });
    }

    setStudents(prev => [...newBatch, ...prev]);
    sounds.playSuccess();
    sendBrowserPushNotification(
      '🚀 Batch Registration Completed',
      `Registered ${count} new student memberships. Total active members now: ${students.length + count}.`
    );
  };

  // Record payment & renew membership (supports optional targetYearMonth e.g. "2026-02")
  const handleRecordPayment = (
    studentId: string, 
    amount: number, 
    method: 'UPI' | 'CASH' | 'CARD',
    targetYearMonth?: string
  ): Invoice => {
    const student = students.find(s => s.id === studentId);
    const today = new Date().toISOString().split('T')[0];
    const currentYM = today.slice(0, 7);
    const effectiveYM = targetYearMonth || currentYM;
    const newDueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Update student payment status if settling current month or general renewal
    if (effectiveYM >= currentYM) {
      setStudents(prev => prev.map(s => {
        if (s.id === studentId) {
          return {
            ...s,
            paymentStatus: 'PAID',
            cardValidFrom: today,
            renewalDueDate: newDueDate,
            lastPaymentDate: today,
          };
        }
        return s;
      }));
      setSelectedStudentForCard(prev =>
        prev && prev.id === studentId
          ? {
              ...prev,
              paymentStatus: 'PAID',
              cardValidFrom: today,
              renewalDueDate: newDueDate,
              lastPaymentDate: today,
            }
          : prev
      );
    }

    // Create invoice anchored to the target billing month
    const newInvoice: Invoice = {
      id: generateUniqueInvoiceId(invoices),
      studentId,
      studentName: student?.name || 'Member',
      phone: student?.phone || '',
      planName: student?.plan.replace('_', ' ') || 'Study Pass',
      amount,
      paidDate: today,
      periodStart: `${effectiveYM}-01`,
      periodEnd: effectiveYM === currentYM ? newDueDate : `${effectiveYM}-28`,
      paymentMethod: method,
      transactionRef: `PAY${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      status: 'PAID',
    };

    setInvoices(prev => [newInvoice, ...prev]);

    // Send push notification
    sendBrowserPushNotification(
      '💰 Payment Received & Renewed',
      `₹${amount.toLocaleString('en-IN')} received from ${student?.name}. Membership extended to ${newDueDate}.`
    );

    return newInvoice;
  };

  // Student Portal: submit online UPI / Card payment with mandatory UTR for Admin verification
  const handleSubmitOnlinePaymentRequest = (
    studentId: string,
    amount: number,
    method: 'UPI' | 'CARD',
    transactionRef: string,
    targetYearMonth?: string,
    proofImageUrl?: string
  ): Invoice => {
    const student = students.find(s => s.id === studentId);
    const today = new Date().toISOString().split('T')[0];
    const currentYM = today.slice(0, 7);
    const effectiveYM = targetYearMonth || currentYM;
    const newDueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const pendingInvoice: Invoice = {
      id: generateUniqueInvoiceId(invoices),
      studentId,
      studentName: student?.name || 'Member',
      phone: student?.phone || '',
      planName: student?.plan.replace('_', ' ') || 'Study Pass',
      amount,
      paidDate: today,
      periodStart: `${effectiveYM}-01`,
      periodEnd: effectiveYM === currentYM ? newDueDate : `${effectiveYM}-28`,
      paymentMethod: method,
      transactionRef: transactionRef.trim().toUpperCase(),
      proofImageUrl,
      status: 'PENDING',
    };

    setInvoices(prev => [pendingInvoice, ...prev]);

    sendBrowserPushNotification(
      '🔔 Online Payment Pending Verification',
      `${student?.name} submitted ₹${amount.toLocaleString('en-IN')} (${method} Ref: ${pendingInvoice.transactionRef}). Verify in Billing.`
    );

    return pendingInvoice;
  };

  // Admin Only: verify & approve pending student UTR payment
  const handleVerifyPendingInvoice = (invoiceId: string) => {
    if (!isAdmin) {
      setIsAdminAuthOpen(true);
      return;
    }
    const targetInv = invoices.find(inv => inv.id === invoiceId);
    if (!targetInv) return;

    const today = new Date().toISOString().split('T')[0];
    const currentYM = today.slice(0, 7);
    const invYM = (targetInv.periodStart || targetInv.paidDate).slice(0, 7);
    const newDueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    setInvoices(prev =>
      prev.map(inv => (inv.id === invoiceId ? { ...inv, status: 'PAID' } : inv))
    );

    if (invYM >= currentYM) {
      setStudents(prev =>
        prev.map(s =>
          s.id === targetInv.studentId
            ? {
                ...s,
                paymentStatus: 'PAID',
                cardValidFrom: today,
                renewalDueDate: newDueDate,
                lastPaymentDate: today,
              }
            : s
        )
      );
      setSelectedStudentForCard(prev =>
        prev && prev.id === targetInv.studentId
          ? {
              ...prev,
              paymentStatus: 'PAID',
              cardValidFrom: today,
              renewalDueDate: newDueDate,
              lastPaymentDate: today,
            }
          : prev
      );
    }

    sounds.playSuccess();
    sendBrowserPushNotification(
      '✓ Online Payment Verified',
      `Verified UTR ${targetInv.transactionRef} (₹${targetInv.amount}) for ${targetInv.studentName}.`
    );
  };

  // Admin Only: reject unverified / invalid student payment submission
  const handleRejectPendingInvoice = (invoiceId: string) => {
    if (!isAdmin) {
      setIsAdminAuthOpen(true);
      return;
    }
    const targetInv = invoices.find(inv => inv.id === invoiceId);
    setInvoices(prev =>
      prev.map(inv => (inv.id === invoiceId ? { ...inv, status: 'OVERDUE' } : inv))
    );
    sounds.playAlert();
    if (targetInv) {
      sendBrowserPushNotification(
        '⚠️ Payment Verification Declined',
        `UTR ${targetInv.transactionRef} for ${targetInv.studentName} was not matched in PhonePe.`
      );
    }
  };

  // Update existing student fee & details (Admin Only)
  const handleUpdateStudent = (updatedStudent: Student) => {
    if (!isAdmin) {
      setIsAdminAuthOpen(true);
      return;
    }
    setStudents(prev => prev.map(s => (s.id === updatedStudent.id ? updatedStudent : s)));
    setSelectedStudentForCard(prev =>
      prev && prev.id === updatedStudent.id ? updatedStudent : prev
    );
    sendBrowserPushNotification(
      `✓ Updated: ${updatedStudent.name}`,
      `Desk ${updatedStudent.assignedDesk} · Fee ₹${updatedStudent.monthlyFee}/mo saved.`
    );
  };

  // Update student photo via camera capture (Admin Only)
  const handleUpdateStudentPhoto = (studentId: string, photoDataUrl: string) => {
    if (!isAdmin) {
      setIsAdminAuthOpen(true);
      return;
    }
    setStudents(prev =>
      prev.map(s => (s.id === studentId ? { ...s, avatarUrl: photoDataUrl } : s))
    );
    setSelectedStudentForCard(prev =>
      prev && prev.id === studentId ? { ...prev, avatarUrl: photoDataUrl } : prev
    );
    sounds.playSuccess();
  };

  // Log individual WhatsApp fee reminder dispatch
  const handleDispatchWhatsAppReminder = (student: Student, message: string) => {
    const isOverdue = student.paymentStatus === 'OVERDUE' || student.paymentStatus === 'EXPIRED';
    const newReminder: PushReminder = {
      id: `REM-WA-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      studentId: student.id,
      studentName: student.name,
      phone: student.phone,
      type: isOverdue ? 'OVERDUE_ALERT' : 'DUE_IN_3_DAYS',
      title: `WhatsApp Fee Reminder · ${student.name}`,
      message,
      sentAt: new Date().toISOString(),
      channel: 'WHATSAPP',
      status: 'DELIVERED',
    };
    setReminders(prev => [newReminder, ...prev]);
    sounds.playSuccess();
    sendBrowserPushNotification(
      `WhatsApp Reminder Sent: ${student.name}`,
      `Desk ${student.assignedDesk} · Fee ₹${student.monthlyFee.toLocaleString('en-IN')}`
    );
  };

  // Automated batch payment reminder run
  const handleTriggerDailyReminderRun = (): { sentCount: number; affectedStudents: Student[] } => {
    const dueStudents = students.filter(s => s.paymentStatus === 'OVERDUE' || s.paymentStatus === 'DUE_SOON');
    const nowIso = new Date().toISOString();

    const newReminders: PushReminder[] = dueStudents.map((s, idx) => {
      const isOverdue = s.paymentStatus === 'OVERDUE';
      return {
        id: `REM-${Date.now()}-${idx}`,
        studentId: s.id,
        studentName: s.name,
        phone: s.phone,
        type: isOverdue ? 'OVERDUE_ALERT' : 'DUE_IN_3_DAYS',
        title: isOverdue ? 'Library Fee Overdue Notice' : 'Renewal Reminder',
        message: isOverdue
          ? `Hi ${s.name}, your membership fee of ₹${s.monthlyFee} is overdue. Pay via UPI (${settings.upiId || '9973299354@ybl'}) to retain desk ${s.assignedDesk}.`
          : `Hi ${s.name}, your study slot renews on ${s.renewalDueDate}. Amount due: ₹${s.monthlyFee} (UPI: ${settings.upiId || '9973299354@ybl'}).`,
        sentAt: nowIso,
        channel: 'PUSH',
        status: 'DELIVERED',
      };
    });

    setReminders(prev => [...newReminders, ...prev]);

    return {
      sentCount: dueStudents.length,
      affectedStudents: dueStudents,
    };
  };

  const activeSeatedCount = students.filter(s => s.attendanceStatus === 'CHECKED_IN').length;
  const overdueCount = students.filter(s => s.paymentStatus === 'OVERDUE').length;
  const pendingAppsCount = applications.filter(a => a.status === 'PENDING').length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Top Bar Contract Compliant Header */}
      <Header
        libraryName={settings.name}
        activeTab={activeTab}
        setActiveTab={(tab: string) => {
          if (tab === 'billing') setBillingInitialSubTab('LEDGER');
          setActiveTab(tab as typeof activeTab);
        }}
        unreadNotificationsCount={overdueCount}
        pendingApprovalsCount={pendingAppsCount}
        onOpenNotifications={() => runAsAdmin(() => setIsNotificationsOpen(true))}
        onOpenKiosk={() => setIsKioskOpen(true)}
        onOpenRegister={() => runAsAdmin(() => setIsRegisterOpen(true))}
        onOpenSelfRegister={() => setIsSelfRegisterOpen(true)}
        onOpenApprovals={() => runAsAdmin(() => setIsApprovalsOpen(true))}
        isAdmin={isAdmin}
        onOpenAdminAuth={() => setIsAdminAuthOpen(true)}
        totalActiveCount={activeSeatedCount}
        totalCapacity={settings.totalDesks}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-5">
        {storageWarning && (
          <div className="mb-4 px-4 py-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-center justify-between gap-3">
            <span>{storageWarning}</span>
            <button
              type="button"
              onClick={() => setStorageWarning(null)}
              className="font-bold text-amber-800 dark:text-amber-300 hover:underline shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}
        {activeTab === 'dashboard' && (
          <DashboardView
            students={students}
            peakHours={HOURLY_PEAK_DATA}
            settings={settings}
            pendingApplications={applications}
            isAdmin={isAdmin}
            onRequireAdmin={() => setIsAdminAuthOpen(true)}
            onOpenKiosk={() => setIsKioskOpen(true)}
            onOpenRegister={() => runAsAdmin(() => setIsRegisterOpen(true))}
            onOpenSelfRegister={() => setIsSelfRegisterOpen(true)}
            onOpenApprovals={() => runAsAdmin(() => setIsApprovalsOpen(true))}
            onOpenNotifications={() => runAsAdmin(() => setIsNotificationsOpen(true))}
            onSelectStudent={(s) => setSelectedStudentForCard(s)}
            setActiveTab={(tab: string) => {
              if (tab === 'billing') setBillingInitialSubTab('LEDGER');
              setActiveTab(tab as typeof activeTab);
            }}
          />
        )}

        {activeTab === 'attendance' && (
          <AttendanceView
            students={students}
            attendanceRecords={attendanceRecords}
            invoices={invoices}
            settings={settings}
            isAdmin={isAdmin}
            onRequireAdmin={() => setIsAdminAuthOpen(true)}
            onRecordPayment={handleRecordPayment}
            onCheckInToggle={handleCheckInToggle}
            onMarkDailyAttendance={handleMarkDailyAttendance}
            onBulkMarkDailyAttendance={handleBulkMarkDailyAttendance}
            onOpenKiosk={() => setIsKioskOpen(true)}
            onSelectStudent={(s) => setSelectedStudentForCard(s)}
          />
        )}

        {activeTab === 'members' && (
          <MembersView
            students={students}
            settings={settings}
            isAdmin={isAdmin}
            onRequireAdmin={() => setIsAdminAuthOpen(true)}
            pendingCount={pendingAppsCount}
            onOpenApprovals={() => runAsAdmin(() => setIsApprovalsOpen(true))}
            onOpenSelfRegister={() => setIsSelfRegisterOpen(true)}
            onOpenRegister={() => runAsAdmin(() => setIsRegisterOpen(true))}
            onSelectStudent={(s) => setSelectedStudentForCard(s)}
            onEditStudent={(s) => runAsAdmin(() => setEditingStudent(s))}
            onOpenPaymentModal={(s) =>
              runAsAdmin(() => {
                setSelectedStudentForPayment(s);
                setQuickPayAmount(s.monthlyFee);
                setQuickPayMethod('UPI');
              })
            }
            onCheckInToggle={(id) => handleCheckInToggle(id, 'STAFF_MANUAL')}
          />
        )}

        {activeTab === 'billing' && (
          <BillingView
            students={students}
            invoices={invoices}
            reminders={reminders}
            settings={settings}
            isAdmin={isAdmin}
            onRequireAdmin={() => setIsAdminAuthOpen(true)}
            onUpdateSettings={handleUpdateSettings}
            onRecordPayment={handleRecordPayment}
            onVerifyInvoice={handleVerifyPendingInvoice}
            onRejectInvoice={handleRejectPendingInvoice}
            onDispatchWhatsAppReminder={handleDispatchWhatsAppReminder}
            onOpenNotifications={() => runAsAdmin(() => setIsNotificationsOpen(true))}
            initialSubTab={billingInitialSubTab}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            peakHours={HOURLY_PEAK_DATA}
            retentionCohorts={RETENTION_COHORTS}
            settings={settings}
            totalStudentsCount={students.length}
          />
        )}

        {activeTab === 'student-portal' && (
          <StudentPortalView
            students={students}
            attendanceRecords={attendanceRecords}
            invoices={invoices}
            settings={settings}
            isAdmin={isAdmin}
            loggedInStudentId={loggedInStudentId}
            onLoginStudent={(studentId) => {
              setLoggedInStudentId(studentId);
              try {
                localStorage.setItem(STORAGE_KEYS.STUDENT_SESSION, studentId);
              } catch {
                // ignore
              }
            }}
            onLogoutStudent={() => {
              setLoggedInStudentId(null);
              try {
                localStorage.removeItem(STORAGE_KEYS.STUDENT_SESSION);
              } catch {
                // ignore
              }
            }}
            onSubmitPaymentRequest={handleSubmitOnlinePaymentRequest}
            onCheckInToggle={handleCheckInToggle}
            onViewStudentCard={(s) => setSelectedStudentForCard(s)}
            onOpenSelfRegister={() => setIsSelfRegisterOpen(true)}
            onOpenKiosk={() => {
              setKioskInitialMode('PIN');
              setIsKioskOpen(true);
            }}
            onOpenKioskQr={() => {
              setKioskInitialMode('QR');
              setIsKioskOpen(true);
            }}
          />
        )}
      </main>

      {/* Ergonomic Mobile Bottom Tab Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={(tab: string) => {
          if (tab === 'members' && !isAdmin) {
            runAsAdmin(() => setActiveTab('members'));
            return;
          }
          if (tab === 'billing') setBillingInitialSubTab('LEDGER');
          setActiveTab(tab as typeof activeTab);
        }}
        onOpenKiosk={() => {
          setKioskInitialMode('PIN');
          setIsKioskOpen(true);
        }}
        checkedInCount={activeSeatedCount}
        overdueCount={overdueCount}
        isAdmin={isAdmin}
      />

      {/* Modal Dialogs */}
      <KioskCheckInModal
        isOpen={isKioskOpen}
        onClose={() => {
          setIsKioskOpen(false);
          setKioskInitialMode('PIN');
        }}
        students={students}
        isAdmin={isAdmin}
        initialMode={kioskInitialMode}
        onViewFullCard={(student) => {
          setIsKioskOpen(false);
          setKioskInitialMode('PIN');
          setSelectedStudentForCard(student);
        }}
        onCheckInToggle={handleCheckInToggle}
      />

      <ScannedStudentDetailModal
        student={
          scannedStudentId
            ? students.find(s => s.id.toLowerCase() === scannedStudentId.toLowerCase()) || null
            : null
        }
        attendanceRecords={attendanceRecords}
        settings={settings}
        onClose={() => {
          setScannedStudentId(null);
          try {
            const url = new URL(window.location.href);
            if (url.searchParams.has('student_id')) {
              url.searchParams.delete('student_id');
              window.history.replaceState({}, '', url.pathname + url.search + url.hash);
            }
          } catch {
            // ignore
          }
        }}
        onOpenDigitalPass={(student) => setSelectedStudentForCard(student)}
        onCheckInToggle={handleCheckInToggle}
      />

      <StudentCardModal
        student={
          selectedStudentForCard
            ? students.find(s => s.id === selectedStudentForCard.id) || selectedStudentForCard
            : null
        }
        settings={settings}
        isAdmin={isAdmin}
        canViewSensitive={
          isAdmin ||
          Boolean(
            loggedInStudentId &&
              selectedStudentForCard &&
              loggedInStudentId === selectedStudentForCard.id
          )
        }
        onRequireAdmin={() => setIsAdminAuthOpen(true)}
        onClose={() => setSelectedStudentForCard(null)}
        onEdit={isAdmin ? (s) => setEditingStudent(s) : undefined}
        onUpdatePhoto={handleUpdateStudentPhoto}
      />

      <EditStudentModal
        student={isAdmin ? editingStudent : null}
        settings={settings}
        onClose={() => setEditingStudent(null)}
        onSave={handleUpdateStudent}
        onOpenPayment={(s) => {
          setSelectedStudentForPayment(s);
          setQuickPayAmount(s.monthlyFee);
          setQuickPayMethod('UPI');
        }}
      />

      <AdminAuthModal
        isOpen={isAdminAuthOpen}
        isAdmin={isAdmin}
        currentPin={adminPin}
        onClose={() => {
          setIsAdminAuthOpen(false);
          setPendingAdminAction(null);
        }}
        onUnlock={() => {
          setIsAdmin(true);
          if (pendingAdminAction) {
            const fn = pendingAdminAction;
            setPendingAdminAction(null);
            fn();
          }
        }}
        onLock={() => {
          setIsAdmin(false);
          setEditingStudent(null);
          setIsApprovalsOpen(false);
          setIsRegisterOpen(false);
          setIsNotificationsOpen(false);
          setSelectedStudentForPayment(null);
          setQuickPayError(null);
          if (activeTab === 'members') {
            setActiveTab('dashboard');
          }
        }}
        onChangePin={(newPin) => {
          setAdminPin(newPin);
          try {
            localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, newPin);
          } catch {
            // ignore
          }
        }}
      />

      <RegisterMemberModal
        isOpen={isAdmin && isRegisterOpen}
        onClose={() => setIsRegisterOpen(false)}
        onRegister={handleRegister}
        onBatchSimulate={handleBatchSimulate}
        settings={settings}
        availableDesksCount={settings.totalDesks - activeSeatedCount}
      />

      <StudentSelfRegisterModal
        isOpen={isSelfRegisterOpen}
        onClose={() => setIsSelfRegisterOpen(false)}
        onSubmitApplication={handleSubmitApplication}
        applications={applications}
        students={students}
        settings={settings}
        onViewStudentCard={(s) => setSelectedStudentForCard(s)}
      />

      <AdminApprovalModal
        isOpen={isAdmin && isApprovalsOpen}
        onClose={() => setIsApprovalsOpen(false)}
        applications={applications}
        onApprove={handleApproveApplication}
        onReject={handleRejectApplication}
        settings={settings}
        availableDesksCount={settings.totalDesks - activeSeatedCount}
        occupiedDesks={students.map(s => s.assignedDesk)}
      />

      <NotificationDrawer
        isOpen={isAdmin && isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        reminders={reminders}
        students={students}
        settings={settings}
        onTriggerDailyReminderRun={handleTriggerDailyReminderRun}
        onDispatchWhatsAppReminder={handleDispatchWhatsAppReminder}
        onOpenWhatsAppSetup={() => {
          setBillingInitialSubTab('WHATSAPP_REMINDERS');
          setActiveTab('billing');
        }}
      />

      {/* Quick Pay Modal trigger from members view or edit modal (Admin Only) */}
      {isAdmin && selectedStudentForPayment && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md max-h-[92dvh] overflow-y-auto p-6 shadow-2xl space-y-4 my-auto">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Collect Fee & Renew</h3>
              <p className="text-xs text-slate-500 mt-1">
                <strong>{selectedStudentForPayment.name}</strong> ({selectedStudentForPayment.id} · Desk {selectedStudentForPayment.assignedDesk})
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Fee Amount (₹)
              </label>
              <input
                type="number"
                min={1}
                value={quickPayAmount}
                onChange={e => {
                  setQuickPayAmount(Number(e.target.value));
                  setQuickPayError(null);
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
                Payment Mode
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['UPI', 'CASH', 'CARD'] as const).map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setQuickPayMethod(m)}
                    className={`py-2 rounded-xl text-xs font-bold transition-colors ${
                      quickPayMethod === m
                        ? 'bg-slate-900 dark:bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {quickPayMethod === 'UPI' && (
              <PhonePeScannerCard
                settings={settings}
                amount={quickPayAmount}
                note={`${selectedStudentForPayment.id} Fee`}
                compact
              />
            )}

            {quickPayError && (
              <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-xs font-semibold text-rose-700 dark:text-rose-300">
                {quickPayError}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  setSelectedStudentForPayment(null);
                  setQuickPayError(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (!Number.isFinite(quickPayAmount) || quickPayAmount < 1) {
                    setQuickPayError('Please enter a valid fee amount (minimum ₹1).');
                    return;
                  }
                  handleRecordPayment(selectedStudentForPayment.id, quickPayAmount, quickPayMethod);
                  sounds.playSuccess();
                  setQuickPayError(null);
                  setSelectedStudentForPayment(null);
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
              >
                Confirm ₹{(Number.isFinite(quickPayAmount) ? quickPayAmount : 0).toLocaleString('en-IN')} Paid
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
